<?php
session_start();
require_once 'config/database.php';

// Verify if user is logged in as admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

// Get admin name from session
$adminName = htmlspecialchars($_SESSION['user_name'] ?? 'Admin');

// Fetch dashboard statistics
try {
    // Get total active users count (interns + employees)
    $stmt = $pdo->query("
        SELECT 
            (SELECT COUNT(*) FROM interns WHERE status = 'active') + 
            (SELECT COUNT(*) FROM employees WHERE status = 'active') as total
    ");
    $totalUsers = $stmt->fetch()['total'];

    // Get today's attendance statistics
    $today = date('Y-m-d');
    
    // Present today (both interns and employees)
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT CONCAT(user_type, '-', user_id)) as present 
        FROM attendance_logs 
        WHERE date = ? AND user_type IN ('intern', 'employee')
    ");
    $stmt->execute([$today]);
    $presentToday = $stmt->fetch()['present'];

    // Late today (both interns and employees)
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT CONCAT(user_type, '-', user_id)) as late 
        FROM attendance_logs 
        WHERE date = ? AND user_type IN ('intern', 'employee') AND status = 'late'
    ");
    $stmt->execute([$today]);
    $lateToday = $stmt->fetch()['late'];

    // Calculate absent (total - present)
    $absentToday = $totalUsers - $presentToday;
    
    // Fetch recent attendance records
    $stmt = $pdo->prepare("
        SELECT 
            a.id,
            a.user_id,
            CASE 
                WHEN a.user_type = 'intern' THEN i.name
                WHEN a.user_type = 'employee' THEN e.name
            END as name,
            a.user_type as role,
            a.date,
            a.time_in as raw_time_in,
            a.time_out as raw_time_out,
            TIME_FORMAT(a.time_in, '%h:%i %p') as time_in,
            TIME_FORMAT(a.time_out, '%h:%i %p') as time_out,
            a.total_hours,
            a.status,
            a.image_path,
            a.timeout_image_path,
            CASE 
                WHEN a.user_type = 'intern' THEN i.school
                WHEN a.user_type = 'employee' THEN e.department
            END as additional_info,
            CASE 
                WHEN a.user_type = 'employee' THEN e.position
                ELSE 'Intern'
            END as position
        FROM attendance_logs a
        LEFT JOIN interns i ON a.user_type = 'intern' AND a.user_id = i.id
        LEFT JOIN employees e ON a.user_type = 'employee' AND a.user_id = e.id
        WHERE a.date >= DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY)
        ORDER BY a.date DESC, a.time_in DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recentAttendance = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log("Dashboard error: " . $e->getMessage());
    // Set default values if database query fails
    $totalUsers = 0;
    $presentToday = 0;
    $lateToday = 0;
    $absentToday = 0;
    $recentAttendance = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DICT Admin Dashboard</title>
    <link rel="stylesheet" href="css/admin-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <header>
        <div class="logo-left">
            <a href="index.php">
                <img src="img/dict-logo.png" alt="DICT Logo" class="header-logo">
            </a>
        </div>

        <div class="header-content">
            <h1>Admin Dashboard</h1>
            <div class="subheading">Department of Information and Communications Technology</div>
        </div>

        <div class="header-right">
            <!-- Notifications Bell -->
            <div class="notification-dropdown">
                <button id="notificationButton" class="notification-btn">
                    <i class="fas fa-bell"></i>
                    <span id="notificationBadge" class="notification-badge" style="display: none;">0</span>
                </button>
                <div id="notificationDropdown" class="notification-content">
                    <div class="notification-header">
                        <h3>Completion Notifications</h3>
                        <button id="markAllRead" class="mark-all-btn">Mark All Read</button>
                    </div>
                    <div id="notificationList" class="notification-list">
                        <div class="loading-notifications">Loading...</div>
                    </div>
                    <div class="notification-footer">
                        <button class="view-all-btn" onclick="viewAllCompletions()">View All Completions</button>
                    </div>
                </div>
            </div>

            <!-- Profile Dropdown -->
            <div class="profile-dropdown">
                <img src="img/profile.png" id="profileButton" alt="Profile" class="profile-img">
                <div id="dropdownMenu" class="dropdown-content">
                    <div class="admin-info">
                        <i class="fas fa-user-shield"></i>
                        <span>Welcome, <strong id="adminName"><?php echo $adminName; ?></strong></span>
                    </div>
                    <a href="#" onclick="openChangePinModal()"><i class="fas fa-key"></i>Change PIN</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
                </div>
            </div>
        </div>
    </header>

    <nav class="dashboard-nav">
        <div class="nav-item active">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </div>
        <a href="interns.php" class="nav-item">
            <i class="fas fa-users"></i>
            <span>Interns</span>
        </a>
        <a href="employee-management.php" class="nav-item">
            <i class="fas fa-user-tie"></i>
            <span>Employees</span>
        </a>
    </nav>

    <main class="dashboard-layout">
        <div class="quick-stats">
            <div class="stat-card">
                <i class="fas fa-users"></i>
                <div class="stat-info">
                    <h3>Total Active Users</h3>
                    <p class="stat-number"><?php echo $totalUsers; ?></p>
                </div>
            </div>
            <div class="stat-card">
                <i class="fas fa-user-check"></i>
                <div class="stat-info">
                    <h3>Present Today</h3>
                    <p class="stat-number"><?php echo $presentToday; ?></p>
                </div>
            </div>
            <div class="stat-card">
                <i class="fas fa-user-clock"></i>
                <div class="stat-info">
                    <h3>Late Today</h3>
                    <p class="stat-number"><?php echo $lateToday; ?></p>
                </div>
            </div>
            <div class="stat-card">
                <i class="fas fa-user-times"></i>
                <div class="stat-info">
                    <h3>Absent</h3>
                    <p class="stat-number"><?php echo $absentToday; ?></p>
                </div>
            </div>
        </div>



        <div class="dashboard-card full-width">
            <div class="card-header">
                <h2><i class="fas fa-table"></i> Recent Attendance</h2>
                <div class="card-actions">
                    <input type="text" placeholder="Search..." class="search-input">
                    <select class="filter-select">
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="month">This Month</option>
                    </select>

                </div>
            </div>
            <div class="table-container">
                <table class="attendance-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Role</th>
                            <th>Date</th>
                            <th>Time In</th>
                            <th>Time Out</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="attendanceData">
                        <?php foreach ($recentAttendance as $record): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($record['name']); ?></td>
                                <td><?php echo ucfirst(htmlspecialchars($record['role'])); ?></td>
                                <td><?php echo htmlspecialchars($record['date']); ?></td>
                                <td><?php echo htmlspecialchars($record['time_in']); ?></td>
                                <td><?php echo $record['time_out'] ? htmlspecialchars($record['time_out']) : '-'; ?></td>
                                <td>
                                    <span class="status-badge <?php echo $record['status']; ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $record['status'])); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="action-btn" onclick="viewDetails(<?php echo htmlspecialchars($record['id']); ?>)" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <?php if (!empty($record['image_path']) || !empty($record['timeout_image_path'])): ?>
                                        <button class="action-btn image-btn" onclick="viewAttendanceImages(<?php echo htmlspecialchars($record['id']); ?>)" title="View Attendance Photos">
                                            <i class="fas fa-camera"></i>
                                        </button>
                                    <?php else: ?>
                                        <button class="action-btn disabled" disabled title="No photos available">
                                            <i class="fas fa-camera"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Change PIN Modal -->
    <div id="changePinModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-key"></i> Change PIN</h2>
                <button class="close-btn" onclick="closeModal('changePinModal')"><i class="fas fa-times"></i></button>
            </div>
            <form id="changePinForm">
                <div class="form-group">
                    <label for="currentPin">Current PIN</label>
                    <input type="password" id="currentPin" name="currentPin" minlength="4" maxlength="6" required>
                </div>
                <div class="form-group">
                    <label for="newPin">New PIN</label>
                    <input type="password" id="newPin" name="newPin" minlength="4" maxlength="6" required>
                </div>
                <div class="form-group">
                    <label for="confirmPin">Confirm New PIN</label>
                    <input type="password" id="confirmPin" name="confirmPin" minlength="4" maxlength="6" required>
                </div>
                <div class="form-actions">
                    <button type="button" class="cancel-btn" onclick="closeModal('changePinModal')">Cancel</button>
                    <button type="submit" class="save-btn">Update PIN</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Attendance Details Modal -->
    <div id="attendanceDetailsModal" class="modal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h2><i class="fas fa-clipboard-list"></i> Attendance Details</h2>
                <button class="close-btn" onclick="closeModal('attendanceDetailsModal')"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <div class="details-grid">
                    <div class="detail-section">
                        <h3><i class="fas fa-user"></i> Personal Information</h3>
                        <div class="detail-item">
                            <label>Name:</label>
                            <span id="detailName">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Role:</label>
                            <span id="detailRole">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Position:</label>
                            <span id="detailPosition">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Department/School:</label>
                            <span id="detailAdditionalInfo">-</span>
                        </div>
                        <div class="detail-item">
                            <label>User ID:</label>
                            <span id="detailUserId">-</span>
                        </div>
                    </div>

                    <div class="detail-section">
                        <h3><i class="fas fa-clock"></i> Time Information</h3>
                        <div class="detail-item">
                            <label>Date:</label>
                            <span id="detailDate">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Time In:</label>
                            <span id="detailTimeIn">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Time Out:</label>
                            <span id="detailTimeOut">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Total Hours:</label>
                            <span id="detailTotalHours">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Status:</label>
                            <span id="detailStatus" class="status-badge">-</span>
                        </div>
                    </div>

                    <div class="detail-section full-width">
                        <h3><i class="fas fa-info-circle"></i> Additional Information</h3>
                        <div class="detail-item">
                            <label>Attendance ID:</label>
                            <span id="detailAttendanceId">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Day of Week:</label>
                            <span id="detailDayOfWeek">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Hours Worked:</label>
                            <span id="detailHoursWorked">-</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-secondary" onclick="closeModal('attendanceDetailsModal')">Close</button>
                <button class="btn-primary" onclick="editAttendance()">
                    <i class="fas fa-edit"></i> Edit Record
                </button>
            </div>
        </div>
    </div>

    <!-- Completion Management Modal -->
    <div id="completionManagementModal" class="modal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h2><i class="fas fa-graduation-cap"></i> Completion Management</h2>
                <button class="close-btn" onclick="closeModal('completionManagementModal')"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <div class="completion-management-content">
                    <div class="management-tabs">
                        <button class="tab-btn active" onclick="switchTab('pending')">Pending Graduation</button>
                        <button class="tab-btn" onclick="switchTab('graduated')">Graduated</button>
                        <button class="tab-btn" onclick="switchTab('notifications')">Recent Notifications</button>
                    </div>
                    
                    <div id="pendingTab" class="tab-content active">
                        <div class="completed-interns-list" id="pendingInternsList">
                            <div class="loading">Loading pending graduations...</div>
                        </div>
                    </div>
                    
                    <div id="graduatedTab" class="tab-content">
                        <div class="graduated-interns-list" id="graduatedInternsList">
                            <div class="loading">Loading graduated interns...</div>
                        </div>
                    </div>
                    
                    <div id="notificationsTab" class="tab-content">
                        <div class="notifications-list" id="managementNotificationsList">
                            <div class="loading">Loading notifications...</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Attendance Images Modal -->
    <div id="attendanceImagesModal" class="modal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h2><i class="fas fa-camera"></i> Attendance Photos</h2>
                <button class="close-btn" onclick="closeModal('attendanceImagesModal')"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <div class="attendance-images-content">
                    <div class="image-info-section">
                        <div class="image-info">
                            <h3 id="imageAttendanceName">Loading...</h3>
                            <p id="imageAttendanceDetails">Loading details...</p>
                        </div>
                    </div>
                    
                    <div class="images-grid">
                        <div class="image-card" id="timeInImageCard">
                            <div class="image-header">
                                <h4><i class="fas fa-sign-in-alt"></i> Time In Photo</h4>
                                <span id="timeInTimestamp" class="timestamp"></span>
                            </div>
                            <div class="image-container">
                                <img id="timeInImage" src="" alt="Time In Photo" style="display: none;">
                                <div id="timeInNoImage" class="no-image">
                                    <i class="fas fa-camera-slash"></i>
                                    <p>No photo available</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="image-card" id="timeOutImageCard">
                            <div class="image-header">
                                <h4><i class="fas fa-sign-out-alt"></i> Time Out Photo</h4>
                                <span id="timeOutTimestamp" class="timestamp"></span>
                            </div>
                            <div class="image-container">
                                <img id="timeOutImage" src="" alt="Time Out Photo" style="display: none;">
                                <div id="timeOutNoImage" class="no-image">
                                    <i class="fas fa-camera-slash"></i>
                                    <p>No photo available</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-secondary" onclick="closeModal('attendanceImagesModal')">Close</button>
            </div>
        </div>
    </div>

    <footer>
        &copy; 2025 DICT &bull; Reginaldo &bull; Tesorero | All rights reserved
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle profile dropdown
            document.getElementById('profileButton').addEventListener('click', function() {
                document.getElementById('dropdownMenu').classList.toggle('show');
            });

            // Toggle notification dropdown
            document.getElementById('notificationButton').addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const dropdown = document.getElementById('notificationDropdown');
                const notificationDropdownContainer = document.querySelector('.notification-dropdown');
                
                // Close other dropdowns first
                const profileDropdown = document.getElementById('dropdownMenu');
                if (profileDropdown.classList.contains('show')) {
                    profileDropdown.classList.remove('show');
                }
                
                dropdown.classList.toggle('show');
                notificationDropdownContainer.classList.toggle('show');
                
                if (dropdown.classList.contains('show')) {
                    loadNotifications();
                }
            });

            // Mark all notifications as read
            document.getElementById('markAllRead').addEventListener('click', function() {
                markAllNotificationsRead();
            });

            // Close dropdowns when clicking outside
            window.addEventListener('click', function(e) {
                // Close profile dropdown
                if (!e.target.closest('.profile-dropdown')) {
                    const profileDropdown = document.getElementById('dropdownMenu');
                    if (profileDropdown && profileDropdown.classList.contains('show')) {
                        profileDropdown.classList.remove('show');
                    }
                }
                
                // Close notification dropdown
                if (!e.target.closest('.notification-dropdown')) {
                    const notificationDropdown = document.getElementById('notificationDropdown');
                    const notificationDropdownContainer = document.querySelector('.notification-dropdown');
                    if (notificationDropdown && notificationDropdown.classList.contains('show')) {
                        notificationDropdown.classList.remove('show');
                    }
                    if (notificationDropdownContainer && notificationDropdownContainer.classList.contains('show')) {
                        notificationDropdownContainer.classList.remove('show');
                    }
                }
            });

            // Load completion stats on page load
            loadCompletionStats();
            
            // Auto-refresh notifications every 30 seconds
            setInterval(function() {
                loadNotificationCount();
            }, 30000);
            
            // Add escape key listener to close dropdowns
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    closeAllDropdowns();
                }
            });

            // Handle PIN change form submission
            const changePinForm = document.getElementById('changePinForm');
            if (changePinForm) {
                changePinForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const currentPin = document.getElementById('currentPin').value;
                    const newPin = document.getElementById('newPin').value;
                    const confirmPin = document.getElementById('confirmPin').value;
                    
                    if (newPin !== confirmPin) {
                        alert('New PIN and Confirm PIN do not match!');
                        return;
                    }
                    
                    // Show loading state
                    const submitBtn = e.target.querySelector('.save-btn');
                    if (submitBtn) {
                        submitBtn.disabled = true;
                        submitBtn.textContent = 'Updating...';
                    }
                    
                    fetch('change_pin.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify({
                            currentPin: currentPin,
                            newPin: newPin
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('PIN updated successfully!');
                            closeModal('changePinModal');
                        } else {
                            alert(data.message || 'Failed to update PIN. Please try again.');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while updating PIN. Please try again.');
                    })
                    .finally(() => {
                        // Reset button state
                        if (submitBtn) {
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'Update PIN';
                        }
                    });
                });
            }
        });

        function openChangePinModal() {
            document.getElementById('changePinModal').style.display = 'flex';
            const changePinForm = document.getElementById('changePinForm');
            if (changePinForm) {
                changePinForm.reset();
            }
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
            // Ensure no blocking overlays remain
            closeAllDropdowns();
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }

        function viewDetails(attendanceId) {
            // Find the attendance record from the current data
            const attendanceRecords = <?php echo json_encode($recentAttendance); ?>;
            const record = attendanceRecords.find(r => r.id == attendanceId);
            
            if (!record) {
                alert('Attendance record not found!');
                return;
            }
            
            // Populate the modal with data
            populateAttendanceModal(record);
            
            // Show the modal
            document.getElementById('attendanceDetailsModal').style.display = 'flex';
        }

        function populateAttendanceModal(record) {
            // Personal Information
            document.getElementById('detailName').textContent = record.name || '-';
            document.getElementById('detailRole').textContent = ucfirst(record.role) || '-';
            document.getElementById('detailPosition').textContent = record.position || '-';
            document.getElementById('detailAdditionalInfo').textContent = record.additional_info || '-';
            document.getElementById('detailUserId').textContent = record.user_id || '-';
            
            // Time Information
            const date = new Date(record.date);
            document.getElementById('detailDate').textContent = date.toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
            document.getElementById('detailTimeIn').textContent = record.time_in || '-';
            document.getElementById('detailTimeOut').textContent = record.time_out || 'Not recorded';
            document.getElementById('detailTotalHours').textContent = record.total_hours ? 
                parseFloat(record.total_hours).toFixed(2) + ' hours' : 'Not calculated';
            
            // Status badge
            const statusElement = document.getElementById('detailStatus');
            statusElement.textContent = ucfirst(record.status.replace('_', ' '));
            statusElement.className = 'status-badge ' + record.status;
            
            // Additional Information
            document.getElementById('detailAttendanceId').textContent = record.id;
            document.getElementById('detailDayOfWeek').textContent = date.toLocaleDateString('en-US', {
                weekday: 'long'
            });
            
            // Calculate hours worked if both times are available
            let hoursWorked = '-';
            if (record.raw_time_in && record.raw_time_out) {
                const timeIn = new Date('2000-01-01 ' + record.raw_time_in);
                const timeOut = new Date('2000-01-01 ' + record.raw_time_out);
                const diffMs = timeOut - timeIn;
                const diffHours = diffMs / (1000 * 60 * 60);
                hoursWorked = diffHours.toFixed(2) + ' hours';
            }
            document.getElementById('detailHoursWorked').textContent = hoursWorked;
        }

        function ucfirst(str) {
            return str.charAt(0).toUpperCase() + str.slice(1);
        }

        function editAttendance() {
            // TODO: Implement edit functionality
            alert('Edit functionality will be implemented soon!');
            // This could open an edit modal or redirect to an edit page
        }

        // === COMPLETION NOTIFICATION SYSTEM ===
        
        function loadNotifications() {
            fetch('get_admin_notifications.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updateNotificationDropdown(data.notifications);
                        updateNotificationBadge(data.unread_count);
                    } else {
                        console.error('Failed to load notifications:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error loading notifications:', error);
                });
        }

        function loadNotificationCount() {
            fetch('get_admin_notifications.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updateNotificationBadge(data.unread_count);
                    }
                })
                .catch(error => {
                    console.error('Error loading notification count:', error);
                });
        }

        function updateNotificationDropdown(notifications) {
            const notificationList = document.getElementById('notificationList');
            
            if (notifications.length === 0) {
                notificationList.innerHTML = '<div class="no-notifications">No recent notifications</div>';
                return;
            }

            let html = '';
            notifications.forEach(notification => {
                const isUnread = !notification.notification_read;
                const completionDate = new Date(notification.completion_date).toLocaleDateString();
                
                html += `
                    <div class="notification-item ${isUnread ? 'unread' : ''}" data-id="${notification.id}">
                        <div class="notification-icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <div class="notification-content-text">
                            <div class="notification-title">
                                <strong>${notification.intern_name}</strong> completed internship
                            </div>
                            <div class="notification-details">
                                ${notification.school} • ${notification.completed_hours}/${notification.required_hours} hours
                            </div>
                            <div class="notification-time">${completionDate}</div>
                        </div>
                        <div class="notification-actions">
                            ${isUnread ? '<div class="unread-dot"></div>' : ''}
                            <button class="action-btn small" onclick="viewInternCompletion(${notification.intern_id})">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                `;
            });

            notificationList.innerHTML = html;
        }

        function updateNotificationBadge(count) {
            const badge = document.getElementById('notificationBadge');
            if (count > 0) {
                badge.textContent = count > 99 ? '99+' : count;
                badge.style.display = 'block';
            } else {
                badge.style.display = 'none';
            }
        }

        function markAllNotificationsRead() {
            fetch('mark_notification_read.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ mark_all: true })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateNotificationBadge(0);
                    loadNotifications(); // Refresh the list
                } else {
                    alert('Failed to mark notifications as read: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error marking notifications as read:', error);
            });
        }

        // === COMPLETION STATISTICS ===
        
        function loadCompletionStats() {
            fetch('get_admin_notifications.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.completion_stats) {
                        const stats = data.completion_stats;
                        document.getElementById('completedThisWeek').textContent = stats.completed_this_week || 0;
                        document.getElementById('completedThisMonth').textContent = stats.completed_this_month || 0;
                        document.getElementById('totalCompleted').textContent = stats.total_completed || 0;
                        
                        // Calculate pending graduation (completed but not graduated)
                        fetch('get_pending_graduations.php')
                            .then(response => response.json())
                            .then(pendingData => {
                                if (pendingData.success) {
                                    document.getElementById('pendingGraduation').textContent = pendingData.pending_count || 0;
                                }
                            })
                            .catch(error => console.error('Error loading pending graduations:', error));
                    }
                })
                .catch(error => {
                    console.error('Error loading completion stats:', error);
                });
        }

        function checkAllCompletions() {
            fetch('check_completion.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        loadCompletionStats();
                        loadNotificationCount();
                    } else {
                        alert('Error checking completions: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error checking completions:', error);
                    alert('An error occurred while checking completions.');
                });
        }

        function viewCompletionReport() {
            // Redirect to completion report page or open modal
            window.open('completion_report.php', '_blank');
        }

        function viewAllCompletions() {
            document.getElementById('completionManagementModal').style.display = 'flex';
            loadCompletionManagement();
        }

        function viewInternCompletion(internId) {
            // Close notification dropdown completely
            closeAllDropdowns();
            
            // Open completion management modal and switch to the appropriate tab
            document.getElementById('completionManagementModal').style.display = 'flex';
            switchTab('pending');
            loadCompletionManagement();
        }
        
        // Helper function to close all dropdowns and remove any blocking overlays
        function closeAllDropdowns() {
            const notificationDropdown = document.getElementById('notificationDropdown');
            const notificationDropdownContainer = document.querySelector('.notification-dropdown');
            const profileDropdown = document.getElementById('dropdownMenu');
            
            if (notificationDropdown) {
                notificationDropdown.classList.remove('show');
            }
            if (notificationDropdownContainer) {
                notificationDropdownContainer.classList.remove('show');
                // Force remove any lingering show class after animation
                setTimeout(() => {
                    notificationDropdownContainer.classList.remove('show');
                }, 250);
            }
            if (profileDropdown) {
                profileDropdown.classList.remove('show');
            }
            
            // Remove any potential blocking overlays
            document.body.style.pointerEvents = 'auto';
            document.body.style.overflow = 'auto';
        }

        // === COMPLETION MANAGEMENT ===
        
        function switchTab(tabName) {
            // Update tab buttons
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelector(`[onclick="switchTab('${tabName}')"]`).classList.add('active');
            
            // Update tab content
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            document.getElementById(tabName + 'Tab').classList.add('active');
            
            // Load appropriate content
            if (tabName === 'pending') {
                loadPendingGraduations();
            } else if (tabName === 'graduated') {
                loadGraduatedInterns();
            } else if (tabName === 'notifications') {
                loadManagementNotifications();
            }
        }

        function loadCompletionManagement() {
            loadPendingGraduations();
        }

        function loadPendingGraduations() {
            // Implementation for loading pending graduations
            document.getElementById('pendingInternsList').innerHTML = '<div class="loading">Loading pending graduations...</div>';
            
            // This would fetch from a dedicated endpoint
            fetch('get_pending_graduations.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updatePendingGraduationsList(data.interns);
                    } else {
                        document.getElementById('pendingInternsList').innerHTML = '<div class="error">Failed to load pending graduations</div>';
                    }
                })
                .catch(error => {
                    console.error('Error loading pending graduations:', error);
                    document.getElementById('pendingInternsList').innerHTML = '<div class="error">Error loading data</div>';
                });
        }

        function updatePendingGraduationsList(interns) {
            const container = document.getElementById('pendingInternsList');
            
            if (interns.length === 0) {
                container.innerHTML = '<div class="no-data">No interns pending graduation</div>';
                return;
            }

            let html = '';
            interns.forEach(intern => {
                const completionDate = new Date(intern.completion_date).toLocaleDateString();
                const progressPercentage = ((intern.completed_hours / intern.required_hours) * 100).toFixed(1);
                
                html += `
                    <div class="completion-intern-card">
                        <div class="intern-info">
                            <div class="intern-name">${intern.name}</div>
                            <div class="intern-details">${intern.school}</div>
                            <div class="completion-info">
                                Completed: ${completionDate} • ${intern.completed_hours}/${intern.required_hours} hours (${progressPercentage}%)
                            </div>
                        </div>
                        <div class="intern-actions">
                            <button class="action-btn success" onclick="graduateIntern(${intern.id}, '${intern.name}')">
                                <i class="fas fa-graduation-cap"></i> Graduate
                            </button>
                            <button class="action-btn" onclick="viewInternDetails(${intern.id})">
                                <i class="fas fa-eye"></i> View
                            </button>
                        </div>
                    </div>
                `;
            });

            container.innerHTML = html;
        }

        function graduateIntern(internId, internName) {
            if (confirm(`Are you sure you want to graduate ${internName}? This will mark them as inactive.`)) {
                fetch('graduate_intern.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({
                        intern_id: internId,
                        action: 'graduate'
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        loadPendingGraduations();
                        loadCompletionStats();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error graduating intern:', error);
                    alert('An error occurred while graduating the intern.');
                });
            }
        }

        function loadGraduatedInterns() {
            // Implementation for loading graduated interns
            document.getElementById('graduatedInternsList').innerHTML = '<div class="loading">Loading graduated interns...</div>';
            // TODO: Implement this endpoint and functionality
        }

        function loadManagementNotifications() {
            // Reuse existing notification loading
            fetch('get_admin_notifications.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updateManagementNotificationsList(data.notifications);
                    } else {
                        document.getElementById('managementNotificationsList').innerHTML = '<div class="error">Failed to load notifications</div>';
                    }
                })
                .catch(error => {
                    console.error('Error loading management notifications:', error);
                    document.getElementById('managementNotificationsList').innerHTML = '<div class="error">Error loading notifications</div>';
                });
        }

        function updateManagementNotificationsList(notifications) {
            const container = document.getElementById('managementNotificationsList');
            
            if (notifications.length === 0) {
                container.innerHTML = '<div class="no-data">No recent notifications</div>';
                return;
            }

            let html = '';
            notifications.forEach(notification => {
                const completionDate = new Date(notification.completion_date).toLocaleDateString();
                const createdDate = new Date(notification.created_at).toLocaleDateString();
                
                html += `
                    <div class="notification-card ${!notification.notification_read ? 'unread' : ''}">
                        <div class="notification-header">
                            <div class="notification-title">${notification.intern_name} - Internship Completed</div>
                            <div class="notification-date">${createdDate}</div>
                        </div>
                        <div class="notification-body">
                            <div class="intern-details">
                                <strong>School:</strong> ${notification.school}<br>
                                <strong>Hours:</strong> ${notification.completed_hours}/${notification.required_hours}<br>
                                <strong>Completion Date:</strong> ${completionDate}<br>
                                <strong>Status:</strong> ${notification.completion_status}
                            </div>
                        </div>
                        <div class="notification-actions">
                            <button class="action-btn" onclick="viewInternDetails(${notification.intern_id})">
                                <i class="fas fa-eye"></i> View Details
                            </button>
                            ${notification.completion_status === 'completed' ? 
                                `<button class="action-btn success" onclick="graduateIntern(${notification.intern_id}, '${notification.intern_name}')">
                                    <i class="fas fa-graduation-cap"></i> Graduate
                                </button>` : ''
                            }
                        </div>
                    </div>
                `;
            });

            container.innerHTML = html;
        }

        // === ATTENDANCE IMAGES FUNCTIONALITY ===
        
        function viewAttendanceImages(attendanceId) {
            // Find the attendance record from the current data
            const attendanceRecords = <?php echo json_encode($recentAttendance); ?>;
            const record = attendanceRecords.find(r => r.id == attendanceId);
            
            if (!record) {
                alert('Attendance record not found!');
                return;
            }
            
            // Populate the image modal with data
            populateImageModal(record);
            
            // Show the modal
            document.getElementById('attendanceImagesModal').style.display = 'flex';
        }

        function populateImageModal(record) {
            // Set header information
            document.getElementById('imageAttendanceName').textContent = record.name;
            document.getElementById('imageAttendanceDetails').textContent = 
                `${ucfirst(record.role)} • ${record.date} • ${record.status.replace('_', ' ')}`;
            
            // Handle Time In Image
            const timeInImg = document.getElementById('timeInImage');
            const timeInNoImage = document.getElementById('timeInNoImage');
            const timeInTimestamp = document.getElementById('timeInTimestamp');
            
            if (record.image_path) {
                timeInImg.src = `view_attendance_image.php?path=${encodeURIComponent(record.image_path)}`;
                timeInImg.style.display = 'block';
                timeInNoImage.style.display = 'none';
                timeInTimestamp.textContent = record.time_in;
                
                // Add click event to open image in new tab
                timeInImg.onclick = function() {
                    window.open(this.src, '_blank');
                };
            } else {
                timeInImg.style.display = 'none';
                timeInNoImage.style.display = 'flex';
                timeInTimestamp.textContent = record.time_in || 'Not recorded';
            }
            
            // Handle Time Out Image
            const timeOutImg = document.getElementById('timeOutImage');
            const timeOutNoImage = document.getElementById('timeOutNoImage');
            const timeOutTimestamp = document.getElementById('timeOutTimestamp');
            
            if (record.timeout_image_path) {
                timeOutImg.src = `view_attendance_image.php?path=${encodeURIComponent(record.timeout_image_path)}`;
                timeOutImg.style.display = 'block';
                timeOutNoImage.style.display = 'none';
                timeOutTimestamp.textContent = record.time_out || 'Time out recorded';
                
                // Add click event to open image in new tab
                timeOutImg.onclick = function() {
                    window.open(this.src, '_blank');
                };
            } else {
                timeOutImg.style.display = 'none';
                timeOutNoImage.style.display = 'flex';
                timeOutTimestamp.textContent = record.time_out || 'Not recorded';
            }
        }
    </script>
</body>
</html> 