<?php
session_start();
require_once 'config/database.php';

// Verify if user is logged in as intern
if (!isset($_SESSION['intern_id'])) {
    header('Location: login.php');
    exit();
}

try {
    // Get intern details
    $stmt = $pdo->prepare("SELECT * FROM interns WHERE id = ? AND status = 'active'");
    $stmt->execute([$_SESSION['intern_id']]);
    $intern = $stmt->fetch();

    if (!$intern) {
        session_destroy();
        header('Location: login.php');
        exit();
    }

    // Get the current month and year
    $currentMonth = isset($_GET['month']) ? $_GET['month'] : date('m');
    $currentYear = date('Y'); // Always use current year

    // Set timezone to Asia/Manila
    date_default_timezone_set('Asia/Manila');

    // Get monthly attendance with break time adjustment
    $stmt = $pdo->prepare("
        SELECT 
            al.date,
            TIME_FORMAT(al.time_in, '%h:%i %p') as time_in,
            TIME_FORMAT(al.time_out, '%h:%i %p') as time_out,
            al.time_in as raw_time_in,
            al.time_out as raw_time_out,
            al.total_hours,
            al.status,
            idr.tasks_done as tasks
        FROM attendance_logs al
        LEFT JOIN intern_daily_reports idr ON al.date = idr.date AND al.user_id = idr.intern_id
        WHERE al.user_type = 'intern' 
        AND al.user_id = ? 
        AND MONTH(al.date) = ?
        AND YEAR(al.date) = ?
        ORDER BY al.date DESC
    ");

    // Debug: Log the query parameters
    error_log("Query parameters - User ID: {$_SESSION['intern_id']}, Month: $currentMonth, Year: $currentYear");

    $stmt->execute([$_SESSION['intern_id'], $currentMonth, $currentYear]);
    $attendanceRecords = $stmt->fetchAll();

    // Debug: Log the query results
    error_log("Attendance Records for month $currentMonth, year $currentYear: " . print_r($attendanceRecords, true));

    // Calculate monthly statistics
    $totalDays = 0;
    $totalHours = 0;
    $onTimeCount = 0;
    $lateCount = 0;

    foreach ($attendanceRecords as $record) {
        // Debug: Log each record being processed
        error_log("Processing record: " . print_r($record, true));
        
        if ($record['time_out']) {
            $totalDays++;
            if ($record['total_hours'] !== null) {
                $totalHours += floatval($record['total_hours']);
            }
            
            // Use the status directly from the database instead of recalculating
            if ($record['status'] === 'on_time') {
                $onTimeCount++;
            } else if ($record['status'] === 'late') {
                $lateCount++;
            }
        }
    }

    // Debug: Log final statistics
    error_log("Final Statistics - Total Days: $totalDays, Total Hours: $totalHours, On Time: $onTimeCount, Late: $lateCount");

} catch (PDOException $e) {
    error_log("Attendance History error: " . $e->getMessage());
    $attendanceRecords = [];
    $totalDays = 0;
    $totalHours = 0;
    $onTimeCount = 0;
    $lateCount = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance History - DICT Intern</title>
    <link rel="stylesheet" href="css/intern-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .attendance-header {
            background: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 1rem;
        }

        .month-selector {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .month-selector select {
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 0.9rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }

        .stat-box {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 4px;
            text-align: center;
        }

        .stat-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--dict-blue);
            margin-bottom: 0.25rem;
        }

        .stat-label {
            font-size: 0.85rem;
            color: #666;
        }

        .attendance-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .attendance-table table {
            width: 100%;
            border-collapse: collapse;
        }

        .attendance-table th,
        .attendance-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .attendance-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }

        .attendance-table tr:hover {
            background: #f8f9fa;
        }

        .status-pill {
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.85rem;
            font-weight: 500;
            display: inline-block;
        }

        .status-pill.on-time {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .status-pill.late {
            background: #fff3e0;
            color: #e65100;
        }

        .time-cell {
            white-space: nowrap;
        }



        .tasks-cell {
            max-width: 300px;
        }

        .tasks-content {
            white-space: pre-line;
            color: #444;
            font-size: 0.9rem;
            line-height: 1.4;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo-left">
            <a href="index.php">
                <img src="img/dict-logo.png" alt="DICT Logo" class="header-logo">
            </a>
        </div>

        <div class="header-content">
            <h1>Attendance History</h1>
            <div class="subheading">Department of Information and Communications Technology</div>
        </div>

        <div class="profile-dropdown">
            <img src="img/profile.png" alt="Profile" class="profile-img" id="profileButton">
            <div id="dropdownMenu" class="dropdown-content">
                <div class="admin-info">
                    <i class="fas fa-user"></i>
                    <span>Welcome, <strong><?php echo htmlspecialchars($intern['name']); ?></strong></span>
                </div>
                <a href="#" onclick="openChangePinModal()"><i class="fas fa-key"></i>Change PIN</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
            </div>
        </div>
    </header>

    <nav class="dashboard-nav">
        <a href="intern-dashboard.php" class="nav-item">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </a>
        <div class="nav-item active">
            <i class="fas fa-history"></i>
            <span>Attendance History</span>
        </div>
    </nav>

    <main class="dashboard-layout">
        <div class="attendance-header">
            <div class="month-selector">
                <select id="monthSelect" onchange="updateAttendance()">
                    <?php
                    // Get the last 3 months
                    $months = [];
                    for ($i = 0; $i < 3; $i++) {
                        $monthNum = date('m', strtotime("-$i month"));
                        $monthName = date('F', strtotime("-$i month"));
                        $months[$monthNum] = $monthName;
                    }
                    
                    foreach ($months as $num => $name) {
                        $selected = $num == $currentMonth ? 'selected' : '';
                        echo "<option value='$num' $selected>$name</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="stats-grid">
                <div class="stat-box">
                    <div class="stat-number"><?php echo $totalDays; ?></div>
                    <div class="stat-label">Days Present</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo number_format($totalHours, 1); ?></div>
                    <div class="stat-label">Total Hours</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo $onTimeCount; ?></div>
                    <div class="stat-label">On Time</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo $lateCount; ?></div>
                    <div class="stat-label">Late Arrivals</div>
                </div>
            </div>
        </div>

        <div class="attendance-table">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time In</th>
                        <th>Time Out</th>
                        <th>Hours</th>
                        <th>Status</th>
                        <th>Tasks Completed</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attendanceRecords as $record): 
                        $timeIn = strtotime($record['date'] . ' ' . $record['time_in']);
                        $expectedTimeIn = strtotime($record['date'] . ' 08:00:00');
                        $status = $timeIn <= $expectedTimeIn ? 'on-time' : 'late';
                    ?>
                    <tr>
                        <td><?php echo date('l, F j, Y', strtotime($record['date'])); ?></td>
                        <td class="time-cell"><?php echo $record['time_in']; ?></td>
                        <td class="time-cell"><?php echo $record['time_out'] ?: '-'; ?></td>
                        <td><?php echo $record['total_hours'] ? number_format($record['total_hours'], 1) : '-'; ?></td>
                        <td>
                            <span class="status-pill <?php echo $status; ?>">
                                <?php echo $status === 'on-time' ? 'On Time' : 'Late'; ?>
                            </span>
                        </td>
                        <td class="tasks-cell">
                            <div class="tasks-content">
                                <?php echo htmlspecialchars($record['tasks'] ?: 'No tasks recorded'); ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>
        &copy; 2025 DICT &bull; Reginaldo &bull; Tesorero | All rights reserved
    </footer>

    <script>
        function updateAttendance() {
            const month = document.getElementById('monthSelect').value;
            window.location.href = `attendance-history.php?month=${month}`;
        }

        // Profile dropdown functionality
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('profileButton').addEventListener('click', function() {
                document.getElementById('dropdownMenu').classList.toggle('show');
            });

            window.addEventListener('click', function(e) {
                if (!e.target.matches('#profileButton')) {
                    const dropdown = document.getElementById('dropdownMenu');
                    if (dropdown.classList.contains('show')) {
                        dropdown.classList.remove('show');
                    }
                }
            });
        });
    </script>
</body>
</html> 