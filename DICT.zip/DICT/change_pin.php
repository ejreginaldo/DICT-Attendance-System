<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

// Determine user type and verify authentication
$isAdmin = isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true && isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin';
$isIntern = isset($_SESSION['intern_id']);

if (!$isAdmin && !$isIntern) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);
$currentPin = $data['currentPin'] ?? '';
$newPin = $data['newPin'] ?? '';

if (empty($currentPin) || empty($newPin)) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit();
}

// Validate PIN format (4-6 digits)
if (!preg_match('/^\d{4,6}$/', $newPin)) {
    echo json_encode(['success' => false, 'message' => 'PIN must be 4-6 digits']);
    exit();
}

try {
    if ($isAdmin) {
        // Handle admin PIN change
        $stmt = $pdo->prepare("SELECT pin FROM admins WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        $userId = $_SESSION['user_id'];
        $tableName = 'admins';
        
    } else {
        // Handle intern PIN change
        $stmt = $pdo->prepare("SELECT pin FROM interns WHERE id = ?");
        $stmt->execute([$_SESSION['intern_id']]);
        $user = $stmt->fetch();
        $userId = $_SESSION['intern_id'];
        $tableName = 'interns';
    }

    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit();
    }

    // Verify current PIN
    if (!password_verify($currentPin, $user['pin'])) {
        echo json_encode(['success' => false, 'message' => 'Current PIN is incorrect']);
        exit();
    }

    // Update PIN with new hashed version
    $hashedPin = password_hash($newPin, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE {$tableName} SET pin = ? WHERE id = ?");
    $stmt->execute([$hashedPin, $userId]);

    $userType = $isAdmin ? 'Admin' : 'Intern';
    echo json_encode([
        'success' => true, 
        'message' => 'PIN updated successfully',
        'user_type' => strtolower($userType)
    ]);

} catch (PDOException $e) {
    error_log("PIN change error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred while updating PIN']);
} 