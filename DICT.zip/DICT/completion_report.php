<?php
session_start();
require_once 'config/database.php';

// Verify if user is logged in as admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

// Get admin name from session
$adminName = htmlspecialchars($_SESSION['user_name'] ?? 'Admin');

// Get filter parameters
$filterMonth = $_GET['month'] ?? date('Y-m');
$filterStatus = $_GET['status'] ?? 'all';
$filterSchool = $_GET['school'] ?? 'all';

try {
    // Get completion statistics
    $stmt = $pdo->query("
        SELECT 
            COUNT(CASE WHEN completion_status = 'graduated' THEN 1 END) as total_graduated,
            COUNT(CASE WHEN completion_status = 'completed' THEN 1 END) as pending_graduation,
            COUNT(CASE WHEN completion_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
                       AND completion_status IN ('completed', 'graduated') THEN 1 END) as completed_this_week,
            COUNT(CASE WHEN completion_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) 
                       AND completion_status IN ('completed', 'graduated') THEN 1 END) as completed_this_month,
            AVG(completed_hours) as avg_hours_completed,
            AVG(DATEDIFF(completion_date, start_date)) as avg_completion_days
        FROM interns 
        WHERE completion_status IN ('completed', 'graduated')
    ");
    $stats = $stmt->fetch();
    
    // Get monthly completion data for charts
    $stmt = $pdo->query("
        SELECT 
            DATE_FORMAT(completion_date, '%Y-%m') as month,
            COUNT(*) as completions,
            COUNT(CASE WHEN completion_status = 'graduated' THEN 1 END) as graduated,
            COUNT(CASE WHEN completion_status = 'completed' THEN 1 END) as pending
        FROM interns 
        WHERE completion_date IS NOT NULL 
        AND completion_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
        GROUP BY DATE_FORMAT(completion_date, '%Y-%m')
        ORDER BY month ASC
    ");
    $monthlyData = $stmt->fetchAll();
    
    // Get completion details with filters
    $whereConditions = ["completion_date IS NOT NULL"];
    $params = [];
    
    if ($filterMonth && $filterMonth !== 'all') {
        $whereConditions[] = "DATE_FORMAT(completion_date, '%Y-%m') = ?";
        $params[] = $filterMonth;
    }
    
    if ($filterStatus && $filterStatus !== 'all') {
        $whereConditions[] = "completion_status = ?";
        $params[] = $filterStatus;
    }
    
    if ($filterSchool && $filterSchool !== 'all') {
        $whereConditions[] = "school LIKE ?";
        $params[] = "%$filterSchool%";
    }
    
    $whereClause = implode(' AND ', $whereConditions);
    
    $stmt = $pdo->prepare("
        SELECT 
            id, name, school, start_date, completion_date, 
            required_hours, completed_hours, completion_status,
            DATEDIFF(completion_date, start_date) as completion_days,
            (completed_hours / required_hours) * 100 as completion_percentage
        FROM interns 
        WHERE $whereClause
        ORDER BY completion_date DESC
    ");
    $stmt->execute($params);
    $completedInterns = $stmt->fetchAll();
    
    // Get unique schools for filter
    $stmt = $pdo->query("
        SELECT DISTINCT school 
        FROM interns 
        WHERE completion_date IS NOT NULL 
        ORDER BY school
    ");
    $schools = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log("Completion report error: " . $e->getMessage());
    $stats = [
        'total_graduated' => 0,
        'pending_graduation' => 0,
        'completed_this_week' => 0,
        'completed_this_month' => 0,
        'avg_hours_completed' => 0,
        'avg_completion_days' => 0
    ];
    $monthlyData = [];
    $completedInterns = [];
    $schools = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internship Completion Report - DICT</title>
    <link rel="stylesheet" href="css/admin-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .report-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
            background: #f8f9fa;
            min-height: 100vh;
        }
        
        .report-header {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .report-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .report-actions {
            display: flex;
            gap: 1rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .chart-section {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .chart-container {
            position: relative;
            height: 400px;
            margin-top: 1rem;
        }
        
        .filters-section {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .filters-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            align-items: end;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
        }
        
        .filter-group label {
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #333;
        }
        
        .data-section {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .export-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .completion-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        
        .completion-table th,
        .completion-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }
        
        .completion-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        .completion-table tbody tr:hover {
            background: #f8f9fa;
        }
        
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .summary-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
        }
        
        .summary-card.green {
            background: linear-gradient(135deg, #28a745, #20c997);
        }
        
        .summary-card.blue {
            background: linear-gradient(135deg, #007bff, #6f42c1);
        }
        
        .summary-card.orange {
            background: linear-gradient(135deg, #ffc107, #fd7e14);
        }
        
        .summary-card.purple {
            background: linear-gradient(135deg, #6f42c1, #e83e8c);
        }
        
        .summary-card h3 {
            margin: 0 0 0.5rem 0;
            font-size: 2rem;
            font-weight: bold;
        }
        
        .summary-card p {
            margin: 0;
            opacity: 0.9;
            font-size: 0.9rem;
        }
        
        @media print {
            .report-actions, .filters-section {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="report-container">
        <div class="report-header">
            <div class="report-title">
                <div>
                    <h1><i class="fas fa-chart-line"></i> Internship Completion Report</h1>
                    <p class="text-muted">Department of Information and Communications Technology</p>
                    <small>Generated on <?php echo date('F j, Y g:i A'); ?> by <?php echo $adminName; ?></small>
                </div>
                <div class="report-actions">
                    <button class="btn-secondary" onclick="window.print()">
                        <i class="fas fa-print"></i> Print Report
                    </button>
                    <button class="btn-primary" onclick="exportToExcel()">
                        <i class="fas fa-download"></i> Export Excel
                    </button>
                    <button class="btn-secondary" onclick="window.close()">
                        <i class="fas fa-times"></i> Close
                    </button>
                </div>
            </div>
        </div>

        <!-- Summary Statistics -->
        <div class="summary-cards">
            <div class="summary-card green">
                <h3><?php echo $stats['total_graduated']; ?></h3>
                <p>Total Graduated</p>
            </div>
            <div class="summary-card orange">
                <h3><?php echo $stats['pending_graduation']; ?></h3>
                <p>Pending Graduation</p>
            </div>
            <div class="summary-card blue">
                <h3><?php echo $stats['completed_this_month']; ?></h3>
                <p>Completed This Month</p>
            </div>
            <div class="summary-card purple">
                <h3><?php echo number_format($stats['avg_hours_completed'], 1); ?></h3>
                <p>Average Hours Completed</p>
            </div>
        </div>

        <!-- Charts Section -->
        <div class="chart-section">
            <h2><i class="fas fa-chart-bar"></i> Completion Trends</h2>
            <div class="chart-container">
                <canvas id="completionChart"></canvas>
            </div>
        </div>

        <!-- Filters Section -->
        <div class="filters-section">
            <h3><i class="fas fa-filter"></i> Filters</h3>
            <form method="GET" id="filterForm">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label for="month">Month</label>
                        <select name="month" id="month" class="form-control">
                            <option value="all">All Months</option>
                            <?php
                            for ($i = 11; $i >= 0; $i--) {
                                $monthValue = date('Y-m', strtotime("-$i months"));
                                $monthLabel = date('F Y', strtotime("-$i months"));
                                $selected = $filterMonth === $monthValue ? 'selected' : '';
                                echo "<option value='$monthValue' $selected>$monthLabel</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="status">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="all" <?php echo $filterStatus === 'all' ? 'selected' : ''; ?>>All Status</option>
                            <option value="completed" <?php echo $filterStatus === 'completed' ? 'selected' : ''; ?>>Completed</option>
                            <option value="graduated" <?php echo $filterStatus === 'graduated' ? 'selected' : ''; ?>>Graduated</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="school">School</label>
                        <select name="school" id="school" class="form-control">
                            <option value="all">All Schools</option>
                            <?php foreach ($schools as $school): ?>
                                <option value="<?php echo htmlspecialchars($school['school']); ?>" 
                                        <?php echo $filterSchool === $school['school'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($school['school']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn-primary">
                            <i class="fas fa-search"></i> Apply Filters
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Data Section -->
        <div class="data-section">
            <div class="export-section">
                <h2><i class="fas fa-table"></i> Completion Details</h2>
                <div>
                    <span class="text-muted">Showing <?php echo count($completedInterns); ?> records</span>
                </div>
            </div>
            
            <div class="table-container">
                <table class="completion-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>School</th>
                            <th>Start Date</th>
                            <th>Completion Date</th>
                            <th>Duration</th>
                            <th>Hours</th>
                            <th>Progress</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($completedInterns)): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted" style="padding: 2rem;">
                                    No completion records found for the selected filters.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($completedInterns as $intern): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($intern['name']); ?></td>
                                    <td><?php echo htmlspecialchars($intern['school']); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($intern['start_date'])); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($intern['completion_date'])); ?></td>
                                    <td><?php echo $intern['completion_days']; ?> days</td>
                                    <td><?php echo number_format($intern['completed_hours'], 1) . '/' . $intern['required_hours']; ?></td>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                                            <div style="flex: 1; background: #e9ecef; border-radius: 4px; height: 8px;">
                                                <div style="width: <?php echo min(100, $intern['completion_percentage']); ?>%; 
                                                           background: <?php echo $intern['completion_percentage'] >= 100 ? '#28a745' : '#007bff'; ?>; 
                                                           height: 100%; border-radius: 4px;"></div>
                                            </div>
                                            <span style="font-size: 0.9rem; color: #666;">
                                                <?php echo number_format($intern['completion_percentage'], 1); ?>%
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo $intern['completion_status']; ?>">
                                            <?php echo ucfirst($intern['completion_status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Chart.js configuration
        const monthlyData = <?php echo json_encode($monthlyData); ?>;
        
        // Prepare chart data
        const labels = monthlyData.map(item => {
            const date = new Date(item.month + '-01');
            return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
        });
        
        const completionData = monthlyData.map(item => parseInt(item.completions));
        const graduatedData = monthlyData.map(item => parseInt(item.graduated));
        const pendingData = monthlyData.map(item => parseInt(item.pending));
        
        // Create chart
        const ctx = document.getElementById('completionChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Total Completions',
                        data: completionData,
                        backgroundColor: 'rgba(54, 162, 235, 0.7)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Graduated',
                        data: graduatedData,
                        backgroundColor: 'rgba(40, 167, 69, 0.7)',
                        borderColor: 'rgba(40, 167, 69, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Pending Graduation',
                        data: pendingData,
                        backgroundColor: 'rgba(255, 193, 7, 0.7)',
                        borderColor: 'rgba(255, 193, 7, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Monthly Completion Trends (Last 12 Months)'
                    },
                    legend: {
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
        
        // Export to Excel function
        function exportToExcel() {
            const table = document.querySelector('.completion-table');
            const rows = Array.from(table.querySelectorAll('tr'));
            
            let csv = '';
            rows.forEach(row => {
                const cols = Array.from(row.querySelectorAll('th, td'));
                const csvRow = cols.map(col => {
                    let text = col.textContent.trim();
                    // Clean up progress column
                    if (text.includes('%') && text.includes('/')) {
                        text = text.split(' ').pop(); // Just get the percentage
                    }
                    return '"' + text.replace(/"/g, '""') + '"';
                }).join(',');
                csv += csvRow + '\n';
            });
            
            // Add BOM for Excel UTF-8 support
            const BOM = '\uFEFF';
            const blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8;' });
            
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', `internship_completion_report_${new Date().toISOString().split('T')[0]}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
        
        // Auto-submit form when filters change
        document.querySelectorAll('#filterForm select').forEach(select => {
            select.addEventListener('change', () => {
                document.getElementById('filterForm').submit();
            });
        });
    </script>
</body>
</html> 