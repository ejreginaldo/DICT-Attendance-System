<?php
session_start();
require_once 'config/database.php';

// Verify if user is logged in as admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

// Get admin name from session
$adminName = htmlspecialchars($_SESSION['user_name'] ?? 'Admin');

// Fetch employees data
try {
    $stmt = $pdo->query("
        SELECT 
            e.*,
            (SELECT COUNT(*) FROM attendance_logs 
             WHERE user_type = 'employee' AND user_id = e.id 
             AND date = CURRENT_DATE) as present_today
        FROM employees e
        ORDER BY e.status ASC, e.name ASC
    ");
    $employees = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Error fetching employees: " . $e->getMessage());
    $employees = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Management - DICT Admin</title>
    <link rel="stylesheet" href="css/admin-dashboard.css">
    <link rel="stylesheet" href="css/employee-management.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header>
        <div class="logo-left">
            <a href="admin-dashboard.php">
                <img src="img/dict-logo.png" alt="DICT Logo" class="header-logo">
            </a>
        </div>

        <div class="header-content">
            <h1>Employee Management</h1>
            <div class="subheading">Department of Information and Communications Technology | ILCDB</div>
        </div>

        <div class="profile-dropdown">
            <img src="img/profile.png" id="profileButton" alt="Profile" class="profile-img">
            <div id="dropdownMenu" class="dropdown-content">
                <div class="admin-info">
                    <i class="fas fa-user-shield"></i>
                    <span>Welcome, <strong><?php echo $adminName; ?></strong></span>
                </div>
                <a href="#" onclick="openChangePinModal()"><i class="fas fa-key"></i>Change PIN</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
            </div>
        </div>
    </header>

    <nav class="dashboard-nav">
        <a href="admin-dashboard.php" class="nav-item">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </a>
        <a href="interns.php" class="nav-item">
            <i class="fas fa-users"></i>
            <span>Interns</span>
        </a>
        <div class="nav-item active">
            <i class="fas fa-user-tie"></i>
            <span>Employees</span>
        </div>
    </nav>

    <main class="dashboard-layout">
        <div class="dashboard-card full-width">
            <div class="card-header">
                <h2><i class="fas fa-user-tie"></i> Employees List</h2>
                <div class="card-actions">
                    <input type="text" placeholder="Search employees..." class="search-input" id="searchEmployees">
                    <select class="filter-select" id="statusFilter">
                        <option value="all">All Employees</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>

                    <button class="action-btn primary" onclick="openRegisterModal()">
                        <i class="fas fa-user-plus"></i>
                        Register New Employee
                    </button>
                </div>
            </div>
            <div class="table-container">
                <table class="attendance-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Position</th>
                            <th>Department</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="employeesData">
                        <?php foreach ($employees as $employee): ?>
                            <tr data-status="<?php echo htmlspecialchars($employee['status']); ?>">
                                <td><?php echo htmlspecialchars($employee['name']); ?></td>
                                <td><?php echo htmlspecialchars($employee['position']); ?></td>
                                <td><?php echo htmlspecialchars($employee['department']); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $employee['status']; ?>">
                                        <?php echo ucfirst($employee['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="action-btn" onclick="viewEmployee(<?php echo $employee['id']; ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="action-btn" onclick="editEmployee(<?php echo $employee['id']; ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="action-btn" onclick="toggleStatus(<?php echo $employee['id']; ?>)">
                                        <?php if ($employee['status'] === 'active'): ?>
                                            <i class="fas fa-user-slash"></i>
                                        <?php else: ?>
                                            <i class="fas fa-user-check"></i>
                                        <?php endif; ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Register Employee Modal -->
    <div id="registerModal" class="modal">
        <div class="modal-content modal-wide">
            <div class="modal-header">
                <h2><i class="fas fa-user-plus"></i> Register New Employee</h2>
                <button class="close-btn" onclick="closeModal('registerModal')"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <form id="registerEmployeeForm" method="POST" action="register_employee.php">
                    
                    <div class="form-grid">
                        <div class="form-section">
                            <h3><i class="fas fa-user"></i> Personal Information</h3>
                            <div class="form-group">
                                <label for="name"><i class="fas fa-user"></i> Full Name</label>
                                <input type="text" id="name" name="name" required placeholder="Enter full name">
                            </div>
                            <div class="form-group">
                                <label for="position"><i class="fas fa-briefcase"></i> Position</label>
                                <input type="text" id="position" name="position" required placeholder="Enter job position">
                            </div>
                            <div class="form-group">
                                <label for="department"><i class="fas fa-building"></i> Department</label>
                                <input type="text" id="department" name="department" required placeholder="Enter department">
                            </div>
                        </div>

                        <div class="form-section">
                            <h3><i class="fas fa-id-card"></i> Card Information</h3>
                            <div class="form-group">
                                <label for="card_uid"><i class="fas fa-id-card"></i> NFC Card UID</label>
                                <input type="text" id="card_uid" name="card_uid" required placeholder="Enter card UID">
                            </div>
                            <div class="form-group">
                                <small class="form-note">
                                    <i class="fas fa-info-circle"></i>
                                    Employees only need their NFC card for attendance tracking. No PIN required.
                                </small>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('registerModal')">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="submit" form="registerEmployeeForm" class="btn-primary">
                    <i class="fas fa-user-plus"></i> Register Employee
                </button>
            </div>
        </div>
    </div>

    <!-- Change PIN Modal -->
    <div id="changePinModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-key"></i> Change PIN</h2>
                <button class="close-btn" onclick="closeModal('changePinModal')"><i class="fas fa-times"></i></button>
            </div>
            <form id="changePinForm">
                <div class="form-group">
                    <label for="currentPin">Current PIN</label>
                    <input type="password" id="currentPin" name="currentPin" minlength="4" maxlength="6" required>
                </div>
                <div class="form-group">
                    <label for="newPin">New PIN</label>
                    <input type="password" id="newPin" name="newPin" minlength="4" maxlength="6" required>
                </div>
                <div class="form-group">
                    <label for="confirmPin">Confirm New PIN</label>
                    <input type="password" id="confirmPin" name="confirmPin" minlength="4" maxlength="6" required>
                </div>
                <div class="form-actions">
                    <button type="button" class="cancel-btn" onclick="closeModal('changePinModal')">Cancel</button>
                    <button type="submit" class="save-btn">Update PIN</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Employee Details Modal -->
    <div id="employeeDetailsModal" class="modal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h2><i class="fas fa-user-tie"></i> Employee Details</h2>
                <button class="close-btn" onclick="closeModal('employeeDetailsModal')"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <div class="details-grid">
                    <div class="detail-section">
                        <h3><i class="fas fa-user"></i> Personal Information</h3>
                        <div class="detail-item">
                            <label>Name:</label>
                            <span id="employeeDetailName">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Position:</label>
                            <span id="employeeDetailPosition">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Department:</label>
                            <span id="employeeDetailDepartment">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Card UID:</label>
                            <span id="employeeDetailCardUid">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Status:</label>
                            <span id="employeeDetailStatus" class="status-badge">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Employee ID:</label>
                            <span id="employeeDetailId">-</span>
                        </div>
                    </div>

                    <div class="detail-section">
                        <h3><i class="fas fa-calendar-check"></i> Attendance Summary</h3>
                        <div class="detail-item">
                            <label>Total Days Present:</label>
                            <span id="employeeDetailTotalDays">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Total Hours Worked:</label>
                            <span id="employeeDetailTotalHours">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Average Hours/Day:</label>
                            <span id="employeeDetailAvgHours">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Last Attendance:</label>
                            <span id="employeeDetailLastAttendance">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Attendance Rate:</label>
                            <span id="employeeDetailAttendanceRate">-</span>
                        </div>
                    </div>

                    <div class="detail-section full-width">
                        <h3><i class="fas fa-clock"></i> Today's Attendance</h3>
                        <div class="detail-item">
                            <label>Present Today:</label>
                            <span id="employeeDetailPresentToday">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Time In:</label>
                            <span id="employeeDetailTimeIn">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Time Out:</label>
                            <span id="employeeDetailTimeOut">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Today's Status:</label>
                            <span id="employeeDetailTodayStatus" class="status-badge">-</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-secondary" onclick="closeModal('employeeDetailsModal')">Close</button>
                <button class="btn-primary" onclick="viewEmployeeAttendanceHistory(getCurrentEmployeeId())">
                    <i class="fas fa-history"></i> View History
                </button>
            </div>
        </div>
    </div>

    <!-- Edit Employee Modal -->
    <div id="editEmployeeModal" class="modal">
        <div class="modal-content modal-wide">
            <div class="modal-header">
                <h2><i class="fas fa-user-edit"></i> Edit Employee Information</h2>
                <button class="close-btn" onclick="closeModal('editEmployeeModal')"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <form id="editEmployeeForm">
                    <input type="hidden" id="editEmployeeId" name="employee_id">
                    
                    <div class="form-grid">
                        <div class="form-section">
                            <h3><i class="fas fa-user"></i> Personal Information</h3>
                            <div class="form-group">
                                <label for="editName"><i class="fas fa-user"></i> Full Name</label>
                                <input type="text" id="editName" name="name" required placeholder="Enter full name">
                            </div>
                            <div class="form-group">
                                <label for="editPosition"><i class="fas fa-briefcase"></i> Position</label>
                                <input type="text" id="editPosition" name="position" required placeholder="Enter job position">
                            </div>
                            <div class="form-group">
                                <label for="editDepartment"><i class="fas fa-building"></i> Department</label>
                                <input type="text" id="editDepartment" name="department" required placeholder="Enter department">
                            </div>
                        </div>

                        <div class="form-section">
                            <h3><i class="fas fa-id-card"></i> Card Information</h3>
                            <div class="form-group">
                                <label for="editCardUid"><i class="fas fa-id-card"></i> NFC Card UID</label>
                                <input type="text" id="editCardUid" name="card_uid" required placeholder="Enter card UID">
                            </div>
                            <div class="form-group">
                                <label for="editStatus"><i class="fas fa-toggle-on"></i> Status</label>
                                <select id="editStatus" name="status" required>
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <small class="form-note">
                                    <i class="fas fa-info-circle"></i>
                                    Employees use NFC cards for attendance tracking only.
                                </small>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('editEmployeeModal')">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="submit" form="editEmployeeForm" class="btn-primary">
                    <i class="fas fa-save"></i> Update Employee
                </button>
            </div>
        </div>
    </div>

    <footer>
        &copy; 2025 DICT &bull; Reginaldo &bull; Tesorero | All rights reserved
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Profile dropdown
            const profileButton = document.getElementById('profileButton');
            const dropdownMenu = document.getElementById('dropdownMenu');

            profileButton.addEventListener('click', function() {
                dropdownMenu.classList.toggle('show');
            });

            // Close dropdown when clicking outside
            window.addEventListener('click', function(e) {
                if (!e.target.matches('#profileButton')) {
                    if (dropdownMenu.classList.contains('show')) {
                        dropdownMenu.classList.remove('show');
                    }
                }
            });

            // Search functionality
            const searchInput = document.getElementById('searchEmployees');
            const statusFilter = document.getElementById('statusFilter');
            const rows = document.querySelectorAll('#employeesData tr');

            function filterTable() {
                const searchTerm = searchInput.value.toLowerCase();
                const statusValue = statusFilter.value;

                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    const status = row.dataset.status;
                    const matchesSearch = text.includes(searchTerm);
                    const matchesStatus = statusValue === 'all' || status === statusValue;

                    row.style.display = matchesSearch && matchesStatus ? '' : 'none';
                });
            }

            searchInput.addEventListener('input', filterTable);
            statusFilter.addEventListener('change', filterTable);

            // Handle PIN change form submission
            const changePinForm = document.getElementById('changePinForm');
            if (changePinForm) {
                changePinForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const currentPin = document.getElementById('currentPin').value;
                    const newPin = document.getElementById('newPin').value;
                    const confirmPin = document.getElementById('confirmPin').value;
                    
                    if (newPin !== confirmPin) {
                        alert('New PIN and Confirm PIN do not match!');
                        return;
                    }
                    
                    // Show loading state
                    const submitBtn = e.target.querySelector('.save-btn');
                    if (submitBtn) {
                        submitBtn.disabled = true;
                        submitBtn.textContent = 'Updating...';
                    }
                    
                    fetch('change_pin.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify({
                            currentPin: currentPin,
                            newPin: newPin
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('PIN updated successfully!');
                            closeModal('changePinModal');
                        } else {
                            alert(data.message || 'Failed to update PIN. Please try again.');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while updating PIN. Please try again.');
                    })
                    .finally(() => {
                        // Reset button state
                        if (submitBtn) {
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'Update PIN';
                        }
                    });
                });
            }
        });

        function openRegisterModal() {
            document.getElementById('registerModal').style.display = 'flex';
            document.getElementById('registerEmployeeForm').reset();
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function openChangePinModal() {
            document.getElementById('changePinModal').style.display = 'flex';
            const changePinForm = document.getElementById('changePinForm');
            if (changePinForm) {
                changePinForm.reset();
            }
        }



        let currentEmployeeId = null;

        function getCurrentEmployeeId() {
            return currentEmployeeId;
        }

        function viewEmployee(id) {
            currentEmployeeId = id;
            console.log('Fetching employee details for ID:', id);
            
            // Fetch employee details
            fetch(`get_employee_details.php?id=${id}`)
                .then(response => {
                    console.log('Response status:', response.status);
                    return response.text().then(text => {
                        console.log('Raw response:', text);
                        try {
                            return JSON.parse(text);
                        } catch (e) {
                            console.error('JSON parse error:', e);
                            throw new Error('Invalid JSON response: ' + text);
                        }
                    });
                })
                .then(data => {
                    console.log('Parsed data:', data);
                    if (data.success) {
                        populateEmployeeDetails(data.employee);
                        document.getElementById('employeeDetailsModal').style.display = 'flex';
                    } else {
                        alert(data.message || 'Failed to fetch employee details.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while fetching employee details: ' + error.message);
                });
        }

        function populateEmployeeDetails(employee) {
            document.getElementById('employeeDetailName').textContent = employee.name || '-';
            document.getElementById('employeeDetailPosition').textContent = employee.position || '-';
            document.getElementById('employeeDetailDepartment').textContent = employee.department || '-';
            document.getElementById('employeeDetailCardUid').textContent = employee.card_uid || '-';
            document.getElementById('employeeDetailId').textContent = employee.id || '-';
            
            const statusBadge = document.getElementById('employeeDetailStatus');
            statusBadge.textContent = employee.status ? employee.status.charAt(0).toUpperCase() + employee.status.slice(1) : '-';
            statusBadge.className = `status-badge ${employee.status || ''}`;
            
            // Attendance summary
            document.getElementById('employeeDetailTotalDays').textContent = employee.total_days || '0';
            document.getElementById('employeeDetailTotalHours').textContent = employee.total_hours || '0';
            document.getElementById('employeeDetailAvgHours').textContent = employee.avg_hours || '0';
            document.getElementById('employeeDetailLastAttendance').textContent = employee.last_attendance || 'Never';
            document.getElementById('employeeDetailAttendanceRate').textContent = employee.attendance_rate || '0%';
            
            // Today's attendance
            document.getElementById('employeeDetailPresentToday').textContent = employee.present_today ? 'Yes' : 'No';
            document.getElementById('employeeDetailTimeIn').textContent = employee.time_in || '-';
            document.getElementById('employeeDetailTimeOut').textContent = employee.time_out || '-';
            
            const todayStatusBadge = document.getElementById('employeeDetailTodayStatus');
            todayStatusBadge.textContent = employee.today_status || 'Not Present';
            todayStatusBadge.className = `status-badge ${employee.today_status_class || ''}`;
        }

        function editEmployee(id) {
            currentEmployeeId = id;
            console.log('Fetching employee details for editing, ID:', id);
            
            // Fetch employee details for editing
            fetch(`get_employee_details.php?id=${id}`)
                .then(response => {
                    console.log('Edit response status:', response.status);
                    return response.text().then(text => {
                        console.log('Edit raw response:', text);
                        try {
                            return JSON.parse(text);
                        } catch (e) {
                            console.error('Edit JSON parse error:', e);
                            throw new Error('Invalid JSON response: ' + text);
                        }
                    });
                })
                .then(data => {
                    console.log('Edit parsed data:', data);
                    if (data.success) {
                        populateEditForm(data.employee);
                        document.getElementById('editEmployeeModal').style.display = 'flex';
                    } else {
                        alert(data.message || 'Failed to fetch employee details.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while fetching employee details: ' + error.message);
                });
        }

        function populateEditForm(employee) {
            document.getElementById('editEmployeeId').value = employee.id || '';
            document.getElementById('editName').value = employee.name || '';
            document.getElementById('editPosition').value = employee.position || '';
            document.getElementById('editDepartment').value = employee.department || '';
            document.getElementById('editCardUid').value = employee.card_uid || '';
            document.getElementById('editStatus').value = employee.status || 'active';
        }

        function viewEmployeeAttendanceHistory(id) {
            // TODO: Implement attendance history view
            alert('Employee attendance history view will be implemented soon!');
        }

        function toggleStatus(id) {
            if (confirm('Are you sure you want to change this employee\'s status?')) {
                fetch('toggle_employee_status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({ id: id })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    } else {
                        alert(data.message || 'Failed to update status. Please try again.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while updating status. Please try again.');
                });
            }
        }

        // Handle employee registration form submission
        document.getElementById('registerEmployeeForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('register_employee.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    closeModal('registerModal');
                    // Reload the page to show the new employee
                    window.location.reload();
                } else {
                    alert(data.message || 'Failed to register employee. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while registering the employee. Please try again.');
            });
        });

        // Handle edit employee form submission
        document.getElementById('editEmployeeForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('update_employee.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    closeModal('editEmployeeModal');
                    // Reload the page to show the updated employee
                    window.location.reload();
                } else {
                    alert(data.message || 'Failed to update employee. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating the employee. Please try again.');
            });
        });
    </script>
</body>
</html> 