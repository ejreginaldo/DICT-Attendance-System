<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

// Verify admin is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

try {
    // Get recent completion notifications
    $stmt = $pdo->prepare("
        SELECT 
            cn.id,
            cn.intern_id,
            cn.completion_date,
            cn.notification_read,
            cn.created_at,
            i.name as intern_name,
            i.school,
            i.required_hours,
            i.completed_hours,
            i.completion_status
        FROM completion_notifications cn
        JOIN interns i ON cn.intern_id = i.id
        ORDER BY cn.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $notifications = $stmt->fetchAll();
    
    // Get count of unread notifications
    $stmt = $pdo->query("
        SELECT COUNT(*) as unread_count 
        FROM completion_notifications 
        WHERE notification_read = FALSE
    ");
    $unreadCount = $stmt->fetch()['unread_count'];
    
    // Get completion statistics - separate graduated from completed
    $stmt = $pdo->query("
        SELECT 
            (SELECT COUNT(*) FROM interns WHERE completion_status = 'graduated') as total_completed,
            COUNT(CASE WHEN completion_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN 1 END) as completed_this_week,
            COUNT(CASE WHEN completion_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) THEN 1 END) as completed_this_month
        FROM interns 
        WHERE completion_status IN ('completed', 'graduated')
    ");
    $completionStats = $stmt->fetch();
    
    echo json_encode([
        'success' => true,
        'notifications' => $notifications,
        'unread_count' => (int)$unreadCount,
        'completion_stats' => $completionStats
    ]);
    
} catch (PDOException $e) {
    error_log("Admin notifications error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to fetch notifications']);
}
?> 