<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

// Verify if user is logged in as intern
if (!isset($_SESSION['intern_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

try {
    // Get intern's required hours
    $stmt = $pdo->prepare("SELECT required_hours FROM interns WHERE id = ? AND status = 'active'");
    $stmt->execute([$_SESSION['intern_id']]);
    $intern = $stmt->fetch();
    
    if (!$intern) {
        throw new Exception('Intern not found');
    }
    
    // Calculate total completed hours from intern daily reports
    // Only count dates up to today to prevent future date inflation
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(hours_rendered), 0) as completed_hours
        FROM intern_daily_reports
        WHERE intern_id = ?
        AND date <= CURDATE()
        AND hours_rendered > 0
    ");
    $stmt->execute([$_SESSION['intern_id']]);
    $result = $stmt->fetch();
    
    $completedHours = floatval($result['completed_hours']);
    $requiredHours = floatval($intern['required_hours']);
    
    // Update the intern's completed_hours field in the database
    $stmt = $pdo->prepare("
        UPDATE interns 
        SET completed_hours = ? 
        WHERE id = ?
    ");
    $stmt->execute([$completedHours, $_SESSION['intern_id']]);
    
    // Check for completion and update status if needed
    if ($completedHours >= $requiredHours) {
        $stmt = $pdo->prepare("
            SELECT completion_status FROM interns WHERE id = ? AND status = 'active'
        ");
        $stmt->execute([$_SESSION['intern_id']]);
        $currentStatus = $stmt->fetchColumn();
        
        if ($currentStatus != 'completed') {
            // Update completion status
            $stmt = $pdo->prepare("
                UPDATE interns 
                SET completion_status = 'completed', completion_date = CURDATE()
                WHERE id = ?
            ");
            $stmt->execute([$_SESSION['intern_id']]);
            
            // Create completion notification
            $stmt = $pdo->prepare("
                INSERT IGNORE INTO completion_notifications (intern_id, completion_date, notification_read, created_at)
                VALUES (?, CURDATE(), FALSE, NOW())
            ");
            $stmt->execute([$_SESSION['intern_id']]);
            
            error_log("Intern {$_SESSION['intern_id']} completed their internship via get_completed_hours!");
        }
    }
    
    echo json_encode([
        'success' => true,
        'completed_hours' => $completedHours,
        'required_hours' => $requiredHours,
        'progress_percentage' => $requiredHours > 0 ? min(100, ($completedHours / $requiredHours) * 100) : 0
    ]);

} catch (Exception $e) {
    error_log("Get completed hours error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Failed to calculate completed hours',
        'debug' => $e->getMessage()
    ]);
}
?> 