<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

// Verify if user is logged in as intern
if (!isset($_SESSION['intern_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Invalid JSON input');
    }
    
    $endDate = $input['endDate'] ?? null;
    $weekNumber = $input['weekNumber'] ?? 1;
    
    if (!$endDate) {
        throw new Exception('End date is required');
    }
    
    // Get cumulative completed hours from intern daily reports up to the specified end date
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(hours_rendered), 0) as completed_hours
        FROM intern_daily_reports
        WHERE intern_id = ?
        AND date <= ?
    ");
    $stmt->execute([$_SESSION['intern_id'], $endDate]);
    $result = $stmt->fetch();
    
    $completedHours = floatval($result['completed_hours']);
    
    echo json_encode([
        'success' => true,
        'completed_hours' => $completedHours,
        'completed_hours_formatted' => [
            'hours' => floor($completedHours),
            'minutes' => round(($completedHours - floor($completedHours)) * 60)
        ],
        'week_number' => $weekNumber,
        'end_date' => $endDate
    ]);
    
} catch (Exception $e) {
    error_log("Get cumulative hours error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to fetch cumulative hours: ' . $e->getMessage()
    ]);
}
?> 