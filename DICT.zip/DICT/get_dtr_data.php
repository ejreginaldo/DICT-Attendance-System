<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

// Verify if user is logged in as intern
if (!isset($_SESSION['intern_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Invalid JSON input');
    }
    
    $startDate = $input['startDate'] ?? null;
    $endDate = $input['endDate'] ?? null;
    
    if (!$startDate || !$endDate) {
        throw new Exception('Start date and end date are required');
    }
    
    // Get intern details
    $stmt = $pdo->prepare("
        SELECT 
            id,
            name,
            school,
            start_date,
            required_hours,
            completed_hours,
            status
        FROM interns 
        WHERE id = ?
    ");
    $stmt->execute([$_SESSION['intern_id']]);
    $intern = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$intern) {
        throw new Exception('Intern not found');
    }
    
    // Add default supervisor name
    $intern['supervisor_name'] = 'Mr. Edd Fernan D. Gonzales';
    
    // Calculate total hours completed BEFORE the selected month
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(hours_rendered), 0) as hours_before_month
        FROM intern_daily_reports
        WHERE intern_id = ?
        AND date < ?
        AND hours_rendered > 0
    ");
    $stmt->execute([$_SESSION['intern_id'], $startDate]);
    $hoursBeforeResult = $stmt->fetch(PDO::FETCH_ASSOC);
    $hoursBeforeMonth = floatval($hoursBeforeResult['hours_before_month'] ?? 0);
    
    // Check if work_mode column exists (like in old file)
    $stmt = $pdo->query("SHOW COLUMNS FROM intern_daily_reports LIKE 'work_mode'");
    $hasWorkMode = $stmt->rowCount() > 0;
    
    // Build the query dynamically based on available columns (like old file)
    $workModeSelect = $hasWorkMode ? "COALESCE(work_mode, 'office') as work_mode," : "'office' as work_mode,";
    
    // Debug: Log the date range being queried
    error_log("DTR Query - Intern ID: {$_SESSION['intern_id']}, Start: $startDate, End: $endDate");
    
    // Get ALL DTR data from intern_daily_reports for the ENTIRE month specified
    $stmt = $pdo->prepare("
        SELECT 
            date,
            DATE_FORMAT(date, '%M %d, %Y') as formatted_date,
            DATE_FORMAT(date, '%m/%d/%Y') as short_date,
            time_in,
            time_out,
            COALESCE(hours_rendered, 0) as hours_rendered,
            COALESCE(tasks_done, '') as tasks_done,
            $workModeSelect
            CASE 
                WHEN time_in IS NOT NULL THEN DATE_FORMAT(time_in, '%h:%i %p')
                ELSE ''
            END as formatted_time_in,
            CASE 
                WHEN time_out IS NOT NULL THEN DATE_FORMAT(time_out, '%h:%i %p')
                ELSE ''
            END as formatted_time_out
        FROM intern_daily_reports
        WHERE intern_id = ?
        AND date >= ?
        AND date <= ?
        ORDER BY date ASC
    ");
    $stmt->execute([$_SESSION['intern_id'], $startDate, $endDate]);
    $allData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Debug: Log how many records were found
    error_log("DTR Query Results - Found " . count($allData) . " records for date range $startDate to $endDate");
    
    // Filter out holidays, absences, blank entries, and weekend/non-working days (like old file)
    $dtrData = array_filter($allData, function($record) {
        // Exclude if work mode is holiday, absent, or leave
        if (in_array($record['work_mode'], ['holiday', 'absent', 'leave'])) {
            return false;
        }
        
        // Exclude if no time data (both time_in and time_out are null or empty)
        if (empty($record['time_in']) && empty($record['time_out'])) {
            return false;
        }
        
        // Exclude if hours_rendered is 0 or null and no valid time data
        if (($record['hours_rendered'] == 0 || is_null($record['hours_rendered'])) && 
            (empty($record['time_in']) || empty($record['time_out']))) {
            return false;
        }
        
        return true;
    });
    
    // Re-index the array to have sequential indices
    $dtrData = array_values($dtrData);
    
    // Debug: Log which dates are included after filtering
    $includedDates = array_map(function($record) { return $record['date']; }, $dtrData);
    error_log("DTR Filtered Results - Included dates: " . implode(', ', $includedDates));
    
    // Calculate totals (only for filtered working days)
    $totalHours = 0;
    $totalDays = count($dtrData); // Total DTR entries (only working days)
    $workingDays = 0;
    
    foreach ($dtrData as $record) {
        $totalHours += floatval($record['hours_rendered']);
        if ($record['hours_rendered'] > 0) {
            $workingDays++;
        }
    }
    
    // Format totals
    $totalHoursFormatted = [
        'hours' => floor($totalHours),
        'minutes' => round(($totalHours - floor($totalHours)) * 60),
        'decimal' => number_format($totalHours, 2)
    ];
    
    echo json_encode([
        'success' => true,
        'intern' => $intern,
        'dtrData' => $dtrData,
        'hoursBeforeMonth' => $hoursBeforeMonth,
        'totals' => [
            'total_hours' => $totalHoursFormatted,
            'total_days' => $totalDays,
            'working_days' => $workingDays
        ],
        'period' => [
            'start_date' => $startDate,
            'end_date' => $endDate,
            'formatted_start' => date('F j, Y', strtotime($startDate)),
            'formatted_end' => date('F j, Y', strtotime($endDate))
        ],
        'debug' => [
            'raw_data_count' => count($allData),
            'filtered_data_count' => count($dtrData),
            'start_date' => $startDate,
            'end_date' => $endDate,
            'first_date' => count($dtrData) > 0 ? $dtrData[0]['date'] : 'none',
            'last_date' => count($dtrData) > 0 ? $dtrData[count($dtrData)-1]['date'] : 'none'
        ]
    ]);
    
} catch (Exception $e) {
    error_log("Get DTR data error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to fetch DTR data: ' . $e->getMessage(),
        'debug' => [
            'error_details' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile()
        ]
    ]);
}
?> 