<?php
session_start();
require_once 'config/database.php';

// Disable error output to prevent JSON corruption
error_reporting(0);
ini_set('display_errors', 0);

// Set content type to JSON
header('Content-Type: application/json');

// Verify if user is logged in as admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Get employee ID from request
$employee_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($employee_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid employee ID']);
    exit();
}

try {
    // Fetch employee basic information
    $stmt = $pdo->prepare("
        SELECT 
            e.*,
            (SELECT COUNT(*) FROM attendance_logs 
             WHERE user_type = 'employee' AND user_id = e.id 
             AND date = CURRENT_DATE) as present_today
        FROM employees e
        WHERE e.id = ?
    ");
    $stmt->execute([$employee_id]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$employee) {
        echo json_encode(['success' => false, 'message' => 'Employee not found']);
        exit();
    }

    // Calculate attendance statistics
    $stats_stmt = $pdo->prepare("
        SELECT 
            COUNT(DISTINCT date) as total_days,
            SUM(CASE WHEN time_out IS NOT NULL THEN 
                TIMESTAMPDIFF(HOUR, time_in, time_out) 
                ELSE 0 END) as total_hours,
            MAX(date) as last_attendance,
            AVG(CASE WHEN time_out IS NOT NULL THEN 
                TIMESTAMPDIFF(HOUR, time_in, time_out) 
                ELSE 0 END) as avg_hours
        FROM attendance_logs 
        WHERE user_type = 'employee' AND user_id = ?
    ");
    $stats_stmt->execute([$employee_id]);
    $stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

    // Get today's attendance details
    $today_stmt = $pdo->prepare("
        SELECT 
            time_in,
            time_out,
            CASE 
                WHEN time_in IS NULL THEN 'absent'
                WHEN TIME(time_in) <= '08:00:00' AND time_out IS NOT NULL AND TIME(time_out) >= '17:00:00' THEN 'on_time'
                WHEN TIME(time_in) > '08:00:00' THEN 'late'
                WHEN time_out IS NOT NULL AND TIME(time_out) < '17:00:00' THEN 'early_departure'
                ELSE 'present'
            END as today_status
        FROM attendance_logs 
        WHERE user_type = 'employee' AND user_id = ? AND date = CURRENT_DATE
        ORDER BY time_in DESC 
        LIMIT 1
    ");
    $today_stmt->execute([$employee_id]);
    $today = $today_stmt->fetch(PDO::FETCH_ASSOC);

    // Calculate attendance rate (assuming 30 working days per month)
    $working_days = 30; // You can adjust this based on your business logic
    $attendance_rate = ($stats['total_days'] && $stats['total_days'] > 0) ? min(100, ($stats['total_days'] / $working_days) * 100) : 0;

    // Safely handle the stats data
    $total_days = isset($stats['total_days']) ? $stats['total_days'] : 0;
    $total_hours = isset($stats['total_hours']) ? $stats['total_hours'] : 0;
    $avg_hours = isset($stats['avg_hours']) ? $stats['avg_hours'] : 0;
    $last_attendance = isset($stats['last_attendance']) && $stats['last_attendance'] ? date('M d, Y', strtotime($stats['last_attendance'])) : 'Never';

    // Safely handle today's data
    $time_in = (isset($today['time_in']) && $today['time_in']) ? date('h:i A', strtotime($today['time_in'])) : null;
    $time_out = (isset($today['time_out']) && $today['time_out']) ? date('h:i A', strtotime($today['time_out'])) : null;
    $today_status = isset($today['today_status']) ? $today['today_status'] : 'absent';

    // Combine all data
    $employee_data = array_merge($employee, [
        'total_days' => $total_days,
        'total_hours' => round($total_hours, 1),
        'avg_hours' => round($avg_hours, 1),
        'last_attendance' => $last_attendance,
        'attendance_rate' => round($attendance_rate, 1) . '%',
        'time_in' => $time_in,
        'time_out' => $time_out,
        'today_status' => $today_status,
        'today_status_class' => $today_status
    ]);

    echo json_encode(['success' => true, 'employee' => $employee_data]);

} catch (PDOException $e) {
    error_log("Error fetching employee details: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} catch (Exception $e) {
    error_log("General error fetching employee details: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?> 