<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

// Verify if user is logged in as admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Check if intern_id is provided
if (!isset($_GET['intern_id']) || empty($_GET['intern_id'])) {
    echo json_encode(['success' => false, 'message' => 'Intern ID is required']);
    exit();
}

$intern_id = intval($_GET['intern_id']);

if ($intern_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid intern ID']);
    exit();
}

try {
    // First, verify the intern exists
    $stmt = $pdo->prepare("SELECT name FROM interns WHERE id = ?");
    $stmt->execute([$intern_id]);
    $intern = $stmt->fetch();
    
    if (!$intern) {
        echo json_encode(['success' => false, 'message' => 'Intern not found']);
        exit();
    }
    
    // Get attendance records for the intern
    $stmt = $pdo->prepare("
        SELECT 
            date,
            TIME_FORMAT(time_in, '%h:%i %p') as time_in,
            TIME_FORMAT(time_out, '%h:%i %p') as time_out,
            total_hours,
            status
        FROM attendance_logs 
        WHERE user_type = 'intern' AND user_id = ?
        ORDER BY date DESC
    ");
    $stmt->execute([$intern_id]);
    $records = $stmt->fetchAll();
    
    // Calculate statistics
    $total_days = count($records);
    $present_days = $total_days; // All records mean they were present
    $total_hours = 0;
    
    foreach ($records as $record) {
        if ($record['total_hours']) {
            $total_hours += floatval($record['total_hours']);
        }
    }
    
    // Calculate attendance rate (assuming they should attend every day since start)
    $stmt = $pdo->prepare("
        SELECT 
            start_date,
            DATEDIFF(CURRENT_DATE, start_date) + 1 as total_possible_days
        FROM interns 
        WHERE id = ?
    ");
    $stmt->execute([$intern_id]);
    $intern_info = $stmt->fetch();
    
    $total_possible_days = max(1, $intern_info['total_possible_days']);
    $attendance_rate = ($present_days / $total_possible_days) * 100;
    
    // Prepare statistics
    $stats = [
        'total_days' => $total_days,
        'present_days' => $present_days,
        'total_hours' => $total_hours,
        'attendance_rate' => min(100, $attendance_rate) // Cap at 100%
    ];
    
    echo json_encode([
        'success' => true,
        'records' => $records,
        'stats' => $stats
    ]);
    
} catch (PDOException $e) {
    error_log("Get intern attendance history error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error occurred']);
}
?> 