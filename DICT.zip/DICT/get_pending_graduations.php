<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

// Verify admin is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

try {
    // Get interns who have completed their requirements but haven't been graduated
    $stmt = $pdo->query("
        SELECT 
            id,
            name,
            school,
            required_hours,
            completed_hours,
            completion_date,
            completion_status,
            start_date
        FROM interns
        WHERE completion_status = 'completed'
        AND status = 'active'
        ORDER BY completion_date DESC
    ");
    $pendingInterns = $stmt->fetchAll();

    // Get count for quick stat
    $pendingCount = count($pendingInterns);

    echo json_encode([
        'success' => true,
        'interns' => $pendingInterns,
        'pending_count' => $pendingCount
    ]);

} catch (PDOException $e) {
    error_log("Pending graduations error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to fetch pending graduations']);
}
?> 