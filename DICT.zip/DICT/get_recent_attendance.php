<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

try {
    $today = date('Y-m-d');
    
    // Get recent attendance with user details
    $stmt = $pdo->prepare("
        SELECT 
            a.id,
            CASE 
                WHEN a.user_type = 'intern' THEN i.name
                WHEN a.user_type = 'employee' THEN e.name
            END as name,
            a.user_type as role,
            DATE_FORMAT(a.date, '%M %d, %Y') as date,
            TIME_FORMAT(a.time_in, '%h:%i %p') as time_in,
            TIME_FORMAT(a.time_out, '%h:%i %p') as time_out,
            a.status,
            a.created_at
        FROM attendance_logs a
        LEFT JOIN interns i ON a.user_type = 'intern' AND a.user_id = i.id
        LEFT JOIN employees e ON a.user_type = 'employee' AND a.user_id = e.id
        WHERE a.date = ?
        ORDER BY a.created_at DESC, a.time_in DESC
        LIMIT 10
    ");
    $stmt->execute([$today]);
    $recentAttendance = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Also get updated statistics
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT user_id) as total,
               SUM(CASE WHEN status = 'on_time' THEN 1 ELSE 0 END) as on_time,
               SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late
        FROM attendance_logs 
        WHERE date = ?
    ");
    $stmt->execute([$today]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'attendance' => $recentAttendance,
        'stats' => [
            'total' => $stats['total'] ?? 0,
            'on_time' => $stats['on_time'] ?? 0,
            'late' => $stats['late'] ?? 0
        ]
    ]);
    
} catch (PDOException $e) {
    error_log("Get recent attendance error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error',
        'attendance' => [],
        'stats' => ['total' => 0, 'on_time' => 0, 'late' => 0]
    ]);
} 