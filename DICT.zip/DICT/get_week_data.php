<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

// Verify if user is logged in as intern
if (!isset($_SESSION['intern_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Invalid JSON input');
    }
    
    $startDate = $input['startDate'] ?? null;
    $endDate = $input['endDate'] ?? null;
    
    if (!$startDate || !$endDate) {
        throw new Exception('Start date and end date are required');
    }
    
    // Get weekly data from intern_daily_reports for the specified date range
    $stmt = $pdo->prepare("
        SELECT 
            date,
            time_in,
            time_out,
            hours_rendered,
            tasks_done,
            work_mode
        FROM intern_daily_reports
        WHERE intern_id = ?
        AND date >= ?
        AND date <= ?
        ORDER BY date ASC
    ");
    $stmt->execute([$_SESSION['intern_id'], $startDate, $endDate]);
    $weekData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'weekData' => $weekData,
        'startDate' => $startDate,
        'endDate' => $endDate
    ]);
    
} catch (Exception $e) {
    error_log("Get week data error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to fetch week data: ' . $e->getMessage()
    ]);
}
?> 