<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

// Verify admin is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$internId = $data['intern_id'] ?? null;
$action = $data['action'] ?? null;

if (!$internId || $action !== 'graduate') {
    echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
    exit();
}

try {
    // Check if intern exists and is completed
    $stmt = $pdo->prepare("
        SELECT id, name, completion_status 
        FROM interns 
        WHERE id = ? AND completion_status = 'completed'
    ");
    $stmt->execute([$internId]);
    $intern = $stmt->fetch();
    
    if (!$intern) {
        echo json_encode(['success' => false, 'message' => 'Intern not found or not eligible for graduation']);
        exit();
    }
    
    // Begin transaction
    $pdo->beginTransaction();
    
    // Update intern status to graduated
    $stmt = $pdo->prepare("
        UPDATE interns 
        SET completion_status = 'graduated', 
            status = 'inactive',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ");
    $stmt->execute([$internId]);
    
    // Update notification to mark as read (since admin is taking action)
    $stmt = $pdo->prepare("
        UPDATE completion_notifications 
        SET notification_read = TRUE 
        WHERE intern_id = ?
    ");
    $stmt->execute([$internId]);
    
    // Create a new graduation notification entry for history
    $stmt = $pdo->prepare("
        INSERT INTO completion_notifications (intern_id, completion_date, notification_read, created_at)
        SELECT ?, completion_date, FALSE, CURRENT_TIMESTAMP
        FROM interns 
        WHERE id = ?
    ");
    $stmt->execute([$internId, $internId]);
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true, 
        'message' => "Successfully graduated {$intern['name']}. They have been marked as inactive."
    ]);
    
} catch (PDOException $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollback();
    }
    
    error_log("Graduate intern error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to graduate intern']);
}
?> 