<?php
/**
 * PIN Management Utility
 * 
 * This utility provides:
 * 1. Hash any existing unhashed PINs in the database
 * 2. Create new admin accounts with proper PIN hashing
 * 3. Verify PIN hashing status across the system
 */

require_once 'config/database.php';

// Set timezone
date_default_timezone_set('Asia/Manila');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PIN Management Utility - DICT</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        .header {
            background: #0033A0;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .content {
            padding: 30px;
        }
        .section {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: #f9f9f9;
        }
        .section h3 {
            margin-top: 0;
            color: #0033A0;
        }
        .btn {
            background: #0033A0;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
            font-size: 14px;
        }
        .btn:hover {
            background: #002780;
        }
        .btn.danger {
            background: #dc3545;
        }
        .btn.success {
            background: #28a745;
        }
        .result {
            margin-top: 15px;
            padding: 15px;
            border-radius: 5px;
            display: none;
        }
        .result.success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        .result.error {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        .result.info {
            background: #d1ecf1;
            border: 1px solid #bee5eb;
            color: #0c5460;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .status-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        .status-table th,
        .status-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .status-table th {
            background: #f8f9fa;
            font-weight: 600;
        }
        .status-good {
            color: #28a745;
            font-weight: 600;
        }
        .status-warning {
            color: #ffc107;
            font-weight: 600;
        }
        .status-error {
            color: #dc3545;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔐 PIN Management Utility</h1>
            <p>DICT Attendance System - PIN Security Management</p>
        </div>
        
        <div class="content">
            <!-- Status Check Section -->
            <div class="section">
                <h3>📊 PIN Security Status</h3>
                <p>Check the current status of PIN hashing in your system:</p>
                <button class="btn" onclick="checkPinStatus()">🔍 Check PIN Status</button>
                <div id="statusResult" class="result"></div>
            </div>

            <!-- Hash Existing PINs Section -->
            <div class="section">
                <h3>🔒 Hash Existing PINs</h3>
                <p><strong>⚠️ Important:</strong> This will hash any unhashed PINs in the database. Run this only once after importing old data.</p>
                <button class="btn danger" onclick="hashExistingPins()">🔨 Hash All Unhashed PINs</button>
                <div id="hashResult" class="result"></div>
            </div>

            <!-- Create Admin Section -->
            <div class="section">
                <h3>👤 Create New Admin</h3>
                <p>Create a new administrator account with properly hashed PIN:</p>
                
                <form id="adminForm" onsubmit="createAdmin(event)">
                    <div class="form-group">
                        <label for="adminName">Full Name:</label>
                        <input type="text" id="adminName" name="name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="adminCardUid">Card UID:</label>
                        <input type="text" id="adminCardUid" name="card_uid" required placeholder="e.g., ADMIN002">
                    </div>
                    
                    <div class="form-group">
                        <label for="adminPin">PIN (4-6 digits):</label>
                        <input type="password" id="adminPin" name="pin" required pattern="\d{4,6}" title="PIN must be 4-6 digits">
                    </div>
                    
                    <button type="submit" class="btn success">➕ Create Admin</button>
                </form>
                <div id="adminResult" class="result"></div>
            </div>

            <!-- Safety Information -->
            <div class="section">
                <h3>ℹ️ Security Information</h3>
                <ul>
                    <li><strong>✅ Automatic Hashing:</strong> New interns get auto-hashed PINs</li>
                    <li><strong>✅ PIN Changes:</strong> PIN changes are automatically hashed</li>
                    <li><strong>✅ Secure Login:</strong> Uses password_verify() for verification</li>
                    <li><strong>🔐 Algorithm:</strong> Uses PHP's PASSWORD_DEFAULT (bcrypt)</li>
                    <li><strong>⚠️ One-Time Use:</strong> Run "Hash Existing PINs" only once</li>
                </ul>
            </div>
        </div>
    </div>

    <script>
        // Check PIN hashing status
        async function checkPinStatus() {
            try {
                const response = await fetch('hash_pins_utility.php?action=check_status');
                const data = await response.json();
                showResult('statusResult', data.success ? 'success' : 'error', data.message);
            } catch (error) {
                showResult('statusResult', 'error', 'Error checking PIN status: ' + error.message);
            }
        }

        // Hash existing unhashed PINs
        async function hashExistingPins() {
            if (!confirm('⚠️ This will hash any unhashed PINs in the database. Are you sure you want to continue?')) {
                return;
            }
            
            try {
                const response = await fetch('hash_pins_utility.php?action=hash_existing');
                const data = await response.json();
                showResult('hashResult', data.success ? 'success' : 'error', data.message);
            } catch (error) {
                showResult('hashResult', 'error', 'Error hashing PINs: ' + error.message);
            }
        }

        // Create new admin
        async function createAdmin(event) {
            event.preventDefault();
            
            const formData = new FormData(event.target);
            formData.append('action', 'create_admin');
            
            try {
                const response = await fetch('hash_pins_utility.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                showResult('adminResult', data.success ? 'success' : 'error', data.message);
                
                if (data.success) {
                    document.getElementById('adminForm').reset();
                }
            } catch (error) {
                showResult('adminResult', 'error', 'Error creating admin: ' + error.message);
            }
        }

        // Show result message
        function showResult(elementId, type, message) {
            const element = document.getElementById(elementId);
            element.className = `result ${type}`;
            element.innerHTML = message;
            element.style.display = 'block';
            
            // Auto-hide after 10 seconds
            setTimeout(() => {
                element.style.display = 'none';
            }, 10000);
        }
    </script>
</body>
</html>

<?php
// Handle AJAX requests
if (isset($_GET['action']) || isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    $action = $_GET['action'] ?? $_POST['action'] ?? '';
    
    try {
        switch ($action) {
            case 'check_status':
                echo json_encode(checkPinHashingStatus());
                break;
                
            case 'hash_existing':
                echo json_encode(hashExistingPins());
                break;
                
            case 'create_admin':
                echo json_encode(createNewAdmin());
                break;
                
            default:
                echo json_encode(['success' => false, 'message' => 'Invalid action']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
    exit();
}

// Check PIN hashing status
function checkPinHashingStatus() {
    global $pdo;
    
    $report = "<table class='status-table'>";
    $report .= "<tr><th>Category</th><th>Count</th><th>Status</th></tr>";
    
    // Check admins
    $stmt = $pdo->query("SELECT COUNT(*) as total, 
                         SUM(CASE WHEN LENGTH(pin) > 20 THEN 1 ELSE 0 END) as hashed 
                         FROM admins");
    $admin_data = $stmt->fetch();
    $admin_status = ($admin_data['total'] == $admin_data['hashed']) ? 'status-good' : 'status-warning';
    
    $report .= "<tr><td>Admins</td><td>{$admin_data['total']} total, {$admin_data['hashed']} hashed</td>";
    $report .= "<td class='$admin_status'>" . ($admin_data['total'] == $admin_data['hashed'] ? '✅ All Hashed' : '⚠️ Some Unhashed') . "</td></tr>";
    
    // Check interns
    $stmt = $pdo->query("SELECT COUNT(*) as total, 
                         SUM(CASE WHEN LENGTH(pin) > 20 THEN 1 ELSE 0 END) as hashed 
                         FROM interns");
    $intern_data = $stmt->fetch();
    $intern_status = ($intern_data['total'] == $intern_data['hashed']) ? 'status-good' : 'status-warning';
    
    $report .= "<tr><td>Interns</td><td>{$intern_data['total']} total, {$intern_data['hashed']} hashed</td>";
    $report .= "<td class='$intern_status'>" . ($intern_data['total'] == $intern_data['hashed'] ? '✅ All Hashed' : '⚠️ Some Unhashed') . "</td></tr>";
    
    $report .= "</table>";
    
    $all_good = ($admin_data['total'] == $admin_data['hashed']) && ($intern_data['total'] == $intern_data['hashed']);
    
    return [
        'success' => true,
        'message' => $report . ($all_good ? "<br><br><strong class='status-good'>🎉 All PINs are properly hashed!</strong>" : "<br><br><strong class='status-warning'>⚠️ Some PINs need hashing.</strong>")
    ];
}

// Hash existing unhashed PINs
function hashExistingPins() {
    global $pdo;
    
    $pdo->beginTransaction();
    
    try {
        $hashedCount = 0;
        
        // Hash admin PINs that are not already hashed (length <= 20)
        $stmt = $pdo->query("SELECT id, pin FROM admins WHERE LENGTH(pin) <= 20");
        $admins = $stmt->fetchAll();
        
        foreach ($admins as $admin) {
            $hashedPin = password_hash($admin['pin'], PASSWORD_DEFAULT);
            $updateStmt = $pdo->prepare("UPDATE admins SET pin = ? WHERE id = ?");
            $updateStmt->execute([$hashedPin, $admin['id']]);
            $hashedCount++;
        }
        
        // Hash intern PINs that are not already hashed (length <= 20)
        $stmt = $pdo->query("SELECT id, pin FROM interns WHERE LENGTH(pin) <= 20");
        $interns = $stmt->fetchAll();
        
        foreach ($interns as $intern) {
            $hashedPin = password_hash($intern['pin'], PASSWORD_DEFAULT);
            $updateStmt = $pdo->prepare("UPDATE interns SET pin = ? WHERE id = ?");
            $updateStmt->execute([$hashedPin, $intern['id']]);
            $hashedCount++;
        }
        
        $pdo->commit();
        
        return [
            'success' => true,
            'message' => "✅ Successfully hashed $hashedCount PINs. All PINs are now secure!"
        ];
        
    } catch (Exception $e) {
        $pdo->rollBack();
        return [
            'success' => false,
            'message' => "❌ Error hashing PINs: " . $e->getMessage()
        ];
    }
}

// Create new admin with hashed PIN
function createNewAdmin() {
    global $pdo;
    
    $name = $_POST['name'] ?? '';
    $card_uid = $_POST['card_uid'] ?? '';
    $pin = $_POST['pin'] ?? '';
    
    // Validate input
    if (empty($name) || empty($card_uid) || empty($pin)) {
        return ['success' => false, 'message' => '❌ All fields are required'];
    }
    
    if (!preg_match('/^\d{4,6}$/', $pin)) {
        return ['success' => false, 'message' => '❌ PIN must be 4-6 digits'];
    }
    
    try {
        // Check if card_uid already exists
        $stmt = $pdo->prepare("SELECT id FROM admins WHERE card_uid = ?");
        $stmt->execute([$card_uid]);
        if ($stmt->fetch()) {
            return ['success' => false, 'message' => '❌ An admin with this card UID already exists'];
        }
        
        // Hash the PIN
        $hashedPin = password_hash($pin, PASSWORD_DEFAULT);
        
        // Insert new admin
        $stmt = $pdo->prepare("INSERT INTO admins (name, card_uid, pin) VALUES (?, ?, ?)");
        $stmt->execute([$name, $card_uid, $hashedPin]);
        
        return [
            'success' => true,
            'message' => "✅ Admin '$name' created successfully with card UID '$card_uid'. PIN has been securely hashed."
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => '❌ Error creating admin: ' . $e->getMessage()
        ];
    }
}
?> 