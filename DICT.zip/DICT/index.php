<?php
session_start();
require_once 'config/database.php';

// Get real-time statistics
try {
    // Get today's attendance statistics
    $today = date('Y-m-d');
    
    // Total attendance today
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT user_id) as total,
               SUM(CASE WHEN status = 'on_time' THEN 1 ELSE 0 END) as on_time,
               SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late
        FROM attendance_logs 
        WHERE date = ?
    ");
    $stmt->execute([$today]);
    $stats = $stmt->fetch();
    
    $totalToday = $stats['total'] ?? 0;
    $onTime = $stats['on_time'] ?? 0;
    $late = $stats['late'] ?? 0;
    
    // Get recent attendance
    $stmt = $pdo->prepare("
        SELECT 
            CASE 
                WHEN a.user_type = 'intern' THEN i.name
                WHEN a.user_type = 'employee' THEN e.name
            END as name,
            a.user_type as role,
            DATE_FORMAT(a.date, '%M %d, %Y') as date,
            TIME_FORMAT(a.time_in, '%h:%i %p') as time_in,
            TIME_FORMAT(a.time_out, '%h:%i %p') as time_out,
            a.status
        FROM attendance_logs a
        LEFT JOIN interns i ON a.user_type = 'intern' AND a.user_id = i.id
        LEFT JOIN employees e ON a.user_type = 'employee' AND a.user_id = e.id
        WHERE a.date = ?
        ORDER BY a.time_in DESC
        LIMIT 10
    ");
    $stmt->execute([$today]);
    $recentAttendance = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log("Index page error: " . $e->getMessage());
    $totalToday = 0;
    $onTime = 0;
    $late = 0;
    $recentAttendance = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>DICT Intern Attendance System</title>
  <link rel="stylesheet" href="css/index.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
  <header>
    <!-- DICT Logo on the left -->
    <div class="logo-left">
      <a href="index.php">
        <img src="img/dict-logo.png" alt="DICT Logo" class="header-logo">
      </a>
    </div>

    <div class="header-content">
      <h1>Welcome to DICT Region IV-A Attendance System</h1>
      <div class="subheading">Department of Information and Communications Technology</div>
    </div>
  
    <!-- Dynamic Login/Profile Section -->
    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
        <div class="profile-dropdown">
            <img src="img/profile.png" id="profileButton" alt="Profile" class="profile-img">
            <div id="dropdownMenu" class="dropdown-content">
                <?php if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin'): ?>
                    <!-- Admin Profile -->
                    <div class="admin-info">
                        <i class="fas fa-user-shield"></i>
                        <span>Welcome, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></span>
                    </div>
                    <a href="admin-dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
                <?php elseif (isset($_SESSION['intern_id'])): ?>
                    <!-- Intern Profile -->
                    <div class="admin-info">
                        <i class="fas fa-user"></i>
                        <span>Welcome, <strong><?php 
                            // Get intern name from database
                            try {
                                $stmt = $pdo->prepare("SELECT name FROM interns WHERE id = ?");
                                $stmt->execute([$_SESSION['intern_id']]);
                                $intern = $stmt->fetch();
                                echo htmlspecialchars($intern['name']);
                            } catch (PDOException $e) {
                                echo "Intern";
                            }
                        ?></strong></span>
                    </div>
                    <a href="intern-dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
                <?php endif; ?>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
            </div>
        </div>
    <?php else: ?>
        <div class="login-button-container">
            <a href="login.php" class="login-link">
                <button class="login-btn">
                    <i class="fas fa-sign-in-alt"></i>
                    Login
                </button>
            </a>
        </div>
    <?php endif; ?>
  </header>

  <main class="dashboard-layout">
    <!-- Left Column -->
    <div class="dashboard-left">
      <!-- Philippine Time Display -->
      <div id="clock" class="clock-display"></div>

      <!-- NFC Scan Section - PRIORITY SECTION -->
      <div class="nfc-section">
        <div class="nfc-primary">
          <div class="instruction-text">Tap your NFC card to record attendance</div>
          
          <!-- NFC Input - MOVED UP FOR VISIBILITY -->
          <form id="nfcForm" method="POST" enctype="multipart/form-data">
            <input type="text" id="uid" name="uid" placeholder="Initializing..." autofocus disabled>
            <input type="hidden" id="capturedImage" name="captured_image">
          </form>
          <div class="msg" id="result"></div>
        </div>

        <!-- Camera and Stats Row -->
        <div class="camera-stats-row">
          <!-- Compact Camera Preview -->
          <div class="camera-section compact">
            <div class="camera-preview-small">
              <video id="cameraVideo" autoplay muted playsinline></video>
              <div class="camera-overlay">
                <div class="viewfinder">
                  <div class="viewfinder-corner tl"></div>
                  <div class="viewfinder-corner tr"></div>
                  <div class="viewfinder-corner bl"></div>
                  <div class="viewfinder-corner br"></div>
                </div>
              </div>
            </div>
            <canvas id="cameraCanvas" style="display: none;"></canvas>
            <div id="cameraStatus" class="camera-status compact">
              <i class="fas fa-camera"></i>
              <span>Initializing camera...</span>
            </div>
          </div>

          <!-- Quick Stats -->
          <div class="stats-section compact">
            <div class="stat-card compact">
              <div class="stat-title">Today</div>
              <div class="stat-value"><?php echo $totalToday; ?></div>
            </div>
            <div class="stat-card compact">
              <div class="stat-title">On Time</div>
              <div class="stat-value"><?php echo $onTime; ?></div>
            </div>
            <div class="stat-card compact">
              <div class="stat-title">Late</div>
              <div class="stat-value"><?php echo $late; ?></div>
            </div>
          </div>
        </div>

        <div class="sub-instruction">Photo will be captured automatically</div>
      </div>
    </div>

    <!-- Right Column - Attendance Table -->
    <div class="dashboard-right">
      <div class="attendance-section">
        <div class="section-header">
          <h2>Recent Attendance</h2>
          <div class="header-actions">
            <select class="filter-select">
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
            </select>
          </div>
        </div>
        <div class="table-container">
          <table class="attendance-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Role</th>
                <th>Date</th>
                <th>Time In</th>
                <th>Time Out</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody id="attendanceData">
              <?php foreach ($recentAttendance as $record): ?>
                <tr>
                    <td><?php echo htmlspecialchars($record['name']); ?></td>
                    <td><?php echo ucfirst(htmlspecialchars($record['role'])); ?></td>
                    <td><?php echo htmlspecialchars($record['date']); ?></td>
                    <td><?php echo htmlspecialchars($record['time_in']); ?></td>
                    <td><?php echo $record['time_out'] ? htmlspecialchars($record['time_out']) : '-'; ?></td>
                    <td>
                        <span class="status-badge <?php echo $record['status']; ?>">
                            <?php echo ucfirst(str_replace('_', ' ', $record['status'])); ?>
                        </span>
                    </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>

  <footer>
            &copy; 2025 DICT &bull; Reginaldo &bull; Tesorero | All rights reserved 
  </footer>

  <script src="js/submit.js"></script>
  <script src="js/icon.js"></script>
  <script src="js/time.js"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Profile dropdown functionality
        const profileButton = document.getElementById('profileButton');
        const dropdownMenu = document.getElementById('dropdownMenu');
        
        if (profileButton && dropdownMenu) {
            // Toggle dropdown on profile image click
            profileButton.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                dropdownMenu.classList.toggle('show');
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!dropdownMenu.contains(e.target) && !profileButton.contains(e.target)) {
                    dropdownMenu.classList.remove('show');
                }
            });

            // Prevent dropdown from closing when clicking inside it
            dropdownMenu.addEventListener('click', function(e) {
                e.stopPropagation();
            });
        }

        // Keep focus on the input field after form submission
        const uidInput = document.getElementById('uid');
        const nfcForm = document.getElementById('nfcForm');
        
        if (uidInput && nfcForm) {
            // Set initial focus after camera initializes
            setTimeout(() => {
                if (!uidInput.disabled) {
                    uidInput.focus();
                }
            }, 2000);

            // Maintain focus after form submission
            nfcForm.addEventListener('submit', function() {
                setTimeout(() => {
                    if (!uidInput.disabled) {
                        uidInput.focus();
                    }
                }, 100);
            });
        }
    });
  </script>

  <style>
    .login-button-container {
        margin-right: 20px;
        display: flex;
        align-items: center;
    }

    .login-btn {
        background-color: #0056b3;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 1rem;
        transition: background-color 0.3s;
    }

    .login-btn:hover {
        background-color: #003d82;
    }

    .login-link {
        text-decoration: none;
    }

    .profile-dropdown {
        position: relative;
        margin-right: 20px;
    }

    .profile-img {
        height: 40px;
        width: 40px;
        border-radius: 50%;
        cursor: pointer;
        border: 2px solid white;
        transition: transform 0.2s;
    }

    .profile-img:hover {
        transform: scale(1.05);
    }

    .dropdown-content {
        display: none;
        position: absolute;
        right: 0;
        top: 50px;
        background-color: white;
        min-width: 200px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 1000;
    }

    .dropdown-content.show {
        display: block;
    }

    .admin-info {
        padding: 12px;
        background-color: #0033A0;
        color: white;
        border-radius: 8px 8px 0 0;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .dropdown-content a {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 12px;
        color: #333;
        text-decoration: none;
        transition: background-color 0.2s;
    }

    .dropdown-content a:hover {
        background-color: #f5f5f5;
    }

    .status-badge {
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 0.85em;
        font-weight: 500;
    }

    .status-badge.on_time {
        background-color: #e6f4ea;
        color: #1e7e34;
    }

    .status-badge.late {
        background-color: #ffeeba;
        color: #856404;
    }

    .camera-section {
        margin: 10px 0;
        text-align: center;
    }

    .camera-status {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 8px;
        background-color: #e8f5e8;
        border: 1px solid #4CAF50;
        border-radius: 5px;
        color: #2e7d32;
        font-size: 0.9em;
    }

    .camera-status.error {
        background-color: #ffebee;
        border-color: #f44336;
        color: #c62828;
    }

    .camera-status.capturing {
        background-color: #fff3e0;
        border-color: #ff9800;
        color: #e65100;
    }

    .camera-status.info {
        background-color: #e3f2fd;
        border-color: #2196f3;
        color: #0d47a1;
    }

    .camera-status .fa-camera {
        font-size: 1.1em;
    }

    /* NFC Input States */
    #uid:disabled {
        background-color: #f5f5f5;
        color: #999;
        cursor: not-allowed;
        border-color: #ddd;
    }

    #uid:disabled::placeholder {
        color: #999;
        font-style: italic;
    }

    /* NFC Section Styles */
    .nfc-primary {
        background: linear-gradient(135deg, #0033A0, #004bb5);
        padding: 20px;
        border-radius: 15px;
        margin-bottom: 15px;
        box-shadow: 0 6px 20px rgba(0, 51, 160, 0.3);
    }

    .nfc-primary .instruction-text {
        color: white;
        font-size: 1.2em;
        font-weight: 600;
        text-align: center;
        margin-bottom: 15px;
    }

    .nfc-primary #uid {
        width: 100%;
        padding: 15px;
        font-size: 1.1em;
        border: 3px solid #4CAF50;
        border-radius: 10px;
        text-align: center;
        font-weight: 600;
        background: white;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        margin-bottom: 10px;
    }

    .nfc-primary #uid:focus {
        outline: none;
        border-color: #45a049;
        box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.3);
    }

    .nfc-primary .msg {
        color: white;
        text-align: center;
        font-weight: 500;
        min-height: 20px;
        padding: 8px;
        border-radius: 6px;
        margin-top: 10px;
    }

    .nfc-primary .msg.success {
        background-color: rgba(76, 175, 80, 0.2);
        border: 1px solid rgba(76, 175, 80, 0.5);
    }

    .nfc-primary .msg.error {
        background-color: rgba(244, 67, 54, 0.2);
        border: 1px solid rgba(244, 67, 54, 0.5);
    }

    .camera-stats-row {
        display: flex;
        gap: 15px;
        margin-bottom: 10px;
        align-items: flex-start;
    }

    .sub-instruction {
        font-size: 0.85em;
        color: #666;
        font-style: italic;
        text-align: center;
        margin-top: 0;
    }

    /* Compact Camera Preview Styles */
    .camera-preview-small {
        position: relative;
        width: 200px;
        height: 150px;
        border-radius: 8px;
        overflow: hidden;
        background-color: #000;
        border: 2px solid #0033A0;
        box-shadow: 0 3px 10px rgba(0, 51, 160, 0.2);
    }

    #cameraVideo {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: none; /* Hidden by default, shown when camera is ready */
        transform: scaleX(-1); /* Mirror the video for natural selfie view */
    }

    /* Compact Camera Section */
    .camera-section.compact {
        flex: 1;
        max-width: 200px;
    }

    .camera-status.compact {
        font-size: 0.8em;
        padding: 6px 10px;
        margin-top: 8px;
    }

    .camera-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        pointer-events: none;
    }

    .viewfinder {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 80%;
        height: 80%;
        border: 2px dashed rgba(255, 255, 255, 0.7);
        border-radius: 8px;
    }

    .viewfinder-corner {
        position: absolute;
        width: 20px;
        height: 20px;
        border: 3px solid #4CAF50;
    }

    .viewfinder-corner.tl {
        top: -3px;
        left: -3px;
        border-right: none;
        border-bottom: none;
    }

    .viewfinder-corner.tr {
        top: -3px;
        right: -3px;
        border-left: none;
        border-bottom: none;
    }

    .viewfinder-corner.bl {
        bottom: -3px;
        left: -3px;
        border-right: none;
        border-top: none;
    }

    .viewfinder-corner.br {
        bottom: -3px;
        right: -3px;
        border-left: none;
        border-top: none;
    }

    /* Camera flash effect */
    .camera-flash {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: white;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.1s ease;
    }

    .camera-flash.active {
        opacity: 0.8;
    }

    /* Update camera status styles */
    .camera-status {
        margin-top: 10px;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 0.9em;
        font-weight: 500;
        text-align: center;
        transition: all 0.3s ease;
    }

    .camera-status.ready {
        background-color: #e8f5e8;
        border: 1px solid #4CAF50;
        color: #2e7d32;
    }

    .camera-status.error {
        background-color: #ffebee;
        border: 1px solid #f44336;
        color: #c62828;
    }

    .camera-status.capturing {
        background-color: #fff3e0;
        border: 1px solid #ff9800;
        color: #e65100;
        animation: pulse 0.5s ease-in-out;
    }

    .camera-status.info {
        background-color: #e3f2fd;
        border: 1px solid #2196f3;
        color: #0d47a1;
    }

    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }

    /* New entry highlighting */
    .new-entry {
        background-color: #e8f5e8 !important;
        animation: highlight 2s ease-out;
    }

    @keyframes highlight {
        0% { background-color: #c8e6c9; }
        100% { background-color: #e8f5e8; }
    }

    .new-entry td {
        border-left: 3px solid #4CAF50;
    }

    /* Compact Stats Section */
    .stats-section.compact {
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .stat-card.compact {
        background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 10px;
        text-align: center;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s ease;
    }

    .stat-card.compact:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .stat-card.compact .stat-title {
        font-size: 0.8em;
        color: #6c757d;
        font-weight: 600;
        margin-bottom: 4px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .stat-card.compact .stat-value {
        font-size: 1.4em;
        font-weight: 700;
        color: #0033A0;
        margin: 0;
    }

    /* Statistics update animation */
    .stat-value {
        transition: transform 0.2s ease;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .camera-stats-row {
            flex-direction: column;
            gap: 10px;
        }

        .camera-section.compact {
            max-width: 100%;
        }

        .camera-preview-small {
            width: 160px;
            height: 120px;
            margin: 0 auto;
        }

        .stats-section.compact {
            flex-direction: row;
            justify-content: space-around;
        }

        .stat-card.compact {
            flex: 1;
            margin: 0 5px;
        }

        .nfc-primary {
            padding: 15px;
        }

        .nfc-primary #uid {
            padding: 12px;
            font-size: 1em;
        }
    }

    @media (max-width: 480px) {
        .camera-preview-small {
            width: 140px;
            height: 105px;
        }

        .stat-card.compact .stat-value {
            font-size: 1.2em;
        }

        .stat-card.compact .stat-title {
            font-size: 0.7em;
        }
    }


  </style>
</body>
</html>
