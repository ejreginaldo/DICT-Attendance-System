-- ===============================================================
-- DICT Attendance System - Complete Database Installation
-- ===============================================================
-- This file contains the complete database setup for the 
-- DICT Attendance System including all tables, indexes, and
-- sample data for immediate deployment.
-- ===============================================================

-- Create the database
CREATE DATABASE IF NOT EXISTS attendance_system;
USE attendance_system;

-- ===============================================================
-- ADMINS TABLE
-- ===============================================================
CREATE TABLE IF NOT EXISTS admins (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    card_uid VARCHAR(50) UNIQUE NOT NULL,
    pin VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin (PIN: 000000)
INSERT INTO admins (name, card_uid, pin) VALUES 
('System Administrator', '123456789', '$2y$10$57Usw79ko0g0Tp2VSDFc3ecdAZhGgUugcjN2lo/KAu5J2SANWG7xG')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- ===============================================================
-- INTERNS TABLE (with completion tracking)
-- ===============================================================
CREATE TABLE IF NOT EXISTS interns (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    school VARCHAR(100) NOT NULL,
    card_uid VARCHAR(50) UNIQUE NOT NULL,
    pin VARCHAR(255) NOT NULL,
    start_date DATE NOT NULL,
    required_hours INT NOT NULL,
    completed_hours DECIMAL(10,2) DEFAULT 0,
    status ENUM('active', 'completed', 'terminated') DEFAULT 'active',
    completion_status ENUM('active', 'completed', 'graduated') DEFAULT 'active',
    completion_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ===============================================================
-- EMPLOYEES TABLE
-- ===============================================================
CREATE TABLE IF NOT EXISTS employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    position VARCHAR(100) NOT NULL,
    department VARCHAR(100) NOT NULL,
    card_uid VARCHAR(50) UNIQUE NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ===============================================================
-- ATTENDANCE LOGS TABLE (with image support)
-- ===============================================================
CREATE TABLE IF NOT EXISTS attendance_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_type ENUM('intern', 'employee') NOT NULL,
    user_id INT NOT NULL,
    date DATE NOT NULL,
    time_in TIME,
    time_out TIME,
    total_hours DECIMAL(4,2),
    status ENUM('on_time', 'late', 'absent') NOT NULL,
    image_path VARCHAR(255) NULL COMMENT 'Path to time-in photo',
    timeout_image_path VARCHAR(255) NULL COMMENT 'Path to time-out photo',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_type, user_id),
    INDEX idx_date (date),
    INDEX idx_image_path (image_path),
    INDEX idx_timeout_image_path (timeout_image_path)
);

-- ===============================================================
-- INTERN DAILY REPORTS TABLE (with work mode support)
-- ===============================================================
CREATE TABLE IF NOT EXISTS intern_daily_reports (
    id INT PRIMARY KEY AUTO_INCREMENT,
    intern_id INT NOT NULL,
    date DATE NOT NULL,
    time_in TIME NULL,
    time_out TIME NULL,
    hours_rendered DECIMAL(4,2) DEFAULT 0,
    tasks_done TEXT,
    work_mode ENUM('office', 'wfh', 'absent', 'leave', 'holiday') DEFAULT 'office',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (intern_id) REFERENCES interns(id) ON DELETE CASCADE,
    UNIQUE KEY unique_intern_date (intern_id, date)
);

-- ===============================================================
-- COMPLETION NOTIFICATIONS TABLE
-- ===============================================================
CREATE TABLE IF NOT EXISTS completion_notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    intern_id INT NOT NULL,
    completion_date DATE NOT NULL,
    notification_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (intern_id) REFERENCES interns(id) ON DELETE CASCADE,
    INDEX idx_intern_id (intern_id),
    INDEX idx_completion_date (completion_date),
    INDEX idx_notification_read (notification_read)
);

-- ===============================================================
-- CREATE DIRECTORIES (Note: These need to be created manually)
-- ===============================================================
-- The following directories should be created with proper permissions:
-- - images/attendance/ (for storing attendance photos)
-- - images/attendance/[YYYY-MM-DD]/ (daily folders will be created automatically)

-- ===============================================================
-- INDEXES FOR PERFORMANCE
-- ===============================================================
-- Additional indexes for better performance
ALTER TABLE interns ADD INDEX IF NOT EXISTS idx_status (status);
ALTER TABLE interns ADD INDEX IF NOT EXISTS idx_completion_status (completion_status);
ALTER TABLE interns ADD INDEX IF NOT EXISTS idx_completion_date (completion_date);
ALTER TABLE interns ADD INDEX IF NOT EXISTS idx_card_uid (card_uid);
ALTER TABLE employees ADD INDEX IF NOT EXISTS idx_status (status);
ALTER TABLE employees ADD INDEX IF NOT EXISTS idx_card_uid (card_uid);
ALTER TABLE intern_daily_reports ADD INDEX IF NOT EXISTS idx_date (date);
ALTER TABLE intern_daily_reports ADD INDEX IF NOT EXISTS idx_intern_date (intern_id, date);

-- ===============================================================
-- MIGRATION / UPGRADE SECTION
-- ===============================================================
-- Run these statements to upgrade an existing database with missing columns.
-- These use stored procedures to safely add columns only if they don't exist.
-- (MySQL doesn't support ADD COLUMN IF NOT EXISTS in all versions)

-- Drop the procedure if it exists, then create it
DROP PROCEDURE IF EXISTS AddColumnIfNotExists;

DELIMITER //
CREATE PROCEDURE AddColumnIfNotExists(
    IN tableName VARCHAR(64),
    IN columnName VARCHAR(64),
    IN columnDefinition VARCHAR(255)
)
BEGIN
    DECLARE columnExists INT DEFAULT 0;
    
    SELECT COUNT(*) INTO columnExists
    FROM information_schema.columns
    WHERE table_schema = DATABASE()
      AND table_name = tableName
      AND column_name = columnName;
    
    IF columnExists = 0 THEN
        SET @sql = CONCAT('ALTER TABLE ', tableName, ' ADD COLUMN ', columnName, ' ', columnDefinition);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        SELECT CONCAT('Added column: ', tableName, '.', columnName) AS Result;
    ELSE
        SELECT CONCAT('Column already exists: ', tableName, '.', columnName) AS Result;
    END IF;
END //
DELIMITER ;

-- Upgrade interns table
CALL AddColumnIfNotExists('interns', 'completion_status', "ENUM('active', 'completed', 'graduated') DEFAULT 'active'");
CALL AddColumnIfNotExists('interns', 'completion_date', 'DATE NULL');
CALL AddColumnIfNotExists('interns', 'start_date', 'DATE NULL');
CALL AddColumnIfNotExists('interns', 'completed_hours', 'DECIMAL(10,2) DEFAULT 0');

-- Upgrade intern_daily_reports table
CALL AddColumnIfNotExists('intern_daily_reports', 'work_mode', "ENUM('office', 'wfh', 'absent', 'leave', 'holiday') DEFAULT 'office'");

-- Upgrade attendance_logs table
CALL AddColumnIfNotExists('attendance_logs', 'image_path', 'VARCHAR(255) NULL');
CALL AddColumnIfNotExists('attendance_logs', 'timeout_image_path', 'VARCHAR(255) NULL');

-- Clean up the procedure
DROP PROCEDURE IF EXISTS AddColumnIfNotExists;

-- ===============================================================
-- QUICK UPGRADE (Alternative - Run manually if procedure fails)
-- ===============================================================
-- If the stored procedure above doesn't work on your MySQL version,
-- run these commands manually (ignore errors for columns that exist):
--
-- ALTER TABLE interns ADD COLUMN completion_status ENUM('active', 'completed', 'graduated') DEFAULT 'active';
-- ALTER TABLE interns ADD COLUMN completion_date DATE NULL;
-- ALTER TABLE interns ADD COLUMN start_date DATE NULL;
-- ALTER TABLE interns ADD COLUMN completed_hours DECIMAL(10,2) DEFAULT 0;
-- ALTER TABLE intern_daily_reports ADD COLUMN work_mode ENUM('office', 'wfh', 'absent', 'leave', 'holiday') DEFAULT 'office';
-- ALTER TABLE attendance_logs ADD COLUMN image_path VARCHAR(255) NULL;
-- ALTER TABLE attendance_logs ADD COLUMN timeout_image_path VARCHAR(255) NULL;

-- ===============================================================
-- SYSTEM INFORMATION
-- ===============================================================
-- Display installation completion message
SELECT 'DICT Attendance System Database Installation Complete!' as Status,
       COUNT(*) as 'Total Tables' 
FROM information_schema.tables 
WHERE table_schema = 'attendance_system';

-- Show all created tables
SELECT 
    table_name as 'Table Name',
    table_rows as 'Rows',
    ROUND(((data_length + index_length) / 1024 / 1024), 2) as 'Size (MB)'
FROM information_schema.tables 
WHERE table_schema = 'attendance_system'
ORDER BY table_name; 