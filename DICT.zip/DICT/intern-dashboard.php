<?php
session_start();
require_once 'config/database.php';

// Verify if user is logged in as intern
if (!isset($_SESSION['intern_id'])) {
    header('Location: login.php');
    exit();
}

try {
    // Get intern details
    $stmt = $pdo->prepare("
        SELECT * FROM interns 
        WHERE id = ? AND status = 'active'
    ");
    $stmt->execute([$_SESSION['intern_id']]);
    $intern = $stmt->fetch();

    if (!$intern) {
        session_destroy();
        header('Location: login.php');
        exit();
    }

    // Calculate total completed hours from intern daily reports (weekly reports table data)
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(hours_rendered), 0) as completed_hours
        FROM intern_daily_reports
        WHERE intern_id = ?
        AND date <= CURDATE()
        AND hours_rendered > 0
    ");
    $stmt->execute([$_SESSION['intern_id']]);
    $completedHoursResult = $stmt->fetch();
    $completedHours = $completedHoursResult['completed_hours'];

    // Get today's attendance with break time adjustment (from actual card tapping)
    $today = date('Y-m-d');
    $stmt = $pdo->prepare("
        SELECT 
            DATE_FORMAT(time_in, '%h:%i %p') as formatted_time_in,
            DATE_FORMAT(time_out, '%h:%i %p') as formatted_time_out,
            time_in,
            time_out,
            total_hours,
            status
        FROM attendance_logs
        WHERE user_type = 'intern' 
        AND user_id = ? 
        AND date = ?
    ");
    $stmt->execute([$_SESSION['intern_id'], $today]);
    $todayAttendance = $stmt->fetch();

    // Get weekly attendance summary with break time adjustment and tasks (weekdays only)
    $stmt = $pdo->prepare("
        SELECT 
            idr.date,
            DATE_FORMAT(idr.date, '%W, %M %d') as formatted_date,
            TIME_FORMAT(idr.time_in, '%h:%i %p') as time_in,
            TIME_FORMAT(idr.time_out, '%h:%i %p') as time_out,
            idr.hours_rendered as total_hours,
            COALESCE(idr.work_mode, 'office') as status,
            COALESCE(idr.tasks_done, '') as tasks
        FROM intern_daily_reports idr
        WHERE idr.intern_id = ?
        AND idr.date >= DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY)
        AND WEEKDAY(idr.date) < 5  -- Monday=0, Tuesday=1, Wednesday=2, Thursday=3, Friday=4
        ORDER BY idr.date DESC
    ");
    $stmt->execute([$_SESSION['intern_id']]);
    $weeklyAttendance = $stmt->fetchAll();

    // Update completed_hours in interns table based on weekly reports data
    $stmt = $pdo->prepare("
        UPDATE interns i
        SET completed_hours = (
            SELECT COALESCE(SUM(hours_rendered), 0)
            FROM intern_daily_reports 
            WHERE intern_id = i.id
            AND date <= CURDATE()
            AND hours_rendered > 0
        )
        WHERE id = ?
    ");
    $stmt->execute([$_SESSION['intern_id']]);

    // Check for completion and update status if needed
    $stmt = $pdo->prepare("
        SELECT id, required_hours, completed_hours, completion_status 
        FROM interns 
        WHERE id = ? AND status = 'active'
    ");
    $stmt->execute([$_SESSION['intern_id']]);
    $internCheck = $stmt->fetch();
    
    if ($internCheck && $internCheck['completed_hours'] >= $internCheck['required_hours'] && $internCheck['completion_status'] != 'completed') {
        // Update completion status
        $stmt = $pdo->prepare("
            UPDATE interns 
            SET completion_status = 'completed', completion_date = CURDATE()
            WHERE id = ?
        ");
        $stmt->execute([$_SESSION['intern_id']]);
        
        // Create completion notification
        $stmt = $pdo->prepare("
            INSERT IGNORE INTO completion_notifications (intern_id, completion_date, notification_read, created_at)
            VALUES (?, CURDATE(), FALSE, NOW())
        ");
        $stmt->execute([$_SESSION['intern_id']]);
        
        error_log("Intern {$_SESSION['intern_id']} completed their internship via dashboard!");
    }

} catch (PDOException $e) {
    error_log("Dashboard error: " . $e->getMessage());
    $intern = null;
    $todayAttendance = null;
    $weeklyAttendance = [];
    $completedHours = 0;
}

    // Calculate progress with proper error handling
    $progressPercentage = 0;
    $isCompleted = false;
    if ($intern && isset($intern['required_hours']) && $intern['required_hours'] > 0) {
        $progressPercentage = ($completedHours / $intern['required_hours']) * 100;
        $progressPercentage = round($progressPercentage, 1);
        $isCompleted = $progressPercentage >= 100;
        
        // Cap display at 100% for UI purposes, but keep actual value for calculations
        $displayPercentage = min(100, $progressPercentage);
    } else {
        $displayPercentage = 0;
    }

// Set default values if intern data is missing
if (!$intern) {
    $intern = [
        'name' => 'Unknown Intern',
        'required_hours' => 0,
        'school' => 'Unknown School'
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DICT Intern Dashboard</title>
    <link rel="stylesheet" href="css/intern-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header>
        <div class="logo-left">
            <a href="index.php">
                <img src="img/dict-logo.png" alt="DICT Logo" class="header-logo">
            </a>
        </div>

        <div class="header-content">
            <h1>Intern Dashboard</h1>
            <div class="subheading">Department of Information and Communications Technology</div>
        </div>

        <div class="profile-dropdown">
            <img src="img/profile.png" id="profileButton" alt="Profile" class="profile-img">
            <div id="dropdownMenu" class="dropdown-content">
                <div class="intern-info">
                    <i class="fas fa-user-graduate"></i>
                    <span>Welcome, <strong id="internName"><?php echo htmlspecialchars($intern['name'] ?? 'Unknown Intern'); ?></strong></span>
                </div>
                <a href="#" onclick="openChangePinModal()"><i class="fas fa-key"></i>Change PIN</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
            </div>
        </div>
    </header>

    <nav class="dashboard-nav">
        <div class="nav-item active">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </div>
        <a href="attendance-history.php" class="nav-item">
            <i class="fas fa-history"></i>
            <span>Attendance History</span>
        </a>
    </nav>

    <main class="dashboard-layout">
        <!-- Progress Section -->
        <div class="quick-stats">
            <div class="stat-card progress-card">
                <div class="progress-visualization <?php echo $isCompleted ? 'completed' : ''; ?>">
                    <div class="progress-header">
                        <h3>Internship Progress</h3>
                        <div class="progress-status">
                            <span class="progress-percentage"><?php echo $isCompleted ? '100.0' : $progressPercentage; ?>%</span>
                            <?php if ($isCompleted): ?>
                                <span class="completion-badge">🎉 Completed!</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="modern-progress-bar <?php echo $isCompleted ? 'completed' : ''; ?>">
                        <div class="progress-track">
                            <div class="progress-fill <?php echo $isCompleted ? 'completed' : ''; ?>" style="width: <?php echo $displayPercentage; ?>%">
                                <div class="progress-glow"></div>
                            </div>
                            <div class="progress-markers">
                                <div class="marker" style="left: 25%"><span>25%</span></div>
                                <div class="marker" style="left: 50%"><span>50%</span></div>
                                <div class="marker" style="left: 75%"><span>75%</span></div>
                                <div class="marker" style="left: 100%"><span>100%</span></div>
                            </div>
                        </div>
                    </div>
                    <div class="hours-info">
                        <div class="hours-detail">
                            <span class="hours-number"><?php echo number_format($completedHours, 1); ?></span>
                            <span class="hours-label">Hours Done</span>
                        </div>
                        <div class="hours-divider"></div>
                        <div class="hours-detail">
                            <span class="hours-number"><?php echo isset($intern['required_hours']) ? $intern['required_hours'] : 0; ?></span>
                            <span class="hours-label">Required</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="content-grid">
            <!-- Time Record Section - 1/4 width -->
            <div class="time-record-card">
                <div class="card-header">
                    <h3><i class="fas fa-clock"></i> Time Record</h3>
                    <span class="current-date"><?php echo date('l, F j, Y'); ?></span>
                </div>
                <div class="time-status">
                    <?php if ($todayAttendance): ?>
                    <div class="status-indicator online">
                        <i class="fas fa-circle"></i>
                        <span>Currently Logged In</span>
                    </div>
                    <?php else: ?>
                    <div class="status-indicator offline">
                        <i class="fas fa-circle"></i>
                        <span>Not Yet Logged In</span>
                    </div>
                    <?php endif; ?>
                </div>
                                    <div class="time-actions">
                    <button class="time-btn time-in" <?php echo $todayAttendance ? 'disabled' : ''; ?>>
                        <i class="fas fa-sign-in-alt"></i>
                        Time In
                        <?php if ($todayAttendance): ?>
                        <span class="time-stamp"><?php echo $todayAttendance['formatted_time_in']; ?></span>
                        <?php endif; ?>
                    </button>
                    <button class="time-btn time-out" <?php echo (!$todayAttendance || $todayAttendance['time_out']) ? 'disabled' : ''; ?>>
                        <i class="fas fa-sign-out-alt"></i>
                        Time Out
                        <?php if ($todayAttendance && $todayAttendance['time_out']): ?>
                        <span class="time-stamp"><?php echo $todayAttendance['formatted_time_out']; ?></span>
                        <?php endif; ?>
                    </button>
                </div>
                <div class="time-summary">
                    <div class="summary-item">
                        <span class="label">Time In</span>
                        <span class="value"><?php echo $todayAttendance ? $todayAttendance['formatted_time_in'] : '-'; ?></span>
                    </div>
                    <div class="summary-item">
                        <span class="label">Time Out</span>
                        <span class="value"><?php echo ($todayAttendance && $todayAttendance['time_out']) ? $todayAttendance['formatted_time_out'] : '-'; ?></span>
                    </div>
                    <div class="summary-item">
                        <span class="label">Hours Today</span>
                        <span class="value highlight"><?php echo $todayAttendance && $todayAttendance['total_hours'] ? number_format($todayAttendance['total_hours'], 1) : '0.0'; ?> hrs</span>
                    </div>
                </div>
            </div>

            <!-- Weekly Report Section - 3/4 width -->
            <div class="weekly-report-card">
                <div class="card-header">
                    <div class="header-left">
                        <h3><i class="fas fa-calendar-week"></i> Weekly Report</h3>
                        <span class="date-range" id="weekDateRange"><?php 
                            $startOfWeek = strtotime('monday this week');
                            $endOfWeek = strtotime('friday this week');
                            $internStartDate = !empty($intern['start_date']) ? strtotime($intern['start_date']) : $startOfWeek;
                            $effectiveStart = max($startOfWeek, $internStartDate);
                            
                            $startFormatted = date('F j', $effectiveStart);
                            $endFormatted = date('F j, Y', $endOfWeek);
                            echo $startFormatted . ' - ' . $endFormatted;
                        ?></span>
                    </div>
                    <div class="header-actions">
                        <div class="week-selector">
                            <label for="weekSelector">Week:</label>
                            <select id="weekSelector" class="week-dropdown">
                                <?php
                                // Calculate weeks since start date
                                if ($intern && !empty($intern['start_date'])) {
                                    $startDate = new DateTime($intern['start_date']);
                                    $currentDate = new DateTime();
                                    $today = new DateTime();
                                    
                                    // Find the Monday of the week containing the start date
                                    $firstWeekMonday = clone $startDate;
                                    $dayOfWeek = $firstWeekMonday->format('N'); // 1 = Monday, 7 = Sunday
                                    if ($dayOfWeek > 1) {
                                        $daysToSubtract = $dayOfWeek - 1;
                                        $firstWeekMonday->modify("-{$daysToSubtract} days");
                                    }
                                    
                                    $weekNumber = 1;
                                    $selectedWeek = null;
                                    
                                    // Generate week options from start week up to current week (and beyond if needed)
                                    $tempDate = clone $firstWeekMonday;
                                    $currentWeekMonday = new DateTime('monday this week');
                                    
                                    // Generate at least current week, and all weeks from start to current + 1 week ahead
                                    $endDate = max($currentWeekMonday, $tempDate);
                                    $endDate->modify('+1 week'); // Add one week ahead for safety
                                    
                                    while ($tempDate <= $endDate) {
                                        $weekStart = $tempDate->format('Y-m-d');
                                        $tempFriday = clone $tempDate;
                                        $tempFriday->modify('+4 days');
                                        $weekEnd = $tempFriday->format('Y-m-d');
                                        
                                        // Check if this week contains today
                                        $todayStr = $today->format('Y-m-d');
                                        $isCurrentWeek = ($weekStart <= $todayStr && $todayStr <= $weekEnd);
                                        
                                        echo "<option value='$weekNumber' data-start='$weekStart' data-end='$weekEnd'" . 
                                             ($isCurrentWeek ? " selected" : "") . ">Week $weekNumber</option>";
                                        
                                        if ($isCurrentWeek) {
                                            $selectedWeek = $weekNumber;
                                        }
                                        
                                        $tempDate->modify('+7 days');
                                        $weekNumber++;
                                    }
                                    
                                    // If no week was selected (edge case), select the first week
                                    if ($selectedWeek === null && $weekNumber > 1) {
                                        echo "<script>document.addEventListener('DOMContentLoaded', function() { 
                                            document.getElementById('weekSelector').selectedIndex = 0; 
                                        });</script>";
                                    }
                                } else {
                                    echo "<option value='1' selected>Week 1</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <button class="action-btn primary" onclick="printReport()">
                            <i class="fas fa-print"></i>
                            Print Report
                        </button>
                        <button class="action-btn" onclick="openDTRModal()" style="background: #28a745; color: white; margin-left: 0.5rem;">
                            <i class="fas fa-file-alt"></i>
                            Generate Time Sheet
                        </button>
                        <!-- Test button for completion popup -->
                        <button class="action-btn" onclick="testCompletionModal()" style="background: #17a2b8; margin-left: 0.5rem;">
                            <i class="fas fa-test-tube"></i>
                            Test Completion
                        </button>
                    </div>
                </div>
                <div class="report-table-container">
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Time In</th>
                                <th>Time Out</th>
                                <th>Hours</th>
                                <th class="task-column">Daily Tasks</th>
                                <th>Work Mode</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // Generate weekdays for the current week, starting from intern's start date if later
                            $weekdays = [];
                            $startOfWeek = strtotime('monday this week');
                            $endOfWeek = strtotime('friday this week');
                            $internStartDate = !empty($intern['start_date']) ? strtotime($intern['start_date']) : $startOfWeek;
                            
                            // Determine the effective start date for this week
                            $effectiveStartDate = max($startOfWeek, $internStartDate);
                            
                            // Generate days from effective start date to Friday
                            $currentDate = $effectiveStartDate;
                            while ($currentDate <= $endOfWeek) {
                                $weekdays[] = date('Y-m-d', $currentDate);
                                $currentDate = strtotime('+1 day', $currentDate);
                            }
                            
                            // Get existing data for pre-filling
                            $attendanceByDate = [];
                            foreach ($weeklyAttendance as $record) {
                                $attendanceByDate[$record['date']] = $record;
                            }
                            
                            foreach ($weekdays as $date): 
                                $record = $attendanceByDate[$date] ?? null;
                                $isToday = $date === date('Y-m-d');
                                $isPast = $date < date('Y-m-d');
                                $isFuture = $date > date('Y-m-d');
                                $dayName = date('l', strtotime($date));
                                
                                // Determine row classes
                                $rowClasses = [];
                                if ($isToday) $rowClasses[] = 'current-day';
                                if ($isFuture) $rowClasses[] = 'future-day';
                                if ($isPast) $rowClasses[] = 'past-day';
                            ?>
                            <tr class="<?php echo implode(' ', $rowClasses); ?>" data-date="<?php echo $date; ?>" data-is-future="<?php echo $isFuture ? 'true' : 'false'; ?>">
                                <td><?php echo date('l, M j', strtotime($date)); ?></td>
                                <td class="time-cell">
                                    <input type="time" class="time-input time-in-input" data-date="<?php echo $date; ?>" 
                                           value="<?php echo $record && $record['time_in'] ? date('H:i', strtotime($record['time_in'])) : ''; ?>" 
                                           placeholder="Time In" <?php echo $isFuture ? 'disabled' : ''; ?>>
                                </td>
                                <td class="time-cell">
                                    <input type="time" class="time-input time-out-input" data-date="<?php echo $date; ?>" 
                                           value="<?php echo $record && $record['time_out'] ? date('H:i', strtotime($record['time_out'])) : ''; ?>" 
                                           placeholder="Time Out" <?php echo $isFuture ? 'disabled' : ''; ?>>
                                </td>
                                <td class="hours-cell">
                                    <span class="calculated-hours" data-date="<?php echo $date; ?>">
                                        <?php echo $record && $record['total_hours'] ? number_format($record['total_hours'], 1) : '0.0'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="task-input-container">
                                        <textarea class="task-input" data-date="<?php echo $date; ?>" placeholder="<?php echo $isFuture ? 'Future date - cannot enter tasks yet' : "Enter tasks for $dayName..."; ?>" <?php echo $isFuture ? 'disabled' : ''; ?>><?php echo htmlspecialchars($record ? ($record['tasks'] ?: '') : ''); ?></textarea>
                                        <button class="save-row-btn" data-date="<?php echo $date; ?>" <?php echo $isFuture ? 'disabled' : ''; ?>>
                                            <i class="fas fa-save"></i>
                                        </button>
                                    </div>
                                </td>
                                <td>
                                    <select class="status-select" data-date="<?php echo $date; ?>" <?php echo $isFuture ? 'disabled' : ''; ?>>
                                        <option value="office" <?php echo (!$record || ($record && strpos($record['status'], 'office') !== false)) ? 'selected' : ''; ?>>Office</option>
                                        <option value="wfh" <?php echo ($record && strpos($record['status'], 'wfh') !== false) ? 'selected' : ''; ?>>Work From Home</option>
                                        <option value="absent" <?php echo ($record && strpos($record['status'], 'absent') !== false) ? 'selected' : ''; ?>>Absent</option>
                                        <option value="leave" <?php echo ($record && strpos($record['status'], 'leave') !== false) ? 'selected' : ''; ?>>Leave</option>
                                        <option value="holiday" <?php echo ($record && strpos($record['status'], 'holiday') !== false) ? 'selected' : ''; ?>>Holiday</option>
                                    </select>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            
                            <?php 
                            // Add hidden placeholder rows to ensure we always have 5 rows total for JavaScript compatibility
                            $currentRowCount = count($weekdays);
                            for ($i = $currentRowCount; $i < 5; $i++): 
                            ?>
                            <tr style="display: none;" data-placeholder="true">
                                <td>-</td>
                                <td class="time-cell"><input type="time" class="time-input time-in-input" disabled></td>
                                <td class="time-cell"><input type="time" class="time-input time-out-input" disabled></td>
                                <td class="hours-cell"><span class="calculated-hours">0.0</span></td>
                                <td>
                                    <div class="task-input-container">
                                        <textarea class="task-input" disabled></textarea>
                                        <button class="save-row-btn" disabled><i class="fas fa-save"></i></button>
                                    </div>
                                </td>
                                <td><select class="status-select" disabled><option value="office">Office</option></select></td>
                            </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
                <div class="weekly-summary">
                    <div class="summary-box">
                        <span class="summary-label">Week's Progress</span>
                        <div class="summary-progress">
                            <?php
                            // Calculate weekly hours from the actual weekday records
                            $weeklyHours = 0;
                            foreach ($weekdays as $date) {
                                if (isset($attendanceByDate[$date]) && $attendanceByDate[$date]['total_hours']) {
                                    $weeklyHours += floatval($attendanceByDate[$date]['total_hours']);
                                }
                            }
                            $weeklyTarget = 40; // 8 hours * 5 days
                            $weeklyProgress = $weeklyTarget > 0 ? min(100, ($weeklyHours / $weeklyTarget) * 100) : 0;
                            ?>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: <?php echo $weeklyProgress; ?>%"></div>
                            </div>
                            <span class="progress-text"><?php echo number_format($weeklyHours, 1); ?> / <?php echo $weeklyTarget; ?> hours</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Change PIN Modal -->
    <div id="changePinModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-key"></i> Change PIN</h2>
                <button class="close-btn" onclick="closeModal('changePinModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form id="changePinForm">
                <div class="form-group">
                    <label for="currentPin">Current PIN</label>
                    <input type="password" id="currentPin" name="currentPin" minlength="4" maxlength="6" required>
                </div>
                <div class="form-group">
                    <label for="newPin">New PIN</label>
                    <input type="password" id="newPin" name="newPin" minlength="4" maxlength="6" required>
                </div>
                <div class="form-group">
                    <label for="confirmPin">Confirm New PIN</label>
                    <input type="password" id="confirmPin" name="confirmPin" minlength="4" maxlength="6" required>
                </div>
                <div class="form-actions">
                    <button type="button" class="cancel-btn" onclick="closeModal('changePinModal')">Cancel</button>
                    <button type="submit" class="save-btn">Update PIN</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Completion Congratulations Modal -->
    <div id="completionModal" class="modal completion-modal">
        <div class="modal-content completion-content">
            <div class="completion-header">
                <div class="completion-icon">✓</div>
                <h2>Internship Complete</h2>
                <button class="close-btn" onclick="closeModal('completionModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="completion-body">
                <div class="achievement-badge">
                    <i class="fas fa-check-circle"></i>
                    <span>Successfully Completed</span>
                </div>
                <p class="completion-message">
                    Congratulations, <strong><?php echo htmlspecialchars($intern['name'] ?? 'Intern'); ?></strong>!<br>
                    You have completed your <strong><?php echo $intern['required_hours'] ?? 0; ?> hours</strong> internship requirement.<br>
                    <span style="color: #6c757d; font-style: italic; margin-top: 0.5rem; display: block;">Good luck on your future endeavors!</span>
                </p>
                <div class="completion-stats">
                    <div class="stat-item">
                        <span class="stat-value" id="finalHours"><?php echo number_format($completedHours, 1); ?></span>
                        <span class="stat-label">Hours Completed</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-value" id="finalPercentage"><?php echo $progressPercentage; ?>%</span>
                        <span class="stat-label">Progress</span>
                    </div>
                </div>
                <p class="next-steps">
                    Your supervisor has been notified. You may continue logging hours and your final evaluation will be processed.
                </p>
            </div>
            <div class="completion-actions">
                <button class="celebrate-btn" onclick="closeModal('completionModal')">
                    <i class="fas fa-check"></i> Continue
                </button>
            </div>
        </div>
    </div>

    <!-- DTR Generation Modal -->
    <div id="dtrModal" class="modal">
        <div class="modal-content dtr-modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-file-alt"></i> Generate Daily Time Record (DTR)</h2>
                <button class="close-btn" onclick="closeModal('dtrModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="dtr-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="dtrMonth">Select Month (Current Year: <span id="currentYear"></span>)</label>
                            <select id="dtrMonth" name="dtrMonth" required>
                                <option value="01">January</option>
                                <option value="02">February</option>
                                <option value="03">March</option>
                                <option value="04">April</option>
                                <option value="05">May</option>
                                <option value="06">June</option>
                                <option value="07">July</option>
                                <option value="08">August</option>
                                <option value="09">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                        </div>
                    </div>
                    <div class="dtr-info">
                        <div class="info-box">
                            <i class="fas fa-info-circle"></i>
                            <span>DTR will be generated for the selected month from the 1st to the last day.</span>
                        </div>
                        <div class="selected-period" id="selectedPeriodDisplay">
                            <strong>Selected Period:</strong> <span id="periodText">-</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-actions">
                <button type="button" class="cancel-btn" onclick="closeModal('dtrModal')">Cancel</button>
                <button type="button" class="generate-btn" onclick="generateDTR()">
                    <i class="fas fa-file-alt"></i> Generate Time Sheet
                </button>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="footer-content">
            &copy; 2025 DICT &bull; Reginaldo &bull; Tesorero | All rights reserved
        </div>
    </footer>

    <!-- Printable Weekly Report -->
    <div id="printable-weekly-report" style="display: none;">
        <div style="display: flex; flex-direction: column; min-height: 100vh; font-family: Arial, sans-serif; color: #222;">
            <!-- Header Section -->
            <div style="text-align: center; margin-bottom: 20px;">
                <img src="img/header.png" alt="DICT Header" style="width: 500px; margin: 0 auto;">
                <h3 style="margin: 40px 0 20px 0; font-weight: bold; font-family: Cambria, serif; font-size: 20px;">WEEKLY ACCOMPLISHMENT REPORT</h3>
            </div>
            
            <!-- Content Section -->
            <div style="flex: 1; padding: 0 20px;">
                <div class="student-info" style="margin-bottom: 15px; font-family: Cambria, serif; font-size: 18px; text-align: left;">
                    <div><strong>Name of Student:</strong> <span style="text-decoration: underline;"><?php echo htmlspecialchars($intern['name']); ?></span></div>
                    <div><strong>Department Assigned:</strong> <span style="text-decoration: underline;">ILCDB</span></div>
                </div>
                
                <table id="print-table" class="report-table" style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-family: Cambria, serif; font-size: 16px; border: 2px solid #222;">
                    <thead>
                        <tr style="border: 2px solid #222;">
                            <th colspan="5" style="border: 2px solid #222; border-bottom: 1px solid #222; padding: 8px; background: #f8f8f8; font-weight: bold; font-size: 20px; text-align: center;">Week No. <span id="print-week-label">1</span></th>
                        </tr>
                        <tr style="border: 2px solid #222;">
                            <th style="border: 1px solid #222; border-bottom: 2px solid #222; padding: 8px; width: 18%; font-weight: bold; font-size: 16px; text-align: center;">Date</th>
                            <th style="border: 1px solid #222; border-bottom: 2px solid #222; padding: 8px; width: 15%; font-weight: bold; font-size: 16px; text-align: center;">Time in</th>
                            <th style="border: 1px solid #222; border-bottom: 2px solid #222; padding: 8px; width: 15%; font-weight: bold; font-size: 16px; text-align: center;">Time out</th>
                            <th style="border: 1px solid #222; border-bottom: 2px solid #222; padding: 8px; width: 12%; font-weight: bold; font-size: 16px; text-align: center;">No. of Hours</th>
                            <th style="border: 1px solid #222; border-bottom: 2px solid #222; padding: 8px; width: 40%; font-weight: bold; font-size: 16px; text-align: center;">Tasks</th>
                        </tr>
                    </thead>
                    <tbody id="print-table-body">
                        <!-- Table rows will be populated by JavaScript -->
                    </tbody>
                </table>
                
                <div style="margin: 20px 0; font-family: Cambria, serif; font-size: 18px; text-align: right;">
                    <strong>Weekly Total:</strong> <span id="print-weekly-total">0</span> Hours and <span id="print-weekly-minutes">0</span> Minutes<br>
                    <strong>Total Hours Completed:</strong> <span id="print-cumulative-hours">0</span> Hours and <span id="print-cumulative-minutes">0</span> Minutes<br>
                    <strong>Hours Remaining:</strong> <span id="print-remaining-hours">0</span> Hours
                </div>
                
            </div>
            
            <!-- Footer Section - Always at bottom -->
            <div class="footer-section">
                <!-- Reviewed By Section -->
                <div style="margin-bottom: 20px; font-family: Arial, sans-serif; font-size: 17px; text-align: left;">
                    <div style="margin-bottom: 5px;"><strong>Reviewed By:</strong></div>
                    <div style="border-bottom: 1px solid #222; width: 300px; height: 20px; margin: 10px 0;"></div>
                    <div style="font-weight: bold;">Mr. Edd Fernan D. Gonzales</div>
                    <div>DICT Rizal Provincial Officer</div>
                </div>
                
                <!-- Contact Information Footer -->
                <div class="footer-content">
                    <img src="img/footer.png" alt="DICT Footer" style="width: 550px; max-width: 550px; display: block; margin: 0 auto;">
                </div>
            </div>
        </div>
    </div>

    <link rel="stylesheet" href="css/intern-dashboard-print.css">
    

    <!-- External JavaScript Files -->
    <script src="js/intern-dashboard-utils.js"></script>
    <script src="js/intern-dashboard.js"></script>
    <script src="js/intern-dashboard-dtr.js"></script>
    <script src="js/intern-dashboard-init.js"></script>
    
    <script>
        // Global variables for external scripts
        window.internName = '<?php echo htmlspecialchars($intern['name'] ?? 'Unknown Intern'); ?>';
        window.internStartDate = '<?php echo $intern['start_date'] ?? ''; ?>';
        window.completedHours = <?php echo floatval($completedHours); ?>;
        window.requiredHours = <?php echo floatval($intern['required_hours'] ?? 0); ?>;
    </script>
</body>
</html>