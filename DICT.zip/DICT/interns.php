<?php
session_start();
require_once 'config/database.php';

// Verify if user is logged in as admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

// Get admin name from session
$adminName = htmlspecialchars($_SESSION['user_name'] ?? 'Admin');

// Helper function to format hours without unnecessary decimals
function formatHours($hours) {
    return $hours == floor($hours) ? (string)floor($hours) : rtrim(rtrim(number_format($hours, 1), '0'), '.');
}

// Fetch interns data
try {
    $stmt = $pdo->query("
        SELECT 
            i.*,
            (SELECT COUNT(*) FROM attendance_logs 
             WHERE user_type = 'intern' AND user_id = i.id 
             AND date = CURRENT_DATE) as present_today,
            (SELECT TIME_FORMAT(time_in, '%h:%i %p') FROM attendance_logs 
             WHERE user_type = 'intern' AND user_id = i.id 
             AND date = CURRENT_DATE LIMIT 1) as today_time_in,
            (SELECT TIME_FORMAT(time_out, '%h:%i %p') FROM attendance_logs 
             WHERE user_type = 'intern' AND user_id = i.id 
             AND date = CURRENT_DATE LIMIT 1) as today_time_out,
            (SELECT status FROM attendance_logs 
             WHERE user_type = 'intern' AND user_id = i.id 
             AND date = CURRENT_DATE LIMIT 1) as today_status
        FROM interns i
        ORDER BY i.status ASC, i.name ASC
    ");
    $interns = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Error fetching interns: " . $e->getMessage());
    $interns = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DICT Interns Management</title>
    <link rel="stylesheet" href="css/admin-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header>
        <div class="logo-left">
            <a href="admin-dashboard.php">
                <img src="img/dict-logo.png" alt="DICT Logo" class="header-logo">
            </a>
        </div>

        <div class="header-content">
            <h1>Interns Management</h1>
            <div class="subheading">Department of Information and Communications Technology | ILCDB</div>
        </div>

        <div class="profile-dropdown">
            <img src="img/profile.png" id="profileButton" alt="Profile" class="profile-img">
            <div id="dropdownMenu" class="dropdown-content">
                <div class="admin-info">
                    <i class="fas fa-user-shield"></i>
                    <span>Welcome, <strong><?php echo $adminName; ?></strong></span>
                </div>
                <a href="#" onclick="openChangePinModal()"><i class="fas fa-key"></i>Change PIN</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
            </div>
        </div>
    </header>

    <nav class="dashboard-nav">
        <a href="admin-dashboard.php" class="nav-item">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </a>
        <div class="nav-item active">
            <i class="fas fa-users"></i>
            <span>Interns</span>
        </div>
        <a href="employee-management.php" class="nav-item">
            <i class="fas fa-user-tie"></i>
            <span>Employees</span>
        </a>
    </nav>

    <main class="dashboard-layout">
        <!-- Internship Completion Stats Section -->
        <div class="completion-stats-section">
            <div class="section-header">
                <h2><i class="fas fa-graduation-cap"></i> Internship Completions</h2>
            </div>
            <div class="completion-quick-stats">
                <div class="completion-stat-card">
                    <div class="stat-icon completed">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <div class="stat-info">
                        <h3>This Week</h3>
                        <p class="stat-number" id="completedThisWeek">0</p>
                        <span class="stat-label">Completed</span>
                    </div>
                </div>
                <div class="completion-stat-card">
                    <div class="stat-icon month">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div class="stat-info">
                        <h3>This Month</h3>
                        <p class="stat-number" id="completedThisMonth">0</p>
                        <span class="stat-label">Completed</span>
                    </div>
                </div>
                <div class="completion-stat-card">
                    <div class="stat-icon total">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total</h3>
                        <p class="stat-number" id="totalCompleted">0</p>
                        <span class="stat-label">Graduated</span>
                    </div>
                </div>
                <div class="completion-stat-card">
                    <div class="stat-icon pending">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Pending</h3>
                        <p class="stat-number" id="pendingGraduation">0</p>
                        <span class="stat-label">Graduation</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="dashboard-card full-width">
            <div class="card-header">
                <h2><i class="fas fa-users"></i> Interns List</h2>
                <div class="card-actions">
                    <input type="text" placeholder="Search interns..." class="search-input" id="searchInterns">
                    <select class="filter-select" id="statusFilter">
                        <option value="all">All Interns</option>
                        <option value="active">Active</option>
                        <option value="completed">Completed</option>
                    </select>

                    <button class="action-btn primary" onclick="openRegisterModal()">
                        <i class="fas fa-user-plus"></i>
                        Register New Intern
                    </button>
                </div>
            </div>
            <div class="table-container">
                <table class="attendance-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>School</th>
                            <th>Start Date</th>
                            <th>Required Hours</th>
                            <th>Completed Hours</th>
                            <th>Remaining Hours</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="internsData">
                        <?php foreach ($interns as $intern): ?>
                            <?php 
                                $remainingHours = max(0, $intern['required_hours'] - $intern['completed_hours']);
                                $isNearCompletion = $remainingHours <= 20 && $remainingHours > 0;
                            ?>
                            <tr data-status="<?php echo htmlspecialchars($intern['status']); ?>">
                                <td><?php echo htmlspecialchars($intern['name']); ?></td>
                                <td><?php echo htmlspecialchars($intern['school']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($intern['start_date'])); ?></td>
                                <td><?php echo formatHours($intern['required_hours']); ?></td>
                                <td><?php echo formatHours($intern['completed_hours']); ?></td>
                                <td>
                                    <span class="remaining-hours <?php echo $isNearCompletion ? 'near-completion' : ''; ?>" title="<?php echo $isNearCompletion ? 'Near graduation!' : ''; ?>">
                                        <?php 
                                            if ($remainingHours == 0) {
                                                echo '<i class="fas fa-check-circle"></i> Complete';
                                            } else {
                                                echo formatHours($remainingHours);
                                            }
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="status-badge <?php echo $intern['status']; ?>">
                                        <?php echo ucfirst($intern['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="action-btn" onclick="viewInternDetails(<?php echo $intern['id']; ?>)" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="action-btn" onclick="editIntern(<?php echo $intern['id']; ?>)" title="Edit Intern">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Register Intern Modal -->
    <div id="registerModal" class="modal">
        <div class="modal-content modal-wide">
            <div class="modal-header">
                <h2><i class="fas fa-user-plus"></i> Register New Intern</h2>
                <button class="close-btn" onclick="closeModal('registerModal')"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <form id="registerInternForm" method="POST" action="register_intern.php">
                    <div class="form-grid">
                        <div class="form-section">
                            <h3><i class="fas fa-user"></i> Personal Information</h3>
                            <div class="form-group">
                                <label for="name"><i class="fas fa-user"></i> Full Name</label>
                                <input type="text" id="name" name="name" required placeholder="Enter full name">
                            </div>
                            <div class="form-group">
                                <label for="school"><i class="fas fa-graduation-cap"></i> School</label>
                                <input type="text" id="school" name="school" required placeholder="Enter school name">
                            </div>
                            <div class="form-group">
                                <label for="card_uid"><i class="fas fa-id-card"></i> NFC Card UID</label>
                                <input type="text" id="card_uid" name="card_uid" required placeholder="Enter card UID">
                            </div>
                        </div>

                        <div class="form-section">
                            <h3><i class="fas fa-key"></i> Access Information</h3>
                            <div class="form-group">
                                <label for="pin"><i class="fas fa-lock"></i> PIN</label>
                                <input type="password" id="pin" name="pin" minlength="4" maxlength="6" required placeholder="Enter 4-6 digit PIN">
                            </div>
                            <div class="form-group">
                                <label for="required_hours"><i class="fas fa-clock"></i> Required Hours</label>
                                <input type="number" id="required_hours" name="required_hours" min="1" required placeholder="Enter total required hours">
                            </div>
                            <div class="form-group">
                                <label for="startDate"><i class="fas fa-calendar-plus"></i> Start Date</label>
                                <input type="date" id="startDate" name="start_date" required>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('registerModal')">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="submit" form="registerInternForm" class="btn-primary">
                    <i class="fas fa-user-plus"></i> Register Intern
                </button>
            </div>
        </div>
    </div>

    <!-- Change PIN Modal -->
    <div id="changePinModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-key"></i> Change PIN</h2>
                <button class="close-btn" onclick="closeModal('changePinModal')"><i class="fas fa-times"></i></button>
            </div>
            <form id="changePinForm">
                <div class="form-group">
                    <label for="currentPin">Current PIN</label>
                    <input type="password" id="currentPin" name="currentPin" minlength="4" maxlength="6" required>
                </div>
                <div class="form-group">
                    <label for="newPin">New PIN</label>
                    <input type="password" id="newPin" name="newPin" minlength="4" maxlength="6" required>
                </div>
                <div class="form-group">
                    <label for="confirmPin">Confirm New PIN</label>
                    <input type="password" id="confirmPin" name="confirmPin" minlength="4" maxlength="6" required>
                </div>
                <div class="form-actions">
                    <button type="button" class="cancel-btn" onclick="closeModal('changePinModal')">Cancel</button>
                    <button type="submit" class="save-btn">Update PIN</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Intern Modal -->
    <div id="editInternModal" class="modal">
        <div class="modal-content modal-wide">
            <div class="modal-header">
                <h2><i class="fas fa-user-edit"></i> Edit Intern Information</h2>
                <button class="close-btn" onclick="closeModal('editInternModal')"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <form id="editInternForm">
                    <input type="hidden" id="editInternId" name="intern_id">
                    
                    <div class="form-grid">
                        <div class="form-section">
                            <h3><i class="fas fa-user"></i> Personal Information</h3>
                            <div class="form-group">
                                <label for="editName"><i class="fas fa-user"></i> Full Name</label>
                                <input type="text" id="editName" name="name" required placeholder="Enter full name">
                            </div>
                            <div class="form-group">
                                <label for="editSchool"><i class="fas fa-graduation-cap"></i> School</label>
                                <input type="text" id="editSchool" name="school" required placeholder="Enter school name">
                            </div>
                            <div class="form-group">
                                <label for="editCardUid"><i class="fas fa-id-card"></i> NFC Card UID</label>
                                <input type="text" id="editCardUid" name="card_uid" required placeholder="Enter card UID">
                            </div>
                        </div>

                        <div class="form-section">
                            <h3><i class="fas fa-calendar-alt"></i> Internship Details</h3>
                            <div class="form-group">
                                <label for="editRequiredHours"><i class="fas fa-clock"></i> Required Hours</label>
                                <input type="number" id="editRequiredHours" name="required_hours" min="1" required placeholder="Enter required hours">
                            </div>
                            <div class="form-group">
                                <label for="editStartDate"><i class="fas fa-calendar-plus"></i> Start Date</label>
                                <input type="date" id="editStartDate" name="start_date" required>
                            </div>
                            <div class="form-group">
                                <label for="editStatus"><i class="fas fa-info-circle"></i> Status</label>
                                <select id="editStatus" name="status" required>
                                    <option value="active">Active</option>
                                    <option value="completed">Completed</option>
                                    <option value="suspended">Suspended</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal('editInternModal')">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button type="submit" form="editInternForm" class="btn-primary">
                    <i class="fas fa-save"></i> Update Intern
                </button>
            </div>
        </div>
    </div>

    <!-- Attendance History Modal -->
    <div id="attendanceHistoryModal" class="modal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h2><i class="fas fa-history"></i> Attendance History</h2>
                <button class="close-btn" onclick="closeModal('attendanceHistoryModal')"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <div class="history-header">
                    <div class="intern-info">
                        <h3 id="historyInternName">Intern Name</h3>
                        <p id="historyInternDetails">Loading...</p>
                    </div>
                    <div class="history-stats">
                        <div class="stat-item">
                            <label>Total Days:</label>
                            <span id="historyTotalDays">-</span>
                        </div>
                        <div class="stat-item">
                            <label>Present Days:</label>
                            <span id="historyPresentDays">-</span>
                        </div>
                        <div class="stat-item">
                            <label>Total Hours:</label>
                            <span id="historyTotalHours">-</span>
                        </div>
                        <div class="stat-item">
                            <label>Attendance Rate:</label>
                            <span id="historyAttendanceRate">-</span>
                        </div>
                    </div>
                </div>
                
                <div class="history-filters">
                    <input type="date" id="historyFromDate" placeholder="From Date">
                    <input type="date" id="historyToDate" placeholder="To Date">
                    <select id="historyStatusFilter">
                        <option value="all">All Status</option>
                        <option value="on_time">On Time</option>
                        <option value="late">Late</option>
                        <option value="early_departure">Early Departure</option>
                    </select>
                    <button class="btn-secondary" onclick="filterAttendanceHistory()">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                </div>

                <div class="table-container">
                    <table class="attendance-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Day</th>
                                <th>Time In</th>
                                <th>Time Out</th>
                                <th>Hours</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody id="historyTableBody">
                            <tr>
                                <td colspan="6" class="loading-row">Loading attendance records...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-secondary" onclick="closeModal('attendanceHistoryModal')">Close</button>
                <button class="btn-primary" onclick="goBackToInternDetails()">
                    <i class="fas fa-arrow-left"></i> Back to Details
                </button>
            </div>
        </div>
    </div>

    <!-- Intern Details Modal -->
    <div id="internDetailsModal" class="modal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h2><i class="fas fa-user-graduate"></i> Intern Details</h2>
                <button class="close-btn" onclick="closeModal('internDetailsModal')"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <div class="details-grid">
                    <div class="detail-section">
                        <h3><i class="fas fa-user"></i> Personal Information</h3>
                        <div class="detail-item">
                            <label>Name:</label>
                            <span id="internDetailName">-</span>
                        </div>
                        <div class="detail-item">
                            <label>School:</label>
                            <span id="internDetailSchool">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Card UID:</label>
                            <span id="internDetailCardUid">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Status:</label>
                            <span id="internDetailStatus" class="status-badge">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Intern ID:</label>
                            <span id="internDetailId">-</span>
                        </div>
                    </div>

                    <div class="detail-section">
                        <h3><i class="fas fa-calendar-alt"></i> Internship Information</h3>
                        <div class="detail-item">
                            <label>Start Date:</label>
                            <span id="internDetailStartDate">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Required Hours:</label>
                            <span id="internDetailRequiredHours">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Completed Hours:</label>
                            <span id="internDetailCompletedHours">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Remaining Hours:</label>
                            <span id="internDetailRemainingHours">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Progress:</label>
                            <span id="internDetailProgress">-</span>
                        </div>
                    </div>

                    <div class="detail-section full-width">
                        <h3><i class="fas fa-clock"></i> Today's Attendance</h3>
                        <div class="detail-item">
                            <label>Present Today:</label>
                            <span id="internDetailPresentToday">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Time In:</label>
                            <span id="internDetailTimeIn">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Time Out:</label>
                            <span id="internDetailTimeOut">-</span>
                        </div>
                        <div class="detail-item">
                            <label>Today's Status:</label>
                            <span id="internDetailTodayStatus" class="status-badge">-</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-secondary" onclick="closeModal('internDetailsModal')">Close</button>
                <button class="btn-primary" onclick="viewAttendanceHistory(getCurrentInternId())">
                    <i class="fas fa-history"></i> View History
                </button>
            </div>
        </div>
    </div>

    <footer>
        &copy; 2025 DICT &bull; Reginaldo &bull; Tesorero | All rights reserved
    </footer>

    <script>
        // Helper function to format hours without unnecessary decimals
        function formatHours(hours) {
            return hours % 1 === 0 ? Math.floor(hours).toString() : hours.toFixed(1);
        }

        document.addEventListener('DOMContentLoaded', function() {
            // Profile dropdown
            const profileButton = document.getElementById('profileButton');
            const dropdownMenu = document.getElementById('dropdownMenu');

            profileButton.addEventListener('click', function() {
                dropdownMenu.classList.toggle('show');
            });

            // Close dropdown when clicking outside
            window.addEventListener('click', function(e) {
                if (!e.target.matches('#profileButton')) {
                    if (dropdownMenu.classList.contains('show')) {
                        dropdownMenu.classList.remove('show');
                    }
                }
            });

            // Search functionality
            const searchInput = document.getElementById('searchInterns');
            const statusFilter = document.getElementById('statusFilter');
            const rows = document.querySelectorAll('#internsData tr');

            function filterTable() {
                const searchTerm = searchInput.value.toLowerCase();
                const statusValue = statusFilter.value;

                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    const status = row.dataset.status;
                    const matchesSearch = text.includes(searchTerm);
                    const matchesStatus = statusValue === 'all' || status === statusValue;

                    row.style.display = matchesSearch && matchesStatus ? '' : 'none';
                });
            }

            searchInput.addEventListener('input', filterTable);
            statusFilter.addEventListener('change', filterTable);

            // Handle PIN change form submission
            const changePinForm = document.getElementById('changePinForm');
            if (changePinForm) {
                changePinForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const currentPin = document.getElementById('currentPin').value;
                    const newPin = document.getElementById('newPin').value;
                    const confirmPin = document.getElementById('confirmPin').value;
                    
                    if (newPin !== confirmPin) {
                        alert('New PIN and Confirm PIN do not match!');
                        return;
                    }
                    
                    // Show loading state
                    const submitBtn = e.target.querySelector('.save-btn');
                    if (submitBtn) {
                        submitBtn.disabled = true;
                        submitBtn.textContent = 'Updating...';
                    }
                    
                    fetch('change_pin.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify({
                            currentPin: currentPin,
                            newPin: newPin
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('PIN updated successfully!');
                            closeModal('changePinModal');
                        } else {
                            alert(data.message || 'Failed to update PIN. Please try again.');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while updating PIN. Please try again.');
                    })
                    .finally(() => {
                        // Reset button state
                        if (submitBtn) {
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'Update PIN';
                        }
                    });
                });
            }
        });

        function openRegisterModal() {
            document.getElementById('registerModal').style.display = 'flex';
            document.getElementById('registerInternForm').reset();
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function openChangePinModal() {
            document.getElementById('changePinModal').style.display = 'flex';
            const changePinForm = document.getElementById('changePinForm');
            if (changePinForm) {
                changePinForm.reset();
            }
        }

        let currentInternId = null;



        function viewInternDetails(id) {
            // Find the intern record from the current data
            const internRecords = <?php echo json_encode($interns); ?>;
            const intern = internRecords.find(i => i.id == id);
            
            if (!intern) {
                alert('Intern record not found!');
                return;
            }
            
            currentInternId = id;
            
            // Populate the modal with data
            populateInternModal(intern);
            
            // Show the modal
            document.getElementById('internDetailsModal').style.display = 'flex';
        }

        function populateInternModal(intern) {
            // Personal Information
            document.getElementById('internDetailName').textContent = intern.name || '-';
            document.getElementById('internDetailSchool').textContent = intern.school || '-';
            document.getElementById('internDetailCardUid').textContent = intern.card_uid || '-';
            document.getElementById('internDetailId').textContent = intern.id || '-';
            
            // Status badge
            const statusElement = document.getElementById('internDetailStatus');
            statusElement.textContent = ucfirst(intern.status);
            statusElement.className = 'status-badge ' + intern.status;
            
            // Internship Information
            const startDate = new Date(intern.start_date);
            document.getElementById('internDetailStartDate').textContent = startDate.toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
            
            const requiredHours = parseFloat(intern.required_hours);
            const completedHours = parseFloat(intern.completed_hours);
            const remainingHours = Math.max(0, requiredHours - completedHours);
            const progress = requiredHours > 0 ? ((completedHours / requiredHours) * 100).toFixed(1) : 0;
            
            document.getElementById('internDetailRequiredHours').textContent = formatHours(requiredHours) + ' hours';
            document.getElementById('internDetailCompletedHours').textContent = formatHours(completedHours) + ' hours';
            
            // Format remaining hours with special styling for near completion
            const remainingElement = document.getElementById('internDetailRemainingHours');
            if (remainingHours === 0) {
                remainingElement.innerHTML = '<i class="fas fa-check-circle" style="color: var(--success-green);"></i> Complete';
            } else {
                const isNearCompletion = remainingHours <= 20;
                remainingElement.innerHTML = formatHours(remainingHours) + ' hours' + 
                    (isNearCompletion ? ' <i class="fas fa-exclamation-triangle" style="color: #e65100;" title="Near graduation!"></i>' : '');
            }
            
            document.getElementById('internDetailProgress').textContent = progress + '%';
            
            // Today's Attendance
            document.getElementById('internDetailPresentToday').textContent = intern.present_today > 0 ? 'Yes' : 'No';
            document.getElementById('internDetailTimeIn').textContent = intern.today_time_in || 'Not recorded';
            document.getElementById('internDetailTimeOut').textContent = intern.today_time_out || 'Not recorded';
            
            // Today's status badge
            const todayStatusElement = document.getElementById('internDetailTodayStatus');
            if (intern.today_status) {
                todayStatusElement.textContent = ucfirst(intern.today_status.replace('_', ' '));
                todayStatusElement.className = 'status-badge ' + intern.today_status;
            } else {
                todayStatusElement.textContent = 'Not recorded';
                todayStatusElement.className = 'status-badge';
            }
        }

        function getCurrentInternId() {
            return currentInternId;
        }

        function editIntern(id) {
            // Find the intern record from the current data
            const internRecords = <?php echo json_encode($interns); ?>;
            const intern = internRecords.find(i => i.id == id);
            
            if (!intern) {
                alert('Intern record not found!');
                return;
            }
            
            // Populate the edit form with current data
            populateEditForm(intern);
            
            // Show the edit modal
            document.getElementById('editInternModal').style.display = 'flex';
        }

        function populateEditForm(intern) {
            document.getElementById('editInternId').value = intern.id;
            document.getElementById('editName').value = intern.name || '';
            document.getElementById('editSchool').value = intern.school || '';
            document.getElementById('editCardUid').value = intern.card_uid || '';
            document.getElementById('editRequiredHours').value = intern.required_hours || '';
            document.getElementById('editStartDate').value = intern.start_date || '';
            document.getElementById('editStatus').value = intern.status || 'active';
        }

        function viewAttendanceHistory(id) {
            // Close the details modal first to prevent overlap
            closeModal('internDetailsModal');
            
            // Set current intern ID for navigation
            currentInternId = id;
            
            // Find the intern record
            const internRecords = <?php echo json_encode($interns); ?>;
            const intern = internRecords.find(i => i.id == id);
            
            if (!intern) {
                alert('Intern record not found!');
                return;
            }
            
            // Populate header info
            document.getElementById('historyInternName').textContent = intern.name;
            document.getElementById('historyInternDetails').textContent = 
                `${intern.school} • Started: ${new Date(intern.start_date).toLocaleDateString()}`;
            
            // Show the attendance history modal
            document.getElementById('attendanceHistoryModal').style.display = 'flex';
            
            // Load attendance data
            loadAttendanceHistory(id);
        }

        function loadAttendanceHistory(internId) {
            // Show loading state
            document.getElementById('historyTableBody').innerHTML = 
                '<tr><td colspan="6" class="loading-row">Loading attendance records...</td></tr>';
            
            // Fetch attendance data
            fetch(`get_intern_attendance_history.php?intern_id=${internId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        populateAttendanceHistory(data.records, data.stats);
                    } else {
                        document.getElementById('historyTableBody').innerHTML = 
                            '<tr><td colspan="6" class="error-row">Failed to load attendance records</td></tr>';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('historyTableBody').innerHTML = 
                        '<tr><td colspan="6" class="error-row">Error loading attendance records</td></tr>';
                });
        }

        function populateAttendanceHistory(records, stats) {
            // Update statistics
            document.getElementById('historyTotalDays').textContent = stats.total_days || '0';
            document.getElementById('historyPresentDays').textContent = stats.present_days || '0';
            
            const totalHours = stats.total_hours || 0;
            document.getElementById('historyTotalHours').textContent = formatHours(totalHours) + ' hrs';
            document.getElementById('historyAttendanceRate').textContent = (stats.attendance_rate || 0).toFixed(1) + '%';
            
            // Populate table
            const tableBody = document.getElementById('historyTableBody');
            
            if (records.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="6" class="no-data-row">No attendance records found</td></tr>';
                return;
            }
            
            tableBody.innerHTML = records.map(record => {
                const date = new Date(record.date);
                const dayName = date.toLocaleDateString('en-US', { weekday: 'long' });
                const formattedDate = date.toLocaleDateString('en-US', { 
                    month: 'short', 
                    day: 'numeric', 
                    year: 'numeric' 
                });
                
                return `
                    <tr>
                        <td>${formattedDate}</td>
                        <td>${dayName}</td>
                        <td>${record.time_in || '-'}</td>
                        <td>${record.time_out || '-'}</td>
                        <td>${record.total_hours ? formatHours(parseFloat(record.total_hours)) + 'h' : '-'}</td>
                        <td><span class="status-badge ${record.status}">${ucfirst(record.status.replace('_', ' '))}</span></td>
                    </tr>
                `;
            }).join('');
        }





        function goBackToInternDetails() {
            // Close history modal and reopen details modal
            closeModal('attendanceHistoryModal');
            if (currentInternId) {
                viewInternDetails(currentInternId);
            }
        }

        function ucfirst(str) {
            return str.charAt(0).toUpperCase() + str.slice(1);
        }

        // Handle intern registration form submission
        document.getElementById('registerInternForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('register_intern.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    closeModal('registerModal');
                    // Reload the page to show the new intern
                    window.location.reload();
                } else {
                    alert(data.message || 'Failed to register intern. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while registering the intern. Please try again.');
            });
        });

        // Handle intern edit form submission
        document.getElementById('editInternForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('update_intern.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    closeModal('editInternModal');
                    // Reload the page to show the updated intern
                    window.location.reload();
                } else {
                    alert(data.message || 'Failed to update intern. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating the intern. Please try again.');
            });
        });

        // === COMPLETION FUNCTIONALITY ===
        
        // Load completion stats on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadCompletionStats();
            
            // Auto-refresh completion stats every 30 seconds
            setInterval(function() {
                loadCompletionStats();
            }, 30000);
        });

        function loadCompletionStats() {
            fetch('get_admin_notifications.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.completion_stats) {
                        const stats = data.completion_stats;
                        document.getElementById('completedThisWeek').textContent = stats.completed_this_week || 0;
                        document.getElementById('completedThisMonth').textContent = stats.completed_this_month || 0;
                        document.getElementById('totalCompleted').textContent = stats.total_completed || 0;
                        
                        // Calculate pending graduation (completed but not graduated)
                        fetch('get_pending_graduations.php')
                            .then(response => response.json())
                            .then(pendingData => {
                                if (pendingData.success) {
                                    document.getElementById('pendingGraduation').textContent = pendingData.pending_count || 0;
                                }
                            })
                            .catch(error => console.error('Error loading pending graduations:', error));
                    }
                })
                .catch(error => {
                    console.error('Error loading completion stats:', error);
                });
        }


    </script>
</body>
</html> 