// Function to populate attendance table with sample data
function populateAttendanceTable() {
    const attendanceData = document.getElementById('attendanceData');
    
    // Sample data - in a real application, this would come from your backend
    const sampleData = [
        {
            name: "Juan Dela Cruz",
            role: "Intern",
            date: "2024-02-28",
            timeIn: "08:00 AM",
            timeOut: "05:00 PM",
            status: "On Time"
        },
        {
            name: "Maria Santos",
            role: "Employee",
            date: "2024-02-28",
            timeIn: "08:15 AM",
            timeOut: "05:15 PM",
            status: "On Time"
        },
        {
            name: "Pedro Garcia",
            role: "Intern",
            date: "2024-02-28",
            timeIn: "08:45 AM",
            timeOut: "05:45 PM",
            status: "Late"
        },
        {
            name: "Ana Reyes",
            role: "Employee",
            date: "2024-02-28",
            timeIn: "08:05 AM",
            timeOut: "05:00 PM",
            status: "On Time"
        }
    ];

    // Clear existing data
    attendanceData.innerHTML = '';

    // Add new rows
    sampleData.forEach(record => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${record.name}</td>
            <td><span class="role-badge ${record.role.toLowerCase()}">${record.role}</span></td>
            <td>${record.date}</td>
            <td>${record.timeIn}</td>
            <td>${record.timeOut}</td>
            <td><span class="status-badge ${record.status.toLowerCase().replace(' ', '-')}">${record.status}</span></td>
            <td>
                <button class="btn-icon" title="View Details">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn-icon" title="Edit">
                    <i class="fas fa-edit"></i>
                </button>
            </td>
        `;
        attendanceData.appendChild(row);
    });
}

// Add status badge styles
function addStatusBadgeStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .status-badge {
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 0.85em;
            font-weight: 500;
        }
        .status-badge.on-time {
            background-color: #e8f5e9;
            color: #2e7d32;
        }
        .status-badge.late {
            background-color: #fff3e0;
            color: #e65100;
        }
    `;
    document.head.appendChild(style);
}

// Run when page loads
document.addEventListener('DOMContentLoaded', function() {
    populateAttendanceTable();
    addStatusBadgeStyles();
}); 