// Function to populate attendance table with sample data
function populateAttendanceTable() {
    const attendanceData = document.getElementById('attendanceData');
    
    // Sample data - in a real application, this would come from your backend
    const sampleData = [
        {
            name: "Juan Dela Cruz",
            role: "Intern",
            date: "2024-02-28",
            timeIn: "08:00 AM",
            timeOut: "05:00 PM",
            status: "On Time"
        },
        {
            name: "Maria Santos",
            role: "Employee",
            date: "2024-02-28",
            timeIn: "08:15 AM",
            timeOut: "05:15 PM",
            status: "On Time"
        },
        {
            name: "Pedro Garcia",
            role: "Intern",
            date: "2024-02-28",
            timeIn: "08:45 AM",
            timeOut: "05:45 PM",
            status: "Late"
        }
    ];

    // Clear existing data
    attendanceData.innerHTML = '';

    // Add new rows
    sampleData.forEach(record => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${record.name}</td>
            <td><span class="role-badge ${record.role.toLowerCase()}">${record.role}</span></td>
            <td>${record.date}</td>
            <td>${record.timeIn}</td>
            <td>${record.timeOut}</td>
            <td><span class="status-badge ${record.status.toLowerCase().replace(' ', '-')}">${record.status}</span></td>
        `;
        attendanceData.appendChild(row);
    });
}

// Run when page loads
document.addEventListener('DOMContentLoaded', populateAttendanceTable); 