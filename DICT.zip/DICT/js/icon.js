document.addEventListener('DOMContentLoaded', function() {
    const profileButton = document.getElementById('profileButton');
    const dropdownMenu = document.getElementById('dropdownMenu');

    // Only add event listeners if elements exist (user is logged in)
    if (profileButton && dropdownMenu) {
        // Toggle dropdown when clicking the profile image
        profileButton.addEventListener('click', function(e) {
            e.stopPropagation();
            dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!profileButton.contains(e.target)) {
                dropdownMenu.style.display = 'none';
            }
        });
    }
});