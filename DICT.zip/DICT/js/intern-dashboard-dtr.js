// DTR Functionality
function openDTRModal() {
    const now = new Date();
    const currentYear = now.getFullYear();
    
    // Display current year in the label
    document.getElementById('currentYear').textContent = currentYear;
    
    // Set default to previous month (since DTR is usually generated after month ends)
    const lastMonth = now.getMonth() === 0 ? 11 : now.getMonth() - 1;
    document.getElementById('dtrMonth').value = String(lastMonth + 1).padStart(2, '0');
    
    // Update period display
    updatePeriodDisplay();
    
    document.getElementById('dtrModal').style.display = 'flex';
}

function initializeDTRModal() {
    // Month change handler
    document.getElementById('dtrMonth').addEventListener('change', updatePeriodDisplay);
}

function updatePeriodDisplay() {
    const month = document.getElementById('dtrMonth').value;
    const year = new Date().getFullYear(); // Always use current year
    
    if (month) {
        const monthNames = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ];
        
        const monthName = monthNames[parseInt(month) - 1];
        const firstDay = new Date(year, parseInt(month) - 1, 1);
        const lastDay = new Date(year, parseInt(month), 0);
        
        const periodText = `${monthName} ${year} (${firstDay.toLocaleDateString()} - ${lastDay.toLocaleDateString()})`;
        document.getElementById('periodText').textContent = periodText;
    } else {
        document.getElementById('periodText').textContent = '-';
    }
}

function generateDTR() {
    const month = document.getElementById('dtrMonth').value;
    const year = new Date().getFullYear(); // Always use current year
    
    if (!month) {
        alert('Please select a month.');
        return;
    }
    
    // Calculate start and end dates for the ENTIRE selected month
    // Ensure we get the complete month regardless of week boundaries
    const monthNum = parseInt(month);
    const startDate = new Date(year, monthNum - 1, 1); // First day of month
    const endDate = new Date(year, monthNum, 0); // Last day of month (using next month, day 0)
    
    // Convert to strings ensuring we get the full date range
    const startDateString = year + '-' + month.padStart(2, '0') + '-01';
    const lastDay = endDate.getDate().toString().padStart(2, '0');
    const endDateString = year + '-' + month.padStart(2, '0') + '-' + lastDay;
    
    console.log('DTR Generation - Month:', month, 'Year:', year);
    console.log('Start Date:', startDateString, 'End Date:', endDateString);
    console.log('Date objects - Start:', startDate, 'End:', endDate);
    
    // Show loading state
    const generateBtn = document.querySelector('.generate-btn');
    const originalText = generateBtn.innerHTML;
    generateBtn.disabled = true;
    generateBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
    
    // Fetch DTR data
    fetch('get_dtr_data.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            startDate: startDateString,
            endDate: endDateString
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            populateDTRTemplate(data);
            closeModal('dtrModal');
        } else {
            throw new Error(data.message || 'Failed to generate DTR');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to generate DTR: ' + error.message);
    })
    .finally(() => {
        // Reset button state
        generateBtn.disabled = false;
        generateBtn.innerHTML = originalText;
    });
}

function populateDTRTemplate(data) {
    // Create DTR content in a new window
    const dtrWindow = window.open('', '_blank', 'width=1000,height=800');
    
    // Start with hours completed before this month
    let cumulativeHours = parseFloat(data.hoursBeforeMonth || 0);
    let tableRows = '';
    
    // Function to format hours (remove .0 for whole numbers)
    function formatHours(hours) {
        const num = parseFloat(hours);
        return num % 1 === 0 ? num.toString() : num.toFixed(1);
    }
    
    // Generate table rows
    data.dtrData.forEach((record, index) => {
        cumulativeHours += parseFloat(record.hours_rendered || 0);
        
        // Format time for AM/PM display
        function formatTimeForDTR(timeStr) {
            if (!timeStr) return '';
            const time = new Date('2000-01-01 ' + timeStr);
            const hours = time.getHours();
            const minutes = time.getMinutes();
            const displayHours = hours > 12 ? hours - 12 : (hours === 0 ? 12 : hours);
            return `${displayHours}:${minutes.toString().padStart(2, '0')}`;
        }
        
        // Determine AM/PM times
        let amIn = '', amOut = '', pmIn = '', pmOut = '';
        const timeIn = record.time_in;
        const timeOut = record.time_out;
        
        if (timeIn && timeOut) {
            const inTime = new Date('2000-01-01 ' + timeIn);
            const outTime = new Date('2000-01-01 ' + timeOut);
            const inHours = inTime.getHours();
            const outHours = outTime.getHours();
            
            if (inHours < 12) {
                amIn = formatTimeForDTR(timeIn);
                if (outHours < 12) {
                    amOut = formatTimeForDTR(timeOut);
                } else {
                    amOut = '12:00';
                    pmIn = '1:00';
                    pmOut = formatTimeForDTR(timeOut);
                }
            } else {
                pmIn = formatTimeForDTR(timeIn);
                pmOut = formatTimeForDTR(timeOut);
            }
        }
        
        // Handle non-working days
        if (record.work_mode === 'holiday' || record.work_mode === 'leave' || record.work_mode === 'absent') {
            amIn = amOut = pmIn = pmOut = '';
        }
        
        tableRows += `
            <tr>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 18%;">${record.formatted_date}</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 10%;">${amIn}</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 10%;">${amOut}</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 10%;">${pmIn}</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 10%;">${pmOut}</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 10%;">${formatHours(record.hours_rendered || 0)}</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 12%;">${formatHours(cumulativeHours)}</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 20%;"></td>
            </tr>
        `;
    });
    
    // Add empty rows to reach minimum of 15 rows
    const currentRows = data.dtrData.length;
    const minRows = 15;
    
    for (let i = currentRows; i < minRows; i++) {
        tableRows += `
            <tr>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; height: 18px; font-family: Arial, sans-serif; font-size: 9pt; width: 18%;">&nbsp;</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 10%;">&nbsp;</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 10%;">&nbsp;</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 10%;">&nbsp;</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 10%;">&nbsp;</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 10%;">&nbsp;</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 12%;">&nbsp;</td>
                <td style="border: 1px solid #222; padding: 3px; text-align: center; font-family: Arial, sans-serif; font-size: 9pt; width: 20%;">&nbsp;</td>
            </tr>
        `;
    }
    
    // Write complete DTR HTML to new window
    dtrWindow.document.write(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>DTR - ${data.intern.name}</title>
            <style>
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }
                body {
                    font-family: Arial, sans-serif;
                    background: white;
                    color: #222;
                    padding: 40px;
                    line-height: 1.4;
                    min-height: 100vh;
                    display: flex;
                    flex-direction: column;
                    box-sizing: border-box;
                }
                .dtr-container {
                    max-width: 900px;
                    margin: 0 auto;
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                }
                .dtr-content {
                    flex: 1;
                }
                .dtr-footer {
                    margin-top: auto;
                    text-align: center;
                }
                .header-img {
                    width: 420px;
                    max-width: 420px;
                    display: block;
                    margin: 0 auto 20px;
                }
                .title {
                    text-align: center;
                    font-family: 'Palatino Linotype', Palatino, serif;
                    font-weight: bold;
                    margin: 0 0 15px 0;
                    letter-spacing: 1px;
                    font-size: 16px;
                }
                .intern-details {
                    margin-bottom: 15px;
                    font-size: 12px;
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                }
                .intern-details div {
                    margin-bottom: 3px;
                }
                .intern-details span {
                    font-weight: bold;
                }
                .dtr-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 25px;
                    font-size: 9px;
                    table-layout: fixed;
                }
                .dtr-table th {
                    border: 1px solid #222;
                    padding: 4px 2px;
                    text-align: center;
                    background: #FFFF00 !important;
                    font-weight: bold;
                    font-size: 8px;
                    line-height: 1.1;
                }
                .dtr-table td {
                    border: 1px solid #222;
                    padding: 3px;
                    text-align: center;
                    font-size: 9px;
                    line-height: 1.2;
                }
                .certification {
                    margin: 40px 0 15px 0;
                    font-size: 11px;
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                }
                .certification div {
                    flex: 1;
                }
                .certification div:first-child {
                    margin-right: 20px;
                }
                .certification div:last-child {
                    margin-left: 20px;
                }
                .signature-line {
                    display: inline-block;
                    width: 180px;
                    border-bottom: 1px solid #222;
                    height: 15px;
                    margin: 8px 0;
                }
                .footer-img {
                    width: 450px;
                    max-width: 450px;
                    display: block;
                    margin: 0 auto;
                }
                
                @media print {
                    body {
                        padding: 20px;
                        font-size: 10px;
                        min-height: 100vh;
                        display: flex;
                        flex-direction: column;
                        transform: scale(1) !important;
                    }
                    .dtr-container {
                        max-width: 100%;
                        flex: 1;
                        display: flex;
                        flex-direction: column;
                        padding: 0;
                        transform: scale(1) !important;
                    }
                    .dtr-content {
                        flex: 1;
                    }
                    .dtr-footer {
                        margin-top: auto;
                    }
                    .header-img {
                        width: 400px;
                        max-width: 400px;
                        margin: 0 auto 15px;
                    }
                    .footer-img {
                        width: 450px;
                        max-width: 450px;
                        margin: 0 auto;
                    }
                    .title {
                        font-size: 14px;
                        margin: 10px 0 8px 0;
                        font-weight: bold;
                    }
                    .intern-details {
                        font-size: 10.5pt;
                        margin-bottom: 8px;
                    }
                    .dtr-table {
                        font-size: 12px;
                        margin-bottom: 15px;
                        width: 100%;
                        border-collapse: collapse;
                    }
                    .dtr-table th {
                        padding: 6px 4px;
                        font-size: 11px;
                        background: #FFFF00 !important;
                        background-color: #FFFF00 !important;
                        -webkit-print-color-adjust: exact !important;
                        color-adjust: exact !important;
                        print-color-adjust: exact !important;
                        border: 1px solid #222;
                        font-weight: bold;
                    }
                    .dtr-table td {
                        padding: 4px 3px;
                        font-size: 11px;
                        border: 1px solid #222;
                    }
                    .certification {
                        font-size: 10pt;
                        margin: 15px 0 10px 0;
                    }
                    .signature-line {
                        width: 180px;
                        height: 20px;
                        margin: 10px auto;
                        display: block;
                    }
                    * {
                        -webkit-print-color-adjust: exact !important;
                        color-adjust: exact !important;
                        print-color-adjust: exact !important;
                    }
                    @page {
                        size: A4 portrait;
                        margin: 0.3in;
                    }
                }
            </style>
        </head>
        <body>
            <div class="dtr-container">
                <div class="dtr-content">
                    <!-- Header -->
                    <img src="img/header.png" alt="DICT Header" class="header-img">
                    <h3 class="title">OJT TIME SHEET</h3>

                    <!-- Intern Details -->
                    <div class="intern-details">
                        <div>
                            <div><span style="font-weight: bold;">Name:</span> <span style="text-decoration: underline; font-weight: normal;">${data.intern.name || 'Unknown Intern'}</span></div>
                            <div><span style="font-weight: bold;">School:</span> <span style="text-decoration: underline; font-weight: normal;">${data.intern.school || 'Unknown School'}</span></div>
                            <div><span style="font-weight: bold;">Bureau/Office/Division:</span> <span style="text-decoration: underline; font-weight: normal;">ILCDB</span></div>
                        </div>
                        <div>
                            <span style="font-weight: bold;">Supervisor:</span> <span style="text-decoration: underline; font-weight: normal;">Mr. Edd Fernan D. Gonzales</span>
                        </div>
                    </div>

                    <!-- DTR Table -->
                    <table class="dtr-table">
                        <thead>
                            <tr>
                                <th rowspan="2" style="width: 18%; font-family: Arial, sans-serif; font-size: 9pt; padding: 4px; text-align: center; background: #FFFF00; border: 1px solid #222; font-weight: bold;">Date</th>
                                <th colspan="2" style="width: 20%; font-family: Arial, sans-serif; font-size: 9pt; padding: 4px; text-align: center; background: #FFFF00; border: 1px solid #222; font-weight: bold;">AM</th>
                                <th colspan="2" style="width: 20%; font-family: Arial, sans-serif; font-size: 9pt; padding: 4px; text-align: center; background: #FFFF00; border: 1px solid #222; font-weight: bold;">PM</th>
                                <th rowspan="2" style="width: 10%; font-family: Arial, sans-serif; font-size: 9pt; padding: 4px; text-align: center; background: #FFFF00; border: 1px solid #222; font-weight: bold;">Number of Hours</th>
                                <th rowspan="2" style="width: 12%; font-family: Arial, sans-serif; font-size: 9pt; padding: 4px; text-align: center; background: #FFFF00; border: 1px solid #222; font-weight: bold;">Total No. of Hours to date</th>
                                <th rowspan="2" style="width: 20%; font-family: Arial, sans-serif; font-size: 9pt; padding: 4px; text-align: center; background: #FFFF00; border: 1px solid #222; font-weight: bold;">Signature</th>
                            </tr>
                            <tr>
                                <th style="width: 10%; font-family: Arial, sans-serif; font-size: 9pt; padding: 4px; text-align: center; background: #FFFF00; border: 1px solid #222; font-weight: bold;">In</th>
                                <th style="width: 10%; font-family: Arial, sans-serif; font-size: 9pt; padding: 4px; text-align: center; background: #FFFF00; border: 1px solid #222; font-weight: bold;">Out</th>
                                <th style="width: 10%; font-family: Arial, sans-serif; font-size: 9pt; padding: 4px; text-align: center; background: #FFFF00; border: 1px solid #222; font-weight: bold;">In</th>
                                <th style="width: 10%; font-family: Arial, sans-serif; font-size: 9pt; padding: 4px; text-align: center; background: #FFFF00; border: 1px solid #222; font-weight: bold;">Out</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${tableRows}
                        </tbody>
                    </table>

                    <!-- Certification Section -->
                    <div class="certification">
                        <div style="text-align: left; display: inline-block; min-width: 240px;">
                            <span>I certify that the above is true and correct</span><br><br>
                            <div style="text-align: center; width: 100%; margin-left: -35px;">
                                <span class="signature-line" style="display: inline-block; width: 130px; border-bottom: 1px solid #222; height: 20px; margin: 0 auto 2px auto;"></span><br>
                                <span style="font-weight: bold; display: inline-block;">Student's Signature</span>
                            </div>
                        </div>
                        <div style="text-align: left; display: inline-block; min-width: 240px;">
                            <span>This certifies to the correctness of the work hours<br>entered by the<br>student trainee</span><br>
                            <div style="text-align: center; width: max-content; margin: 0 auto;">
                                <span class="signature-line" style="display: block; width: 120px; border-bottom: 1px solid #222; height: 20px; margin: 0 auto 2px auto;"></span>
                                <span style="font-weight: bold; display: block;">Supervisor</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <div class="dtr-footer">
                    <img src="img/footer.png" alt="DICT Footer" class="footer-img">
                </div>
            </div>
        </body>
        </html>
    `);
    
    dtrWindow.document.close();
    
    // Auto-print after a short delay
    setTimeout(() => {
        dtrWindow.print();
    }, 1000);
}

function showPrintableDTR() {
    // This function is no longer needed since we open a new window
}

function hidePrintableDTR() {
    // This function is no longer needed since we open a new window
} 