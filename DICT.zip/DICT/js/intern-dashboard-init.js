// Page initialization and event handlers
document.addEventListener('DOMContentLoaded', function() {
    // Initialize DTR modal date handlers
    initializeDTRModal();
    
    // Bind initial event listeners
    bindWeeklyReportEventListeners();
    
    // Update internship progress on page load
    updateInternshipProgress();
    
    // Initialize page state for existing entries with animations
    document.querySelectorAll('.status-select').forEach(select => {
        const date = select.getAttribute('data-date');
        const row = document.querySelector(`tr[data-date="${date}"]`);
        const timeInInput = row.querySelector('.time-in-input');
        const timeOutInput = row.querySelector('.time-out-input');
        const hoursSpan = row.querySelector('.calculated-hours');
        
        // Check if this is a future date
        const today = new Date().toISOString().split('T')[0];
        const isFuture = date > today;
        
        if (select.value === 'holiday' || select.value === 'leave' || select.value === 'absent') {
            // Disable time inputs and add styling for non-working days
            timeInInput.disabled = true;
            timeOutInput.disabled = true;
            
            // Add animated styling classes
            timeInInput.classList.add('non-working');
            timeOutInput.classList.add('non-working');
            select.classList.add(select.value);
            row.classList.add(select.value + '-mode');
            
            // Add zero hours styling if hours is 0
            if (hoursSpan.textContent === '0' || hoursSpan.textContent === '0.0') {
                hoursSpan.classList.add('zero-hours');
            }
            
            if (select.value === 'holiday') {
                row.setAttribute('data-holiday', 'true');
            }
        } else if (select.value === 'office' || select.value === 'wfh') {
            // Enable time inputs for working modes (unless it's a future date)
            if (!isFuture) {
                timeInInput.disabled = false;
                timeOutInput.disabled = false;
            }
            
            // Remove any non-working styling
            timeInInput.classList.remove('non-working');
            timeOutInput.classList.remove('non-working');
            hoursSpan.classList.remove('zero-hours');
            
            // Only auto-fill times for today and past dates, and only if no times are set
            if (!isFuture && !timeInInput.value && !timeOutInput.value) {
                const isToday = date === today;
                const isPast = date < today;
                
                if (isToday || isPast) {
                    timeInInput.value = '08:00';
                    timeOutInput.value = '17:00';
                    calculateHours(date);
                    // Auto-save the default times
                    setTimeout(() => saveWeeklyRow(date), 1000);
                }
            }
        }
    });
    
    // Save button listeners
    document.addEventListener('click', function(e) {
        if (e.target.closest('.save-row-btn')) {
            e.preventDefault();
            const btn = e.target.closest('.save-row-btn');
            const date = btn.getAttribute('data-date');
            saveWeeklyRow(date);
        }
    });
    
    // Week selector event listener
    const weekSelector = document.getElementById('weekSelector');
    if (weekSelector) {
        weekSelector.addEventListener('change', function() {
            const selectedWeek = this.value;
            loadWeekData(selectedWeek);
            // Also update cumulative hours for the new week selection
            setTimeout(() => {
                if (typeof updateCumulativeHoursForSelectedWeek === 'function') {
                    updateCumulativeHoursForSelectedWeek();
                }
            }, 500); // Small delay to ensure week data is loaded first
        });
    }
    
    // Profile dropdown
    const profileButton = document.getElementById('profileButton');
    if (profileButton) {
        profileButton.addEventListener('click', function() {
            document.getElementById('dropdownMenu').classList.toggle('show');
        });
    }

    window.addEventListener('click', function(e) {
        if (!e.target.matches('#profileButton')) {
            const dropdown = document.getElementById('dropdownMenu');
            if (dropdown && dropdown.classList.contains('show')) {
                dropdown.classList.remove('show');
            }
        }
    });

    // Handle PIN change form submission
    const changePinForm = document.getElementById('changePinForm');
    if (changePinForm) {
        changePinForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const currentPin = document.getElementById('currentPin').value;
            const newPin = document.getElementById('newPin').value;
            const confirmPin = document.getElementById('confirmPin').value;
            
            if (newPin !== confirmPin) {
                alert('New PIN and Confirm PIN do not match!');
                return;
            }
            
            // Show loading state
            const submitBtn = e.target.querySelector('.save-btn');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Updating...';
            }
            
            fetch('change_pin.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    currentPin: currentPin,
                    newPin: newPin
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('PIN updated successfully!');
                    closeModal('changePinModal');
                } else {
                    alert(data.message || 'Failed to update PIN. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating PIN. Please try again.');
            })
            .finally(() => {
                // Reset button state
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Update PIN';
                }
            });
        });
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    }
});

// Global variables that can be set from PHP
window.internName = '';
window.internStartDate = '';
window.completedHours = 0;
window.requiredHours = 0; 