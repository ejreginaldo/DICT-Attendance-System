// Time in/out functionality
document.querySelectorAll('.time-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        if (this.disabled) return;
        
        const action = this.classList.contains('time-in') ? 'time_in' : 'time_out';
        
        fetch('time_action.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ action: action })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Reload the page to update the status
                window.location.reload();
            } else {
                alert(data.message || 'Failed to record time. Please try again.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        });
    });
});

// Task saving functionality (updated for new row saving)
function saveWeeklyRow(date) {
    // Check if this is a future date
    const today = new Date().toISOString().split('T')[0];
    const isFuture = date > today;
    
    // Don't save data for future dates
    if (isFuture) {
        console.log('Cannot save data for future date:', date);
        return;
    }
    
    const row = document.querySelector(`tr[data-date="${date}"]`);
    const timeInInput = row.querySelector('.time-in-input');
    const timeOutInput = row.querySelector('.time-out-input');
    const taskInput = row.querySelector('.task-input');
    const statusSelect = row.querySelector('.status-select');
    const saveButton = row.querySelector('.save-row-btn');
    const hoursSpan = row.querySelector('.calculated-hours');
    
    const originalButtonHtml = saveButton.innerHTML;
    
    // Disable the button and show loading state
    saveButton.disabled = true;
    saveButton.classList.add('saving');
    saveButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    
    const data = {
        date: date,
        timeIn: timeInInput.value,
        timeOut: timeOutInput.value,
        tasks: taskInput.value,
        workMode: statusSelect.value
    };
    
    fetch('save_weekly_data.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(data)
    })
    .then(async response => {
        const responseData = await response.json();
        
        if (!response.ok) {
            if (responseData.debug) {
                console.error('Debug information:', responseData.debug);
            }
            throw new Error(responseData.message || 'Failed to save weekly data');
        }
        return responseData;
    })
    .then(data => {
        if (data.success) {
            // Update calculated hours
            if (data.calculatedHours) {
                // Format hours to remove .0 for whole numbers
                const hours = parseFloat(data.calculatedHours);
                const formattedHours = hours % 1 === 0 ? hours.toString() : hours.toFixed(1);
                hoursSpan.textContent = formattedHours;
            }
            
            // Remove loading animation
            saveButton.classList.remove('saving');
            
            // Show success state
            saveButton.classList.add('success');
            saveButton.innerHTML = '<i class="fas fa-check"></i>';
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.className = 'save-success-message';
            successMessage.innerHTML = '<i class="fas fa-check"></i> Saved Successfully';
            saveButton.parentNode.appendChild(successMessage);
            
            // Update weekly progress
            updateWeeklyProgress();
            
            // Update overall internship progress
            updateInternshipProgress();
            
            // Reset button state after animations
            setTimeout(() => {
                saveButton.classList.remove('success');
                saveButton.disabled = false;
                saveButton.innerHTML = originalButtonHtml;
            }, 2000);
            
            // Remove success message after animation
            setTimeout(() => {
                if (successMessage.parentNode) {
                    successMessage.remove();
                }
            }, 2500);
        } else {
            throw new Error(data.message || 'Failed to save weekly data');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        
        // Show error state
        saveButton.classList.remove('saving');
        saveButton.classList.add('error');
        saveButton.innerHTML = '<i class="fas fa-exclamation-triangle"></i>';
        
        // Show error message
        alert(error.message || 'An error occurred while saving data. Please try again.');
        
        // Reset button state after short delay
        setTimeout(() => {
            saveButton.classList.remove('error');
            saveButton.disabled = false;
            saveButton.innerHTML = originalButtonHtml;
        }, 1500);
    });
}

// Calculate hours automatically when time changes
function calculateHours(date) {
    const row = document.querySelector(`tr[data-date="${date}"]`);
    const timeInInput = row.querySelector('.time-in-input');
    const timeOutInput = row.querySelector('.time-out-input');
    const hoursSpan = row.querySelector('.calculated-hours');
    
    if (timeInInput.value && timeOutInput.value) {
        const timeIn = new Date(`${date} ${timeInInput.value}`);
        const timeOut = new Date(`${date} ${timeOutInput.value}`);
        
        if (timeOut > timeIn) {
            let diffHours = (timeOut - timeIn) / (1000 * 60 * 60);
            // Subtract 1 hour break if worked more than 5 hours
            if (diffHours > 5) {
                diffHours -= 1;
            }
            // Format hours to remove .0 for whole numbers
            const formattedHours = diffHours % 1 === 0 ? diffHours.toString() : diffHours.toFixed(1);
            hoursSpan.textContent = formattedHours;
        } else {
            hoursSpan.textContent = '0';
        }
    } else {
        hoursSpan.textContent = '0';
    }
}

// Update weekly progress calculation
function updateWeeklyProgress() {
    const weeklyHours = Array.from(document.querySelectorAll('.calculated-hours'))
        .reduce((total, span) => total + parseFloat(span.textContent || 0), 0);
    
    const weeklyTarget = 40;
    const weeklyProgress = Math.min(100, (weeklyHours / weeklyTarget) * 100);
    
    const progressFill = document.querySelector('.weekly-summary .progress-fill');
    const progressText = document.querySelector('.weekly-summary .progress-text');
    
    if (progressFill) {
        progressFill.style.width = weeklyProgress + '%';
    }
    if (progressText) {
        progressText.textContent = `${weeklyHours.toFixed(1)} / ${weeklyTarget} hours`;
    }
}

// Update overall internship progress calculation
function updateInternshipProgress() {
    // Calculate total hours from all daily reports (past and current dates only)
    fetch('get_completed_hours.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const completedHours = parseFloat(data.completed_hours);
            const requiredHours = parseFloat(data.required_hours);
            const actualProgressPercentage = requiredHours > 0 ? (completedHours / requiredHours) * 100 : 0;
            const displayProgressPercentage = Math.min(100, actualProgressPercentage);
            const isCompleted = actualProgressPercentage >= 100;
            
            // Update the main progress bar
            const progressVisualization = document.querySelector('.progress-visualization');
            const modernProgressBar = document.querySelector('.modern-progress-bar');
            const mainProgressFill = document.querySelector('.progress-fill');
            const mainProgressPercentage = document.querySelector('.progress-percentage');
            const hoursNumber = document.querySelector('.hours-number');
            
            if (mainProgressFill) {
                mainProgressFill.style.width = displayProgressPercentage.toFixed(1) + '%';
                
                // Add/remove completed styling
                if (isCompleted) {
                    progressVisualization?.classList.add('completed');
                    modernProgressBar?.classList.add('completed');
                    mainProgressFill.classList.add('completed');
                } else {
                    progressVisualization?.classList.remove('completed');
                    modernProgressBar?.classList.remove('completed');
                    mainProgressFill.classList.remove('completed');
                }
            }
            if (mainProgressPercentage) {
                // Show exactly 100% when completed, otherwise show actual percentage
                const displayPercentageText = isCompleted ? '100.0' : actualProgressPercentage.toFixed(1);
                mainProgressPercentage.textContent = displayPercentageText + '%';
            }
            if (hoursNumber) {
                hoursNumber.textContent = completedHours.toFixed(1);
            }
            
            // Check for completion and show congratulations
            checkCompletion();
        }
    })
    .catch(error => {
        console.error('Error updating internship progress:', error);
    });
}

// Check completion status and show congratulatory modal if just completed
function checkCompletion() {
    fetch('check_completion.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.just_completed) {
            // Update completion modal with current stats
            document.getElementById('finalHours').textContent = data.completed_hours.toFixed(1);
            document.getElementById('finalPercentage').textContent = '100.0%';
            
            // Show congratulatory modal with celebration effect
            showCompletionModal();
        } else if (data.success && data.is_completed) {
            // Already completed, update completion badge if not visible
            updateCompletionBadge(100.0); // Always show 100% when completed
        }
    })
    .catch(error => {
        console.error('Error checking completion:', error);
    });
}

// Show completion modal with simple animation
function showCompletionModal() {
    const modal = document.getElementById('completionModal');
    modal.style.display = 'flex';
}

// Update completion badge visibility
function updateCompletionBadge(progressPercentage) {
    const progressStatus = document.querySelector('.progress-status');
    let completionBadge = progressStatus?.querySelector('.completion-badge');
    
    if (progressPercentage >= 100 && !completionBadge) {
        // Add completion badge if it doesn't exist
        completionBadge = document.createElement('span');
        completionBadge.className = 'completion-badge';
        completionBadge.innerHTML = '🎉 Completed!';
        progressStatus?.appendChild(completionBadge);
        
        // Add completed class to progress visualization
        document.querySelector('.progress-visualization')?.classList.add('completed');
    }
}

// Bind event listeners for weekly report functionality
function bindWeeklyReportEventListeners() {
    // Remove existing event listeners to avoid duplicates
    document.querySelectorAll('.time-input, .status-select').forEach(element => {
        element.removeEventListener('change', handleTimeOrStatusChange);
        element.removeEventListener('blur', handleAutoSave);
    });
    
    // Time input change listeners
    document.querySelectorAll('.time-input').forEach(input => {
        input.addEventListener('change', handleTimeOrStatusChange);
        input.addEventListener('blur', handleAutoSave);
    });
    
    // Work mode change listeners
    document.querySelectorAll('.status-select').forEach(select => {
        select.addEventListener('change', handleStatusChange);
        select.addEventListener('blur', handleAutoSave);
    });
}

// Handle time or status changes
function handleTimeOrStatusChange() {
    const date = this.getAttribute('data-date');
    calculateHours(date);
}

// Handle status changes (including holiday/leave logic with animations)
function handleStatusChange() {
    const date = this.getAttribute('data-date');
    const row = document.querySelector(`tr[data-date="${date}"]`);
    const timeInInput = row.querySelector('.time-in-input');
    const timeOutInput = row.querySelector('.time-out-input');
    const hoursSpan = row.querySelector('.calculated-hours');
    const statusSelect = this;
    
    // Check if this is a future date
    const today = new Date().toISOString().split('T')[0];
    const isFuture = date > today;
    
    // Don't allow changes to future dates
    if (isFuture) {
        // Reset to default value if someone tries to change future dates
        statusSelect.value = 'office';
        return;
    }
    
    // Add pulse animation to status select
    statusSelect.classList.add('pulse');
    setTimeout(() => statusSelect.classList.remove('pulse'), 600);
    
    // Remove all previous status classes
    row.classList.remove('holiday-mode', 'leave-mode', 'absent-mode');
    statusSelect.classList.remove('holiday', 'leave', 'absent');
    timeInInput.classList.remove('non-working', 'fade-out', 'fade-in');
    timeOutInput.classList.remove('non-working', 'fade-out', 'fade-in');
    hoursSpan.classList.remove('zero-hours');
    
    if (this.value === 'holiday' || this.value === 'leave' || this.value === 'absent') {
        // Add fade out animation to time inputs
        timeInInput.classList.add('fade-out');
        timeOutInput.classList.add('fade-out');
        
        // After fade out, apply changes
        setTimeout(() => {
            // Clear time fields and set hours to 0 for holidays, leave, and absent
            timeInInput.value = '';
            timeOutInput.value = '';
            hoursSpan.textContent = '0.0';
            
            // Disable time inputs for non-working days
            timeInInput.disabled = true;
            timeOutInput.disabled = true;
            
            // Add styling classes
            timeInInput.classList.add('non-working');
            timeOutInput.classList.add('non-working');
            hoursSpan.classList.add('zero-hours');
            statusSelect.classList.add(this.value);
            
            // Add row animation based on status
            row.classList.add(this.value + '-mode');
            
            // Add holiday attribute for visual distinction
            if (this.value === 'holiday') {
                row.setAttribute('data-holiday', 'true');
            } else {
                row.removeAttribute('data-holiday');
            }
            
            // Auto-save the changes (only for current/past dates)
            if (!isFuture) {
                saveWeeklyRow(date);
            }
        }, 300);
        
    } else if (this.value === 'office' || this.value === 'wfh') {
        // Add fade in animation
        timeInInput.classList.add('fade-in');
        timeOutInput.classList.add('fade-in');
        
        // Re-enable time inputs for working modes
        timeInInput.disabled = false;
        timeOutInput.disabled = false;
        
        // Remove holiday styling
        row.removeAttribute('data-holiday');
        
        // Only auto-fill times for today and past dates
        const isToday = date === today;
        const isPast = date < today;
        
        if (isToday || isPast) {
            // Automatically set standard 8am-5pm timing for working modes with animation
            setTimeout(() => {
                timeInInput.value = '08:00';
                timeOutInput.value = '17:00';
                calculateHours(date);
                
                // Remove non-working classes
                timeInInput.classList.remove('non-working');
                timeOutInput.classList.remove('non-working');
                
                // Auto-save the changes
                saveWeeklyRow(date);
            }, 100);
        } else {
            // For future dates, just remove non-working classes but don't auto-fill times
            timeInInput.classList.remove('non-working');
            timeOutInput.classList.remove('non-working');
        }
    }
}

// Handle auto-save on blur
function handleAutoSave() {
    const date = this.getAttribute('data-date');
    // Auto-save after a short delay to allow for quick edits
    setTimeout(() => {
        saveWeeklyRow(date);
    }, 500);
}

// Change PIN functionality
function openChangePinModal() {
    document.getElementById('changePinModal').style.display = 'flex';
    const changePinForm = document.getElementById('changePinForm');
    if (changePinForm) {
        changePinForm.reset();
    }
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Test function to show completion modal (for testing purposes)
function testCompletionModal() {
    // Get current completion hours from PHP
    const completedHours = parseFloat(document.querySelector('.hours-number')?.textContent || 0);
    
    // Update completion modal with sample data
    document.getElementById('finalHours').textContent = completedHours.toFixed(1);
    document.getElementById('finalPercentage').textContent = '100.0%';
    
    // Show the completion modal
    showCompletionModal();
} 