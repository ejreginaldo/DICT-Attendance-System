// Week selector functionality
function loadWeekData(weekNumber) {
    const weekSelector = document.getElementById('weekSelector');
    const selectedOption = weekSelector.options[weekSelector.selectedIndex];
    const startDate = selectedOption.getAttribute('data-start');
    const endDate = selectedOption.getAttribute('data-end');
    
    if (!startDate || !endDate) return;
    
    // Get intern start date from PHP
    const internStartDate = window.internStartDate || '';
    
    // Determine effective start date (later of week start or intern start)
    const weekStartDate = new Date(startDate);
    const internStart = internStartDate ? new Date(internStartDate) : weekStartDate;
    const effectiveStartDate = new Date(Math.max(weekStartDate.getTime(), internStart.getTime()));
    
    // Update date range display
    const startFormatted = effectiveStartDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric' });
    const endFormatted = new Date(endDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    document.getElementById('weekDateRange').textContent = `${startFormatted} - ${endFormatted}`;
    
    // Update table dates and clear current data
    const tableRows = document.querySelectorAll('.report-table tbody tr');
    const today = new Date().toISOString().split('T')[0];
    
    // Create an array of dates to show (from effective start to Friday)
    const datesToShow = [];
    const currentDate = new Date(effectiveStartDate);
    const weekEnd = new Date(endDate);
    
    while (currentDate <= weekEnd) {
        datesToShow.push(currentDate.toISOString().split('T')[0]);
        currentDate.setDate(currentDate.getDate() + 1);
    }
    
    tableRows.forEach((row, index) => {
        if (index < datesToShow.length) {
            // Show and update this row
            row.style.display = '';
            const dateString = datesToShow[index];
            const rowDate = new Date(dateString);
            
            // Update the data-date attribute
            row.setAttribute('data-date', dateString);
            
            // Determine date status
            const isToday = dateString === today;
            const isPast = dateString < today;
            const isFuture = dateString > today;
            
            // Update data-is-future attribute
            row.setAttribute('data-is-future', isFuture ? 'true' : 'false');
            
            // Update row classes
            row.className = 'report-table-row'; // Reset classes
            if (isToday) row.classList.add('current-day');
            if (isFuture) row.classList.add('future-day');
            if (isPast) row.classList.add('past-day');
            
            // Update the date display in the first column
            const dateCell = row.querySelector('td:first-child');
            const dayName = rowDate.toLocaleDateString('en-US', { weekday: 'long' });
            const monthDay = rowDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            dateCell.textContent = `${dayName}, ${monthDay}`;
            
            // Update all input and select elements with the new date
            const timeInInput = row.querySelector('.time-in-input');
            const timeOutInput = row.querySelector('.time-out-input');
            const statusSelect = row.querySelector('.status-select');
            const saveButton = row.querySelector('.save-row-btn');
            const taskInput = row.querySelector('.task-input');
            
            timeInInput.setAttribute('data-date', dateString);
            timeOutInput.setAttribute('data-date', dateString);
            statusSelect.setAttribute('data-date', dateString);
            saveButton.setAttribute('data-date', dateString);
            taskInput.setAttribute('data-date', dateString);
            
            // Handle future date restrictions
            if (isFuture) {
                // Disable inputs for future dates
                timeInInput.disabled = true;
                timeOutInput.disabled = true;
                statusSelect.disabled = true;
                saveButton.disabled = true;
                taskInput.disabled = true;
                
                // Update placeholder for future dates
                taskInput.placeholder = 'Future date - cannot enter tasks yet';
            } else {
                // Enable inputs for past and current dates
                timeInInput.disabled = false;
                timeOutInput.disabled = false;
                statusSelect.disabled = false;
                saveButton.disabled = false;
                taskInput.disabled = false;
                
                // Update placeholder for editable dates
                const dayName = rowDate.toLocaleDateString('en-US', { weekday: 'long' });
                taskInput.placeholder = `Enter tasks for ${dayName}...`;
            }
            
            // Clear current data
            timeInInput.value = '';
            timeOutInput.value = '';
            row.querySelector('.calculated-hours').textContent = '0.0';
            taskInput.value = '';
            statusSelect.value = 'office';
            
            // Remove any status-related classes
            row.classList.remove('holiday-mode', 'leave-mode', 'absent-mode');
            statusSelect.classList.remove('holiday', 'leave', 'absent');
            timeInInput.classList.remove('non-working', 'fade-out', 'fade-in');
            timeOutInput.classList.remove('non-working', 'fade-out', 'fade-in');
        } else {
            // Hide unused rows
            row.style.display = 'none';
        }
    });
    
    // Fetch data for the selected week
    fetch('get_week_data.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            startDate: effectiveStartDate.toISOString().split('T')[0],
            endDate: endDate
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.weekData) {
            // Populate table with fetched data
            data.weekData.forEach(dayData => {
                const row = document.querySelector(`tr[data-date="${dayData.date}"]`);
                if (row) {
                    const timeInInput = row.querySelector('.time-in-input');
                    const timeOutInput = row.querySelector('.time-out-input');
                    const statusSelect = row.querySelector('.status-select');
                    const taskInput = row.querySelector('.task-input');
                    const hoursSpan = row.querySelector('.calculated-hours');
                    
                    if (dayData.time_in) {
                        timeInInput.value = dayData.time_in.substring(0, 5);
                    }
                    if (dayData.time_out) {
                        timeOutInput.value = dayData.time_out.substring(0, 5);
                    }
                    if (dayData.hours_rendered) {
                        const hours = parseFloat(dayData.hours_rendered);
                        const formattedHours = hours % 1 === 0 ? hours.toString() : hours.toFixed(1);
                        hoursSpan.textContent = formattedHours;
                    }
                    if (dayData.tasks_done) {
                        taskInput.value = dayData.tasks_done;
                    }
                    if (dayData.work_mode) {
                        statusSelect.value = dayData.work_mode;
                        
                        // Apply status-based styling if needed
                        if (dayData.work_mode === 'holiday' || dayData.work_mode === 'leave' || dayData.work_mode === 'absent') {
                            // Apply non-working day styling
                            timeInInput.classList.add('non-working');
                            timeOutInput.classList.add('non-working');
                            statusSelect.classList.add(dayData.work_mode);
                            row.classList.add(dayData.work_mode + '-mode');
                            
                            // Disable time inputs only if not a future date
                            const isFuture = row.getAttribute('data-is-future') === 'true';
                            if (!isFuture) {
                                timeInInput.disabled = true;
                                timeOutInput.disabled = true;
                            }
                            
                            // Add zero hours styling if hours is 0
                            if (hoursSpan.textContent === '0' || hoursSpan.textContent === '0.0') {
                                hoursSpan.classList.add('zero-hours');
                            }
                            
                            if (dayData.work_mode === 'holiday') {
                                row.setAttribute('data-holiday', 'true');
                            }
                        }
                    }
                }
            });
            
            // Update weekly progress
            updateWeeklyProgress();
            
            // Update overall internship progress
            updateInternshipProgress();
            
            // Update printable report
            if (typeof updatePrintableReportTasks === 'function') {
                updatePrintableReportTasks();
            }
        }
        
        // Re-bind event listeners for the new dates
        bindWeeklyReportEventListeners();
    })
    .catch(error => {
        console.error('Error loading week data:', error);
    });
}

// Print report functionality
function printReport() {
    populateWeeklyReport();
    document.getElementById('printable-weekly-report').style.display = 'block';
    
    // Ensure cumulative hours are updated before printing
    setTimeout(() => {
        updateCumulativeHoursForSelectedWeek();
        
        // Wait for the cumulative hours to be updated, then print
        setTimeout(() => {
            window.print();
            document.getElementById('printable-weekly-report').style.display = 'none';
        }, 1000); // Give time for AJAX call to complete
    }, 300);
}

// --- PRINTABLE WEEKLY REPORT LOGIC ---
function generateWeeklyReport() {
    const weekSelector = document.getElementById('weekSelector');
    const selectedWeekNumber = weekSelector.value;
    
    // Create weekly report content in a new window
    const reportWindow = window.open('', '_blank', 'width=1000,height=800');
    
    // Get current week data
    const reportRows = document.querySelectorAll('.report-table tbody tr:not([style*="display: none"])');
    let tableRows = '';
    let weeklyTotal = 0;
    
    // Get intern name
    const internName = window.internName || 'Unknown Intern';
    
    // Convert 24-hour format to 12-hour format for display
    function formatTime(timeStr) {
        if (!timeStr) return '';
        const time = new Date('2000-01-01 ' + timeStr);
        return time.toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
    }
    
    // Generate table rows from current dashboard data
    reportRows.forEach((row, index) => {
        if (index >= 5) return; // Maximum 5 rows
        
        const timeInInput = row.querySelector('.time-in-input');
        const timeOutInput = row.querySelector('.time-out-input');
        const hoursSpan = row.querySelector('.calculated-hours');
        const taskTextarea = row.querySelector('.task-input');
        const statusSelect = row.querySelector('.status-select');
        
        const timeIn = timeInInput ? timeInInput.value : '';
        const timeOut = timeOutInput ? timeOutInput.value : '';
        const hours = hoursSpan ? hoursSpan.textContent : '0.0';
        const tasks = taskTextarea ? taskTextarea.value : '';
        const workMode = statusSelect ? statusSelect.value : 'office';
        
        // Add to weekly total
        weeklyTotal += parseFloat(hours || 0);
        
        // Get formatted date
        let printableDate = '';
        if (row.getAttribute('data-date')) {
            const rowDate = new Date(row.getAttribute('data-date'));
            printableDate = rowDate.toLocaleDateString('en-US', {
                month: 'long',
                day: 'numeric',
                year: 'numeric'
            });
        }
        
        // Handle different work modes
        let displayTimeIn = '', displayTimeOut = '', displayHours = '', displayTasks = '';
        
        if (workMode === 'holiday' || workMode === 'leave' || workMode === 'absent') {
            displayTimeIn = '';
            displayTimeOut = '';
            displayHours = '0';
            displayTasks = workMode.charAt(0).toUpperCase() + workMode.slice(1);
        } else {
            displayTimeIn = formatTime(timeIn);
            displayTimeOut = formatTime(timeOut);
            displayHours = hours;
            displayTasks = tasks;
        }
        
        tableRows += `
            <tr>
                <td style="border:1px solid #222; padding:12px; text-align:center; vertical-align:middle; word-wrap:break-word;">${printableDate}</td>
                <td style="border:1px solid #222; padding:12px; text-align:center; vertical-align:middle; word-wrap:break-word;">${displayTimeIn}</td>
                <td style="border:1px solid #222; padding:12px; text-align:center; vertical-align:middle; word-wrap:break-word;">${displayTimeOut}</td>
                <td style="border:1px solid #222; padding:12px; text-align:center; vertical-align:middle; word-wrap:break-word;">${displayHours}</td>
                <td style="border:1px solid #222; padding:12px; text-align:center; vertical-align:middle; word-wrap:break-word; white-space:pre-wrap; overflow-wrap:break-word;">${displayTasks}</td>
            </tr>
        `;
    });
    
    // Add empty rows to reach 5 total
    const currentRows = reportRows.length;
    for (let i = currentRows; i < 5; i++) {
        tableRows += `
            <tr>
                <td style="border:1px solid #222; padding:12px; text-align:center; height:60px;">&nbsp;</td>
                <td style="border:1px solid #222; padding:12px; text-align:center;">&nbsp;</td>
                <td style="border:1px solid #222; padding:12px; text-align:center;">&nbsp;</td>
                <td style="border:1px solid #222; padding:12px; text-align:center;">&nbsp;</td>
                <td style="border:1px solid #222; padding:12px; text-align:center;">&nbsp;</td>
            </tr>
        `;
    }
    
    // Calculate weekly totals
    const weeklyH = Math.floor(weeklyTotal);
    const weeklyM = Math.round((weeklyTotal - weeklyH) * 60);
    
    // Calculate cumulative hours (this will be updated by JavaScript)
    const completedHours = window.completedHours || 0;
    const requiredHours = window.requiredHours || 0;
    const remainingHours = Math.max(0, requiredHours - completedHours);
    const completedH = Math.floor(completedHours);
    const completedM = Math.round((completedHours - completedH) * 60);
    const remainingH = Math.floor(remainingHours);
    
    // Write complete weekly report HTML to new window
    reportWindow.document.write(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Weekly Report - ${internName}</title>
            <style>
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }
                body {
                    font-family: Arial, sans-serif;
                    background: white;
                    color: #222;
                    padding: 40px;
                    line-height: 1.4;
                    min-height: 100vh;
                    display: flex;
                    flex-direction: column;
                }
                .report-container {
                    max-width: 900px;
                    margin: 0 auto;
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                }
                .report-content {
                    flex: 1;
                }
                .report-footer {
                    margin-top: auto;
                    text-align: center;
                }
                .header-img {
                    width: 420px;
                    max-width: 420px;
                    display: block;
                    margin: 0 auto 20px;
                }
                .title {
                    text-align: center;
                    font-weight: bold;
                    margin: 0 0 15px 0;
                    letter-spacing: 1px;
                    font-size: 16px;
                }
                .intern-details {
                    margin-bottom: 15px;
                    font-size: 12px;
                }
                .week-info {
                    margin-bottom: 20px;
                    font-size: 12px;
                }
                .week-input {
                    width: 30px;
                    text-align: center;
                    border: 1px solid #aaa;
                    border-radius: 3px;
                    font-size: 1em;
                    background: white;
                }
                .report-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 20px;
                    font-size: 11px;
                    table-layout: fixed;
                }
                .report-table th {
                    border: 1px solid #222;
                    padding: 8px;
                    text-align: center;
                    background: #f8f8f8;
                    font-weight: bold;
                }
                .report-table td {
                    border: 1px solid #222;
                    padding: 12px;
                    text-align: center;
                    vertical-align: middle;
                    word-wrap: break-word;
                }
                .totals {
                    margin: 15px 0 30px 0;
                    font-size: 11px;
                    text-align: right;
                }
                .signature-section {
                    margin: 20px 0;
                    font-size: 11px;
                    text-align: left;
                }
                .signature-line {
                    display: inline-block;
                    width: 300px;
                    border-bottom: 1px solid #222;
                    height: 15px;
                    margin: 8px 0;
                }
                .footer-img {
                    width: 450px;
                    max-width: 450px;
                    display: block;
                    margin: 0 auto;
                }
                
                @media print {
                    body {
                        padding: 20px;
                        min-height: 100vh;
                        display: flex;
                        flex-direction: column;
                    }
                    .report-container {
                        max-width: 100%;
                        flex: 1;
                        display: flex;
                        flex-direction: column;
                    }
                    .report-content {
                        flex: 1;
                    }
                    .report-footer {
                        margin-top: auto;
                    }
                    .header-img {
                        width: 350px;
                        max-width: 350px;
                    }
                    .footer-img {
                        width: 380px;
                        max-width: 380px;
                    }
                    .title {
                        font-size: 14px;
                    }
                    .intern-details, .week-info {
                        font-size: 10px;
                    }
                    .report-table {
                        font-size: 9px;
                    }
                    .report-table th {
                        padding: 4px;
                    }
                    .report-table td {
                        padding: 8px;
                    }
                    .totals, .signature-section {
                        font-size: 9px;
                    }
                    .signature-line {
                        width: 250px;
                        height: 12px;
                    }
                    @page {
                        size: A4 portrait;
                        margin: 0.5in;
                    }
                }
            </style>
        </head>
        <body>
            <div class="report-container">
                <div class="report-content">
                    <!-- Header -->
                    <img src="img/header.png" alt="DICT Header" class="header-img">
                    <h3 class="title">WEEKLY ACCOMPLISHMENT REPORT</h3>

                    <!-- Intern Details -->
                    <div class="intern-details">
                        <div>Name of Student: <b>${internName}</b></div>
                        <div>Department Assigned: <b>ILCDB</b></div>
                    </div>

                    <!-- Week Info -->
                    <div class="week-info">
                        Week No.: <input type="text" value="${selectedWeekNumber}" class="week-input" readonly>
                    </div>

                    <!-- Report Table -->
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th colspan="5">Week No. ${selectedWeekNumber}</th>
                            </tr>
                            <tr>
                                <th style="width: 18%;">Date</th>
                                <th style="width: 15%;">Time in</th>
                                <th style="width: 15%;">Time out</th>
                                <th style="width: 12%;">No. of Hours</th>
                                <th style="width: 40%;">Tasks</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${tableRows}
                        </tbody>
                    </table>

                    <!-- Totals -->
                    <div class="totals">
                        Weekly Total: ${weeklyH} Hours and ${weeklyM} Minutes<br>
                        Total Hours Completed: ${completedH} Hours and ${completedM} Minutes<br>
                        Hours Remaining: ${remainingH} Hours
                    </div>
                </div>

                <!-- Signature Section & Footer -->
                <div class="report-footer">
                    <div class="signature-section">
                        Reviewed By:<br>
                        <span class="signature-line"></span><br>
                        <b>Mr. Edd Fernan D. Gonzales</b><br>
                        DICT Rizal Provincial Officer
                    </div>
                    <img src="img/footer.png" alt="DICT Footer" class="footer-img">
                </div>
            </div>
        </body>
        </html>
    `);
    
    reportWindow.document.close();
    
    // Auto-print after a short delay
    setTimeout(() => {
        reportWindow.print();
    }, 1000);
}

// Calculate cumulative hours up to selected week for printable report
function updateCumulativeHoursForSelectedWeek() {
    const weekSelector = document.getElementById('weekSelector');
    if (!weekSelector) {
        console.error('Week selector not found');
        return;
    }
    
    const selectedWeekNumber = parseInt(weekSelector.value);
    
    // Calculate end date for the selected week
    const selectedOption = weekSelector.options[weekSelector.selectedIndex];
    const weekEndDate = selectedOption ? selectedOption.getAttribute('data-end') : null;
    
    console.log(`Calculating cumulative hours for Week ${selectedWeekNumber}, End Date: ${weekEndDate}`);
    
    if (!weekEndDate) {
        console.error('Week end date not found for week:', selectedWeekNumber);
        // Fallback: estimate based on week number (assuming 40 hours per week)
        const estimatedHours = selectedWeekNumber * 40;
        const estimatedH = Math.floor(estimatedHours);
        const estimatedM = 0;
        
        document.getElementById('print-cumulative-hours').textContent = estimatedH;
        document.getElementById('print-cumulative-minutes').textContent = estimatedM;
        
        const requiredHours = window.requiredHours || 0;
        const remainingHours = Math.max(0, requiredHours - estimatedHours);
        document.getElementById('print-remaining-hours').textContent = Math.floor(remainingHours);
        
        console.log(`Using estimated hours: ${estimatedHours} for week ${selectedWeekNumber}`);
        return;
    }
    
    // Fetch cumulative hours up to the selected week
    fetch('get_cumulative_hours.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            endDate: weekEndDate,
            weekNumber: selectedWeekNumber
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Calculate hours and minutes for cumulative total
            const cumulativeHours = parseFloat(data.completed_hours || 0);
            const cumulativeH = Math.floor(cumulativeHours);
            const cumulativeM = Math.round((cumulativeHours - cumulativeH) * 60);
            
            // Update cumulative hours in printable report
            document.getElementById('print-cumulative-hours').textContent = cumulativeH;
            document.getElementById('print-cumulative-minutes').textContent = cumulativeM;
            
            // Calculate and update remaining hours
            const requiredHours = window.requiredHours || 0;
            const remainingHours = Math.max(0, requiredHours - cumulativeHours);
            const remainingH = Math.floor(remainingHours);
            document.getElementById('print-remaining-hours').textContent = remainingH;
            
            console.log(`Week ${selectedWeekNumber}: Cumulative = ${cumulativeHours} hours, Remaining = ${remainingHours} hours`);
        } else {
            console.error('Failed to get cumulative hours:', data.message);
            // Fallback to showing current week total only
            const currentWeekTotal = parseFloat(document.getElementById('print-weekly-total').textContent || 0);
            document.getElementById('print-cumulative-hours').textContent = Math.floor(currentWeekTotal);
            document.getElementById('print-cumulative-minutes').textContent = Math.round((currentWeekTotal % 1) * 60);
        }
    })
    .catch(error => {
        console.error('Error fetching cumulative hours:', error);
        // Fallback to showing current week total only
        const currentWeekTotal = parseFloat(document.getElementById('print-weekly-total').textContent || 0);
        document.getElementById('print-cumulative-hours').textContent = Math.floor(currentWeekTotal);
        document.getElementById('print-cumulative-minutes').textContent = Math.round((currentWeekTotal % 1) * 60);
    });
}

function printWeeklyReport() {
    populateWeeklyReport();
    document.getElementById('printable-weekly-report').style.display = 'block';
    setTimeout(() => {
        window.print();
        document.getElementById('printable-weekly-report').style.display = 'none';
    }, 300);
}

// --- WEEKLY REPORT PRINTING LOGIC ---
function populateWeeklyReport() {
    const weekSelector = document.getElementById('weekSelector');
    const selectedWeekNumber = weekSelector.value;
    
    // Update week number in table header
    document.getElementById('print-week-label').textContent = selectedWeekNumber;
    
    // Get current week data from dashboard
    const reportRows = document.querySelectorAll('.report-table tbody tr:not([style*="display: none"])');
    const tableBody = document.getElementById('print-table-body');
    
    // Clear existing rows
    tableBody.innerHTML = '';
    
    let weeklyTotal = 0;
    
    // Convert 24-hour format to 12-hour format for display
    function formatTime(timeStr) {
        if (!timeStr) return '';
        const time = new Date('2000-01-01 ' + timeStr);
        return time.toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
    }
    
    // Filter rows to only show relevant days
    const relevantRows = [];
    let lastWorkingDay = null;
    const today = new Date().toISOString().split('T')[0];
    
    // First pass: identify the last meaningful day to show
    reportRows.forEach((row, index) => {
        if (index >= 5) return;
        
        const rowDate = row.getAttribute('data-date');
        const timeInInput = row.querySelector('.time-in-input');
        const timeOutInput = row.querySelector('.time-out-input');
        const hoursSpan = row.querySelector('.calculated-hours');
        const statusSelect = row.querySelector('.status-select');
        
        const hasTimeIn = timeInInput && timeInInput.value;
        const hasTimeOut = timeOutInput && timeOutInput.value;
        const hasHours = hoursSpan && parseFloat(hoursSpan.textContent || 0) > 0;
        const workMode = statusSelect ? statusSelect.value : 'office';
        
        // Consider a day as "worked" if it has time entries, hours, or is marked as leave/holiday/absent
        const hasWork = hasTimeIn || hasTimeOut || hasHours || (workMode !== 'office');
        
        // Update last working day if this day has work or if it's today/past and might be relevant
        if (hasWork || rowDate === today) {
            lastWorkingDay = rowDate;
        }
    });
    
    // Use last working day as cutoff, but don't show future days beyond today
    const cutoffDay = lastWorkingDay;
    
    console.log(`Weekly Report Filter - Today: ${today}, Last Working Day: ${lastWorkingDay}, Cutoff: ${cutoffDay}`);
    
    // Generate table rows only up to the cutoff day
    reportRows.forEach((row, index) => {
        if (index >= 5) return;
        
        const rowDate = row.getAttribute('data-date');
        
        // Only include rows up to the cutoff day (completion day or last working day)
        if (cutoffDay && rowDate > cutoffDay) {
            return; // Skip future/unnecessary days
        }
        
        const timeInInput = row.querySelector('.time-in-input');
        const timeOutInput = row.querySelector('.time-out-input');
        const hoursSpan = row.querySelector('.calculated-hours');
        const taskTextarea = row.querySelector('.task-input');
        const statusSelect = row.querySelector('.status-select');
        
        const timeIn = timeInInput ? timeInInput.value : '';
        const timeOut = timeOutInput ? timeOutInput.value : '';
        const hours = hoursSpan ? hoursSpan.textContent : '0.0';
        const tasks = taskTextarea ? taskTextarea.value : '';
        const workMode = statusSelect ? statusSelect.value : 'office';
        
        // Add to weekly total
        weeklyTotal += parseFloat(hours || 0);
        
        // Get formatted date
        let printableDate = '';
        if (rowDate) {
            const dateObj = new Date(rowDate);
            printableDate = dateObj.toLocaleDateString('en-US', {
                weekday: 'long',
                month: 'long',
                day: 'numeric',
                year: 'numeric'
            });
        }
        
        // Handle different work modes
        let displayTimeIn = '', displayTimeOut = '', displayHours = '', displayTasks = '';
        
        if (workMode === 'holiday' || workMode === 'leave' || workMode === 'absent') {
            displayTimeIn = '';
            displayTimeOut = '';
            displayHours = '0';
            displayTasks = workMode.charAt(0).toUpperCase() + workMode.slice(1);
        } else {
            displayTimeIn = formatTime(timeIn);
            displayTimeOut = formatTime(timeOut);
            displayHours = hours;
            displayTasks = tasks || '';
        }
        
        // Create table row with proper formatting
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${printableDate}</td>
            <td>${displayTimeIn}</td>
            <td>${displayTimeOut}</td>
            <td>${displayHours}</td>
            <td>${displayTasks}</td>
        `;
        tableBody.appendChild(tr);
        relevantRows.push(tr);
    });
    
    // Add empty rows only if we have less than 3 rows (to maintain minimum table structure)
    const currentRows = relevantRows.length;
    const minRows = Math.max(3, currentRows); // At least 3 rows for professional appearance
    const maxRows = 5; // But no more than 5
    
    for (let i = currentRows; i < Math.min(minRows, maxRows); i++) {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        `;
        tableBody.appendChild(tr);
    }
    
    // Update weekly totals
    const weeklyH = Math.floor(weeklyTotal);
    const weeklyM = Math.round((weeklyTotal - weeklyH) * 60);
    
    document.getElementById('print-weekly-total').textContent = weeklyH;
    document.getElementById('print-weekly-minutes').textContent = weeklyM;
    
    // Get accurate cumulative hours up to the selected week
    updateCumulativeHoursForSelectedWeek();
}

function showWeeklyReport() {
    populateWeeklyReport();
    document.getElementById('printable-weekly-report').style.display = 'block';
}

function hideWeeklyReport() {
    document.getElementById('printable-weekly-report').style.display = 'none';
} 