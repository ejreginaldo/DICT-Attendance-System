// Function to handle NFC card reading
function handleNFCRead() {
    const uidInput = document.getElementById('uid');
    const readCardBtn = document.getElementById('readCardBtn');

    // When the read card button is clicked
    readCardBtn.addEventListener('click', function() {
        readCardBtn.disabled = true;
        readCardBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        uidInput.placeholder = 'Reading card...';

        // Simulate card reading (replace with actual NFC reading logic)
        setTimeout(() => {
            // Reset button state
            readCardBtn.disabled = false;
            readCardBtn.innerHTML = '<i class="fas fa-credit-card"></i>';
            uidInput.placeholder = 'Tap NFC card to read UID...';
        }, 2000);
    });

    // Listen for NFC card tap events
    uidInput.addEventListener('focus', function() {
        // Add any specific behavior when the input is focused
        this.select(); // Select all text when focused
    });
}

// Function to handle form submission
function handleFormSubmission() {
    const form = document.getElementById('registerForm');
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        // Validate UID
        if (!data.uid) {
            alert('Please enter or scan an NFC card UID');
            return;
        }
        
        // Here you would typically send the data to your server
        console.log('Form submitted with data:', data);
        
        // Close modal after successful submission
        document.getElementById('registerModal').style.display = 'none';
        
        // Reset form
        form.reset();
    });
}

// Initialize all functionality when the document is loaded
document.addEventListener('DOMContentLoaded', function() {
    handleNFCRead();
    handleFormSubmission();
}); 