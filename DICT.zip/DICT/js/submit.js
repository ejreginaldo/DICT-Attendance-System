document.addEventListener('DOMContentLoaded', function() {
    console.log('DICT Attendance System - Camera & NFC Handler');
    
    // Get form elements
    const form = document.getElementById('nfcForm');
    const input = document.getElementById('uid');
    const result = document.getElementById('result');
    const video = document.getElementById('cameraVideo');
    const canvas = document.getElementById('cameraCanvas');
    const cameraStatus = document.getElementById('cameraStatus');
    const capturedImageInput = document.getElementById('capturedImage');
    
    let isSubmitting = false;
    let cameraStream = null;
    let cameraReady = false;

    // Initialize camera for photo capture
    async function initializeCamera() {
        console.log('Initializing camera...');
        updateCameraStatus('info', 'Starting camera...');

        try {
            // Request camera access with specific constraints for better quality
            const constraints = {
                video: {
                    width: { ideal: 640 },
                    height: { ideal: 480 },
                    facingMode: 'user' // Front camera if available
                }
            };
            
            cameraStream = await navigator.mediaDevices.getUserMedia(constraints);
            
            // Setup video element
            video.srcObject = cameraStream;
            video.style.display = 'block'; // Show the video preview
            canvas.width = 640;
            canvas.height = 480;
            
            // Wait for video to be ready
            video.addEventListener('loadedmetadata', function() {
                console.log('Camera ready!');
                cameraReady = true;
                updateCameraStatus('ready', 'Camera active - ready for attendance');
                
                // Enable NFC input
                input.disabled = false;
                input.placeholder = 'Tap your NFC card here...';
                input.focus();
            });
            
            // Handle video errors
            video.addEventListener('error', function(e) {
                console.error('Video error:', e);
                updateCameraStatus('error', 'Camera error occurred');
            });
            
        } catch (error) {
            console.error('Camera initialization failed:', error);
            let errorMessage = 'Camera access denied';
            
            if (error.name === 'NotAllowedError') {
                errorMessage = 'Please allow camera access and refresh the page';
            } else if (error.name === 'NotFoundError') {
                errorMessage = 'No camera found on this device';
            } else if (error.name === 'NotSupportedError') {
                errorMessage = 'Camera not supported on this browser';
            }
            
            updateCameraStatus('error', errorMessage);
            
            // Allow NFC without camera as fallback
            input.disabled = false;
            input.placeholder = 'Camera unavailable - NFC only mode';
            input.focus();
        }
    }

    // Update camera status display
    function updateCameraStatus(type, message) {
        const icons = {
            'info': 'fas fa-info-circle',
            'ready': 'fas fa-check-circle',
            'error': 'fas fa-exclamation-triangle',
            'capturing': 'fas fa-camera-retro'
        };
        
        cameraStatus.className = `camera-status ${type}`;
        cameraStatus.innerHTML = `<i class="${icons[type]}"></i><span>${message}</span>`;
    }

    // Capture photo from camera
    function capturePhoto() {
        if (!cameraReady || !cameraStream) {
            console.log('Camera not ready - proceeding without photo');
            return null;
        }

        try {
            updateCameraStatus('capturing', 'Taking photo...');
            
            const context = canvas.getContext('2d');
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imageData = canvas.toDataURL('image/jpeg', 0.8);
            
            console.log('Photo captured successfully');
            
            // Show a brief flash effect to indicate photo was taken
            video.style.filter = 'brightness(150%)';
            setTimeout(() => {
                video.style.filter = 'none';
                updateCameraStatus('ready', 'Camera active - ready for attendance');
            }, 200);
            
            return imageData;
        } catch (error) {
            console.error('Photo capture failed:', error);
            updateCameraStatus('error', 'Photo capture failed');
            return null;
        }
    }

    // Handle form submission
    function handleSubmit(event) {
        event.preventDefault();
        
        if (isSubmitting) {
            console.log('Already submitting, ignoring...');
            return;
        }

        const uid = input.value.trim();
        if (!uid) {
            console.log('No UID provided');
            return;
        }

        isSubmitting = true;
        console.log('Processing NFC tap:', uid);

        // Capture photo automatically when card is tapped
        const photoData = capturePhoto();
        capturedImageInput.value = photoData || '';

        // Submit form
        const formData = new FormData(form);
        
        fetch('process.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            console.log('Server response:', data);
            
            // Show result
            result.textContent = data.message;
            result.className = 'msg ' + (data.success ? 'success' : 'error');
            
            // Refresh attendance table and stats if successful
            if (data.success) {
                refreshAttendanceData();
            }
            
            // Clear input and reset
            input.value = '';
            setTimeout(() => {
                result.textContent = '';
                isSubmitting = false;
                input.focus();
            }, 3000);
        })
        .catch(error => {
            console.error('Submission failed:', error);
            result.textContent = 'Network error - please try again';
            result.className = 'msg error';
            
            setTimeout(() => {
                result.textContent = '';
                isSubmitting = false;
                input.focus();
            }, 3000);
        });
    }

    // Setup form submission handler
    form.addEventListener('submit', handleSubmit);
    
    // Auto-submit when NFC card data is entered
    input.addEventListener('input', function() {
        const value = input.value.trim();
        if (value.length >= 8) { // Minimum card ID length
            setTimeout(() => {
                if (input.value.trim() === value) { // Still the same value
                    handleSubmit(new Event('submit'));
                }
            }, 500); // Small delay to ensure complete card read
        }
    });

    // Refresh attendance data and statistics
    function refreshAttendanceData() {
        console.log('Refreshing attendance data...');
        
        fetch('get_recent_attendance.php')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateAttendanceTable(data.attendance);
                    updateStatistics(data.stats);
                    console.log('Attendance data refreshed successfully');
                } else {
                    console.error('Failed to refresh attendance data:', data.message);
                }
            })
            .catch(error => {
                console.error('Error refreshing attendance data:', error);
            });
    }

    // Update the attendance table with new data
    function updateAttendanceTable(attendanceData) {
        const tbody = document.getElementById('attendanceData');
        if (!tbody) return;

        // Clear existing rows
        tbody.innerHTML = '';

        // Add new rows
        attendanceData.forEach(record => {
            const row = document.createElement('tr');
            
            // Add highlight class for recent entries (within last 30 seconds)
            const recordTime = new Date(record.created_at);
            const now = new Date();
            const timeDiff = (now - recordTime) / 1000; // difference in seconds
            
            if (timeDiff < 30) {
                row.classList.add('new-entry');
            }
            
            row.innerHTML = `
                <td>${escapeHtml(record.name || 'Unknown')}</td>
                <td>${record.role ? escapeHtml(record.role.charAt(0).toUpperCase() + record.role.slice(1)) : 'Unknown'}</td>
                <td>${escapeHtml(record.date)}</td>
                <td>${escapeHtml(record.time_in)}</td>
                <td>${record.time_out ? escapeHtml(record.time_out) : '-'}</td>
                <td>
                    <span class="status-badge ${record.status}">
                        ${escapeHtml(record.status.charAt(0).toUpperCase() + record.status.slice(1).replace('_', ' '))}
                    </span>
                </td>
            `;
            
            tbody.appendChild(row);
        });
    }

    // Update statistics cards
    function updateStatistics(stats) {
        const statValues = document.querySelectorAll('.stat-card .stat-value');
        
        if (statValues.length >= 3) {
            // Update in order: Today's Attendance, On Time, Late
            statValues[0].textContent = stats.total;
            statValues[1].textContent = stats.on_time;
            statValues[2].textContent = stats.late;
            
            // Add a brief animation to indicate update
            statValues.forEach(element => {
                element.style.transform = 'scale(1.1)';
                setTimeout(() => {
                    element.style.transform = 'scale(1)';
                }, 200);
            });
        }
    }

    // Escape HTML to prevent XSS
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Cleanup camera stream on page unload
    window.addEventListener('beforeunload', function() {
        if (cameraStream) {
            cameraStream.getTracks().forEach(track => track.stop());
        }
    });

    // Initialize camera on page load
    initializeCamera();

    // Auto-refresh attendance data every 30 seconds
    setInterval(refreshAttendanceData, 30000);
});