function updatePhilippineTime() {
    const options = {
      timeZone: 'Asia/Manila',
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    };
    
    const now = new Date();
    const philTime = now.toLocaleString('en-PH', options);
    document.getElementById('clock').textContent = philTime;
  }

  // Update time immediately and then every second
  updatePhilippineTime();
  setInterval(updatePhilippineTime, 1000);