<?php
session_start();
require_once 'config/database.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if already logged in and redirect accordingly
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    if ($_SESSION['user_type'] === 'admin') {
        header('Location: admin-dashboard.php');
    } else {
        header('Location: intern-dashboard.php');
    }
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Log the POST data
    error_log("POST data received: " . print_r($_POST, true));
    
    $uid = $_POST['uid'] ?? '';
    $pin = $_POST['pin'] ?? '';

    if (empty($uid) || empty($pin)) {
        $error = "Both card UID and PIN are required.";
        error_log("Login error: Empty UID or PIN");
    } else {
        try {
            // First check admin credentials
            $stmt = $pdo->prepare("SELECT id, name, pin FROM admins WHERE card_uid = ?");
            $stmt->execute([$uid]);
            $admin = $stmt->fetch();
            
            if ($admin && password_verify($pin, $admin['pin'])) {
                // Admin login successful
                $_SESSION['logged_in'] = true;
                $_SESSION['user_type'] = 'admin';
                $_SESSION['user_id'] = $admin['id'];
                $_SESSION['user_name'] = $admin['name'];
                
                error_log("Login successful for admin: " . $admin['name']);
                
                // Return success response for AJAX request
                if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                    echo json_encode(['success' => true, 'redirect' => 'admin-dashboard.php']);
                    exit();
                }
                
                header('Location: admin-dashboard.php');
                exit();
            } else {
                // If not admin, check intern credentials
                $stmt = $pdo->prepare("SELECT id, name, pin FROM interns WHERE card_uid = ? AND status = 'active'");
                $stmt->execute([$uid]);
                $intern = $stmt->fetch();

                if ($intern && password_verify($pin, $intern['pin'])) {
                    // Intern login successful
                    $_SESSION['logged_in'] = true;
                    $_SESSION['user_type'] = 'intern';
                    $_SESSION['intern_id'] = $intern['id']; // Use intern_id as your existing dashboard expects
                    $_SESSION['user_name'] = $intern['name'];

                    error_log("Login successful for intern: " . $intern['name']);

                    // Return success response for AJAX request
                    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                        echo json_encode(['success' => true, 'redirect' => 'intern-dashboard.php']);
                        exit();
                    }

                    header('Location: intern-dashboard.php');
                    exit();
                } else {
                    $error = "Invalid credentials. Please try again.";
                    error_log("Login failed: Invalid credentials for UID $uid");
                }
            }
        } catch (PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            $error = "An error occurred. Please try again.";
        }
    }
    
    // Return error response for AJAX request
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
        echo json_encode(['success' => false, 'message' => $error]);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DICT Login</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="dict-logo">
        <a href="index.php">
            <img src="img/dict-logo.png" alt="DICT Logo">
        </a>
    </div>

    <div class="login-box">
        <h2>Login</h2>
        <div class="nfc-icon">
            <i class="fas fa-wifi fa-flip-vertical"></i>
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form id="loginForm" method="POST">
            <div class="input-wrapper">
                <i class="fas fa-id-card input-icon"></i>
                <input 
                    type="password" 
                    name="uid" 
                    id="uid" 
                    placeholder="Scan your NFC card or enter UID..." 
                    autocomplete="off"
                    required
                    autofocus
                >
            </div>
            
            <div class="input-wrapper">
                <i class="fas fa-lock input-icon"></i>
                <input 
                    type="password" 
                    name="pin" 
                    id="pin" 
                    placeholder="Enter your PIN" 
                    maxlength="6"
                    pattern="[0-9]*"
                    inputmode="numeric"
                    autocomplete="off"
                    required
                >
            </div>

            <button type="submit" class="submit-btn">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('loginForm');
            const uidInput = document.getElementById('uid');
            const pinInput = document.getElementById('pin');

            // Auto-focus UID input
            uidInput.focus();

            // Handle form submission
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                submitForm();
            });

            function submitForm() {
                const formData = new FormData(form);

                fetch('login.php', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = data.redirect;
                    } else {
                        // Show error message
                        const errorDiv = document.querySelector('.error-message') || document.createElement('div');
                        errorDiv.className = 'error-message';
                        errorDiv.textContent = data.message;
                        
                        if (!document.querySelector('.error-message')) {
                            form.insertBefore(errorDiv, form.firstChild);
                        }
                        
                        // Clear inputs
                        uidInput.value = '';
                        pinInput.value = '';
                        uidInput.focus();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    const errorDiv = document.querySelector('.error-message') || document.createElement('div');
                    errorDiv.className = 'error-message';
                    errorDiv.textContent = 'An error occurred while trying to log in. Please try again.';
                    
                    if (!document.querySelector('.error-message')) {
                        form.insertBefore(errorDiv, form.firstChild);
                    }
                });
            }
        });
    </script>
</body>
</html>
