<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

// Verify admin is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['user_type'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$notificationId = $data['notification_id'] ?? null;
$markAll = $data['mark_all'] ?? false;

try {
    if ($markAll) {
        // Mark all notifications as read
        $stmt = $pdo->prepare("UPDATE completion_notifications SET notification_read = TRUE");
        $stmt->execute();
        $affected = $stmt->rowCount();
        
        echo json_encode([
            'success' => true, 
            'message' => "Marked $affected notifications as read"
        ]);
    } else if ($notificationId) {
        // Mark specific notification as read
        $stmt = $pdo->prepare("
            UPDATE completion_notifications 
            SET notification_read = TRUE 
            WHERE id = ?
        ");
        $stmt->execute([$notificationId]);
        
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Notification marked as read']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Notification not found']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Missing notification ID']);
    }
    
} catch (PDOException $e) {
    error_log("Mark notification read error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to update notification']);
}
?> 