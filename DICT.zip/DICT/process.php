<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$card_uid = $_POST['uid'] ?? '';
$captured_image = $_POST['captured_image'] ?? '';

// Log attendance processing
if (!empty($captured_image)) {
    error_log("Attendance: Processing with image data (" . strlen($captured_image) . " chars) for card: " . $card_uid);
}

if (empty($card_uid)) {
    echo json_encode(['success' => false, 'message' => 'No card UID provided']);
    exit;
}

// Function to save captured image
function saveAttendanceImage($imageData, $userId, $userType, $userName, $action) {
    if (empty($imageData)) {
        error_log("Image save: No image data provided for $userName ($action)");
        return null;
    }
    
    // Remove data URL prefix (data:image/jpeg;base64,)
    $imageData = preg_replace('/^data:image\/[a-z]+;base64,/', '', $imageData);
    $imageData = base64_decode($imageData);
    
    if ($imageData === false) {
        error_log("Image save: Failed to decode base64 data for $userName ($action)");
        return null;
    }
    
    // Create filename with timestamp and user info
    $timestamp = date('Y-m-d_H-i-s');
    $safeUserName = preg_replace('/[^a-zA-Z0-9_-]/', '_', $userName);
    $filename = "{$timestamp}_{$userType}_{$userId}_{$safeUserName}_{$action}.jpg";
    
    // Create date-based subfolder
    $dateFolder = date('Y-m-d');
    $uploadDir = "images/attendance/{$dateFolder}/";
    
    // Create directory if it doesn't exist
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $filepath = $uploadDir . $filename;
    
    // Save the image
    if (file_put_contents($filepath, $imageData)) {
        error_log("Image save: SUCCESS - $filename");
        return $filepath;
    } else {
        error_log("Image save: FAILED - Could not write to $filepath");
    }
    
    return null;
}

try {
    // First check if it's an intern
    $stmt = $pdo->prepare("SELECT id, name FROM interns WHERE card_uid = ? AND status = 'active'");
    $stmt->execute([$card_uid]);
    $user = $stmt->fetch();
    $user_type = 'intern';

    // If not an intern, check if it's an employee
    if (!$user) {
        $stmt = $pdo->prepare("SELECT id, name FROM employees WHERE card_uid = ? AND status = 'active'");
        $stmt->execute([$card_uid]);
        $user = $stmt->fetch();
        $user_type = 'employee';
    }

    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'Card not recognized']);
        exit;
    }

    // Get current date and time in Manila/Philippines timezone
    date_default_timezone_set('Asia/Manila');
    $current_date = date('Y-m-d');
    $current_time = date('H:i:s');
    
    // Check if there's an existing log for today
    $stmt = $pdo->prepare("
        SELECT id, time_in, time_out 
        FROM attendance_logs 
        WHERE user_type = ? AND user_id = ? AND date = ?
    ");
    $stmt->execute([$user_type, $user['id'], $current_date]);
    $log = $stmt->fetch();

    if (!$log) {
        // This is a time-in
        // Check if late based on 8:00 AM start time
        $start_time = strtotime('08:00:00');
        $current = strtotime($current_time);
        $status = ($current <= $start_time) ? 'on_time' : 'late';

        // Save attendance image for time-in
        $imagePath = saveAttendanceImage($captured_image, $user['id'], $user_type, $user['name'], 'timein');

        // Insert new attendance log
        $stmt = $pdo->prepare("
            INSERT INTO attendance_logs (user_type, user_id, date, time_in, status, image_path)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$user_type, $user['id'], $current_date, $current_time, $status, $imagePath]);

        echo json_encode([
            'success' => true,
            'message' => "Welcome, " . htmlspecialchars($user['name']) . "! Time in recorded at " . date('h:i A', $current) . ($imagePath ? " (Photo captured)" : "")
        ]);
    } else {
        // Check if at least 5 minutes have passed since time_in before allowing time_out
        $time_in = strtotime($log['time_in']);
        $current = strtotime($current_time);
        $time_difference = ($current - $time_in) / 60; // difference in minutes

        if (!$log['time_out'] && $time_difference >= 5) {
            // This is a time-out
            // Calculate total hours
            $total_hours = round(($current - $time_in) / 3600, 2); // Convert seconds to hours

            // Save attendance image for time-out
            $timeoutImagePath = saveAttendanceImage($captured_image, $user['id'], $user_type, $user['name'], 'timeout');

            // Update the log with time_out, total_hours, and timeout image
            $stmt = $pdo->prepare("
                UPDATE attendance_logs 
                SET time_out = ?, total_hours = ?, timeout_image_path = ?
                WHERE id = ?
            ");
            $stmt->execute([$current_time, $total_hours, $timeoutImagePath, $log['id']]);

            echo json_encode([
                'success' => true,
                'message' => "Goodbye, " . htmlspecialchars($user['name']) . "! Time out recorded at " . date('h:i A', $current) . ($timeoutImagePath ? " (Photo captured)" : "")
            ]);
        } else if (!$log['time_out'] && $time_difference < 5) {
            // Too soon for time-out
            $wait_time = ceil(5 - $time_difference);
            echo json_encode([
                'success' => false,
                'message' => "Please wait " . $wait_time . " more minute(s) before timing out."
            ]);
        } else {
            // Already timed out for today
            echo json_encode([
                'success' => false,
                'message' => "You have already completed your attendance for today."
            ]);
        }
    }

} catch (PDOException $e) {
    error_log("Process error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred while processing your request']);
} 