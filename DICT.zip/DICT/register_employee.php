<?php
session_start();
require_once 'config/database.php';

// Verify if user is logged in as admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get POST data
$name = $_POST['name'] ?? '';
$position = $_POST['position'] ?? '';
$department = $_POST['department'] ?? '';
$card_uid = $_POST['card_uid'] ?? '';

// Validate required fields
if (empty($name) || empty($position) || empty($department) || empty($card_uid)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit();
}

try {
    // Check if card_uid already exists
    $stmt = $pdo->prepare("SELECT id FROM employees WHERE card_uid = ?");
    $stmt->execute([$card_uid]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'An employee with this card UID already exists']);
        exit();
    }

    // Insert new employee (no PIN required for employees)
    $stmt = $pdo->prepare("
        INSERT INTO employees (name, position, department, card_uid)
        VALUES (?, ?, ?, ?)
    ");

    $stmt->execute([
        $name,
        $position,
        $department,
        $card_uid
    ]);

    echo json_encode(['success' => true, 'message' => 'Employee registered successfully']);

} catch (PDOException $e) {
    error_log("Employee registration error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred while registering the employee']);
} 