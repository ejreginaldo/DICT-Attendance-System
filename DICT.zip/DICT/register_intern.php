<?php
session_start();
require_once 'config/database.php';

// Verify if user is logged in as admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get POST data
$name = $_POST['name'] ?? '';
$school = $_POST['school'] ?? '';
$card_uid = $_POST['card_uid'] ?? '';
$pin = $_POST['pin'] ?? '';
$required_hours = $_POST['required_hours'] ?? '';
$start_date = $_POST['start_date'] ?? '';

// Validate required fields
if (empty($name) || empty($school) || empty($card_uid) || empty($pin) || empty($required_hours) || empty($start_date)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit();
}

try {
    // Check if card_uid already exists
    $stmt = $pdo->prepare("SELECT id FROM interns WHERE card_uid = ?");
    $stmt->execute([$card_uid]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'An intern with this card UID already exists']);
        exit();
    }

    // Hash the PIN
    $hashed_pin = password_hash($pin, PASSWORD_DEFAULT);

    // Insert new intern
    $stmt = $pdo->prepare("
        INSERT INTO interns (name, school, card_uid, pin, required_hours, start_date)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $name,
        $school,
        $card_uid,
        $hashed_pin,
        $required_hours,
        $start_date
    ]);

    echo json_encode(['success' => true, 'message' => 'Intern registered successfully']);

} catch (PDOException $e) {
    error_log("Intern registration error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred while registering the intern']);
} 