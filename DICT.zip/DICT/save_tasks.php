<?php
session_start();
require_once 'config/database.php';

// Set timezone to match attendance records
date_default_timezone_set('Asia/Manila');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['intern_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Get POST data
$rawData = file_get_contents('php://input');
$data = json_decode($rawData, true);

// Log the received data for debugging
error_log("Received data: " . print_r($data, true));
error_log("Raw data: " . $rawData);

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Check for required data
if (!isset($data['date']) || !isset($data['tasks'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing required data']);
    exit();
}

try {
    // Ensure date format is correct (YYYY-MM-DD)
    $saveDate = date('Y-m-d', strtotime($data['date']));
    $internId = $_SESSION['intern_id'];
    $tasks = trim($data['tasks']);
    
    // First, check if there's an attendance record for this date
    $stmt = $pdo->prepare("
        SELECT id, time_in, time_out, total_hours 
        FROM attendance_logs 
        WHERE user_type = 'intern' 
        AND user_id = ? 
        AND date = ?
    ");
    $stmt->execute([$internId, $saveDate]);
    $attendance = $stmt->fetch();

    if (!$attendance) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'No attendance record found for this date. Please make sure you have timed in for this day.']);
        exit();
    }

    // Prepare data for intern_daily_reports
    // Use attendance data, but handle NULL time_out gracefully
    $timeIn = $attendance['time_in'];
    $timeOut = $attendance['time_out'] ?: null;
    $hoursRendered = $attendance['total_hours'] ?: 0;
    
    // Insert or update the daily report
    $stmt = $pdo->prepare("
        INSERT INTO intern_daily_reports 
            (intern_id, date, time_in, time_out, hours_rendered, tasks_done) 
        VALUES 
            (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            time_in = VALUES(time_in),
            time_out = VALUES(time_out),
            hours_rendered = VALUES(hours_rendered),
            tasks_done = VALUES(tasks_done)
    ");

    $result = $stmt->execute([
        $internId,
        $saveDate,
        $timeIn,
        $timeOut,
        $hoursRendered,
        $tasks
    ]);

    if ($result) {
        echo json_encode([
            'success' => true, 
            'message' => 'Tasks saved successfully',
            'data' => [
                'date' => $saveDate,
                'tasks' => $tasks,
                'attendance_id' => $attendance['id']
            ]
        ]);
    } else {
        throw new Exception('Failed to save tasks to database');
    }

} catch (PDOException $e) {
    error_log("Database error in save_tasks.php: " . $e->getMessage());
    error_log("Error info: " . print_r($e->errorInfo, true));
    
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Database error occurred: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log("General error in save_tasks.php: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?> 