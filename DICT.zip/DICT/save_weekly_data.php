<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

// Verify if user is logged in as intern
if (!isset($_SESSION['intern_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Invalid JSON input');
    }
    
    $date = $input['date'] ?? null;
    $timeIn = $input['timeIn'] ?? null;
    $timeOut = $input['timeOut'] ?? null;
    $tasks = $input['tasks'] ?? '';
    $workMode = $input['workMode'] ?? 'office';
    
    if (!$date) {
        throw new Exception('Date is required');
    }
    
    // Calculate hours if both time in and time out are provided
    $hoursRendered = 0;
    if ($timeIn && $timeOut) {
        $timeInTimestamp = strtotime($date . ' ' . $timeIn);
        $timeOutTimestamp = strtotime($date . ' ' . $timeOut);
        
        if ($timeOutTimestamp > $timeInTimestamp) {
            $diffHours = ($timeOutTimestamp - $timeInTimestamp) / 3600;
            // Subtract 1 hour break if worked more than 5 hours
            $hoursRendered = $diffHours > 5 ? $diffHours - 1 : $diffHours;
        }
    }
    
    // Debug logging
    error_log("Save attempt - Intern ID: " . $_SESSION['intern_id'] . ", Date: " . $date . ", TimeIn: " . $timeIn . ", TimeOut: " . $timeOut . ", Tasks: " . $tasks . ", WorkMode: " . $workMode);
    
    // Check if daily report record already exists
    $stmt = $pdo->prepare("
        SELECT id FROM intern_daily_reports 
        WHERE intern_id = ? AND date = ?
    ");
    $stmt->execute([$_SESSION['intern_id'], $date]);
    $existingReport = $stmt->fetch();
    
    error_log("Existing report found: " . ($existingReport ? "Yes (ID: " . $existingReport['id'] . ")" : "No"));
    
    if ($existingReport) {
        // Update existing daily report
        error_log("Updating existing report ID: " . $existingReport['id']);
        $stmt = $pdo->prepare("
            UPDATE intern_daily_reports 
            SET time_in = ?, 
                time_out = ?, 
                hours_rendered = ?, 
                tasks_done = ?,
                work_mode = ?
            WHERE id = ?
        ");
        $result = $stmt->execute([
            $timeIn,
            $timeOut,
            $hoursRendered > 0 ? $hoursRendered : 0,
            $tasks,
            $workMode,
            $existingReport['id']
        ]);
        error_log("Update result: " . ($result ? "Success" : "Failed") . ", Affected rows: " . $stmt->rowCount());
    } else {
        // Insert new daily report
        error_log("Inserting new report");
        $stmt = $pdo->prepare("
            INSERT INTO intern_daily_reports 
            (intern_id, date, time_in, time_out, hours_rendered, tasks_done, work_mode, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $result = $stmt->execute([
            $_SESSION['intern_id'],
            $date,
            $timeIn,
            $timeOut,
            $hoursRendered > 0 ? $hoursRendered : 0,
            $tasks,
            $workMode
        ]);
        error_log("Insert result: " . ($result ? "Success" : "Failed") . ", Last insert ID: " . $pdo->lastInsertId());
    }
    
    // Update completed_hours in interns table based on intern_daily_reports only
    $stmt = $pdo->prepare("
        UPDATE interns 
        SET completed_hours = (
            SELECT COALESCE(SUM(hours_rendered), 0)
            FROM intern_daily_reports 
            WHERE intern_id = ?
        )
        WHERE id = ?
    ");
    $stmt->execute([$_SESSION['intern_id'], $_SESSION['intern_id']]);
    
    // Check for completion and update status if needed
    $stmt = $pdo->prepare("
        SELECT id, required_hours, completed_hours, completion_status 
        FROM interns 
        WHERE id = ? AND status = 'active'
    ");
    $stmt->execute([$_SESSION['intern_id']]);
    $intern = $stmt->fetch();
    
    if ($intern && $intern['completed_hours'] >= $intern['required_hours'] && $intern['completion_status'] != 'completed') {
        // Update completion status
        $stmt = $pdo->prepare("
            UPDATE interns 
            SET completion_status = 'completed', completion_date = CURDATE()
            WHERE id = ?
        ");
        $stmt->execute([$_SESSION['intern_id']]);
        
        // Create completion notification
        $stmt = $pdo->prepare("
            INSERT IGNORE INTO completion_notifications (intern_id, completion_date, notification_read, created_at)
            VALUES (?, CURDATE(), FALSE, NOW())
        ");
        $stmt->execute([$_SESSION['intern_id']]);
        
        error_log("Intern {$_SESSION['intern_id']} completed their internship!");
    }
    
    echo json_encode([
        'success' => true, 
        'message' => 'Weekly data saved successfully',
        'calculatedHours' => number_format($hoursRendered, 1)
    ]);
    
} catch (Exception $e) {
    error_log("Save weekly data error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Failed to save weekly data: ' . $e->getMessage()
    ]);
}
?> 