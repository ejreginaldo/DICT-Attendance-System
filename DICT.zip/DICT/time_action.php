<?php
session_start();
require_once 'config/database.php';

// Set timezone to Asia/Manila
date_default_timezone_set('Asia/Manila');

// Check if user is logged in
if (!isset($_SESSION['intern_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['action'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing action parameter']);
    exit();
}

try {
    $today = date('Y-m-d');
    $currentTime = date('H:i:s'); // Current time in 24-hour format
    
    if ($data['action'] === 'time_in') {
        // Check if already timed in today
        $stmt = $pdo->prepare("
            SELECT id FROM attendance_logs 
            WHERE user_type = 'intern' 
            AND user_id = ? 
            AND date = ?
        ");
        $stmt->execute([$_SESSION['intern_id'], $today]);
        
        if ($stmt->fetch()) {
            throw new Exception('Already timed in for today');
        }
        
        // Record time in with current timestamp
        $stmt = $pdo->prepare("
            INSERT INTO attendance_logs 
                (user_type, user_id, date, time_in, status) 
            VALUES 
                ('intern', ?, ?, CURRENT_TIME(), ?)
        ");
        
        // Determine if late (after 8:00 AM)
        $status = (strtotime($currentTime) > strtotime('08:00:00')) ? 'late' : 'on_time';
        
        $stmt->execute([
            $_SESSION['intern_id'],
            $today,
            $status
        ]);
        
        // Get the attendance ID that was just inserted
        $attendanceId = $pdo->lastInsertId();
        
        // Get the actual time that was recorded
        $stmt = $pdo->prepare("
            SELECT time_in, DATE_FORMAT(time_in, '%h:%i %p') as formatted_time_in 
            FROM attendance_logs 
            WHERE user_type = 'intern' 
            AND user_id = ? 
            AND date = ?
        ");
        $stmt->execute([$_SESSION['intern_id'], $today]);
        $result = $stmt->fetch();
        
        // Automatically create a daily report entry
        try {
            $stmt = $pdo->prepare("
                INSERT INTO intern_daily_reports 
                    (intern_id, date, time_in, time_out, hours_rendered, tasks_done, created_at) 
                VALUES 
                    (?, ?, ?, NULL, 0, '', NOW())
            ");
            $stmt->execute([
                $_SESSION['intern_id'],
                $today,
                $result['time_in']
            ]);
        } catch (PDOException $e) {
            // If daily report already exists, that's okay - just continue
            error_log("Daily report entry may already exist: " . $e->getMessage());
        }
        
        echo json_encode([
            'success' => true, 
            'message' => 'Time in recorded successfully',
            'time' => $result['formatted_time_in']
        ]);
        
    } elseif ($data['action'] === 'time_out') {
        // Get existing time in record
        $stmt = $pdo->prepare("
            SELECT id, time_in 
            FROM attendance_logs 
            WHERE user_type = 'intern' 
            AND user_id = ? 
            AND date = ? 
            AND time_out IS NULL
        ");
        $stmt->execute([$_SESSION['intern_id'], $today]);
        $record = $stmt->fetch();
        
        if (!$record) {
            throw new Exception('No active time in record found');
        }
        
        // Update record with time out using current timestamp
        $stmt = $pdo->prepare("
            UPDATE attendance_logs 
            SET time_out = CURRENT_TIME(),
                total_hours = TIMESTAMPDIFF(SECOND, time_in, CURRENT_TIME()) / 3600
            WHERE id = ?
        ");
        
        $stmt->execute([$record['id']]);
        
        // Get the updated attendance record
        $stmt = $pdo->prepare("
            SELECT 
                time_out,
                DATE_FORMAT(time_out, '%h:%i %p') as formatted_time_out,
                CASE 
                    WHEN TIMESTAMPDIFF(HOUR, time_in, time_out) > 5 
                    THEN total_hours - 1
                    ELSE total_hours
                END as adjusted_hours
            FROM attendance_logs 
            WHERE id = ?
        ");
        $stmt->execute([$record['id']]);
        $result = $stmt->fetch();
        
        // Update the corresponding daily report entry
        try {
            $stmt = $pdo->prepare("
                UPDATE intern_daily_reports 
                SET time_out = ?, 
                    hours_rendered = ?
                WHERE intern_id = ? 
                AND date = ?
            ");
            $stmt->execute([
                $result['time_out'],
                $result['adjusted_hours'],
                $_SESSION['intern_id'],
                $today
            ]);
        } catch (PDOException $e) {
            error_log("Error updating daily report on time out: " . $e->getMessage());
        }
        
        echo json_encode([
            'success' => true, 
            'message' => 'Time out recorded successfully',
            'time' => $result['formatted_time_out'],
            'total_hours' => $result['adjusted_hours']
        ]);
        
    } else {
        throw new Exception('Invalid action');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} catch (PDOException $e) {
    error_log("Time action error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error occurred'
    ]);
}
?> 