<?php
session_start();
require_once 'config/database.php';

// Disable error output to prevent JSON corruption
error_reporting(0);
ini_set('display_errors', 0);

// Set content type to JSON
header('Content-Type: application/json');

// Verify if user is logged in as admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Check if this is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$employee_id = isset($input['id']) ? intval($input['id']) : 0;

if ($employee_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid employee ID']);
    exit();
}

try {
    // Get current employee status
    $stmt = $pdo->prepare("SELECT id, name, status FROM employees WHERE id = ?");
    $stmt->execute([$employee_id]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$employee) {
        echo json_encode(['success' => false, 'message' => 'Employee not found']);
        exit();
    }

    // Toggle status
    $new_status = ($employee['status'] === 'active') ? 'inactive' : 'active';

    // Update employee status (without updated_at in case column doesn't exist)
    $update_stmt = $pdo->prepare("UPDATE employees SET status = ? WHERE id = ?");
    $result = $update_stmt->execute([$new_status, $employee_id]);

    if ($result) {
        $action = ($new_status === 'active') ? 'activated' : 'deactivated';
        echo json_encode([
            'success' => true, 
            'message' => "Employee {$employee['name']} has been {$action} successfully",
            'new_status' => $new_status
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update employee status']);
    }

} catch (PDOException $e) {
    error_log("Error toggling employee status: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} catch (Exception $e) {
    error_log("General error toggling employee status: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred']);
}
?> 