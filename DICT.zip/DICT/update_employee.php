<?php
session_start();
require_once 'config/database.php';

// Set content type to JSON
header('Content-Type: application/json');

// Verify if user is logged in as admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Check if this is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get form data
$employee_id = isset($_POST['employee_id']) ? intval($_POST['employee_id']) : 0;
$name = trim($_POST['name'] ?? '');
$position = trim($_POST['position'] ?? '');
$department = trim($_POST['department'] ?? '');
$card_uid = trim($_POST['card_uid'] ?? '');
$status = trim($_POST['status'] ?? '');

// Validate required fields
if (empty($name) || empty($position) || empty($department) || empty($card_uid) || empty($status)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit();
}

if ($employee_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid employee ID']);
    exit();
}

// Validate status
if (!in_array($status, ['active', 'inactive'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid status value']);
    exit();
}

try {
    // Check if employee exists
    $check_stmt = $pdo->prepare("SELECT id FROM employees WHERE id = ?");
    $check_stmt->execute([$employee_id]);
    if (!$check_stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Employee not found']);
        exit();
    }

    // Check if card UID is already in use by another employee
    $uid_check_stmt = $pdo->prepare("SELECT id FROM employees WHERE card_uid = ? AND id != ?");
    $uid_check_stmt->execute([$card_uid, $employee_id]);
    if ($uid_check_stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Card UID is already in use by another employee']);
        exit();
    }

    // Check if card UID is already in use by an intern
    $intern_uid_check_stmt = $pdo->prepare("SELECT id FROM interns WHERE card_uid = ?");
    $intern_uid_check_stmt->execute([$card_uid]);
    if ($intern_uid_check_stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Card UID is already in use by an intern']);
        exit();
    }

    // Update employee information
    $update_stmt = $pdo->prepare("
        UPDATE employees 
        SET name = ?, position = ?, department = ?, card_uid = ?, status = ?, updated_at = NOW()
        WHERE id = ?
    ");
    
    $result = $update_stmt->execute([$name, $position, $department, $card_uid, $status, $employee_id]);
    
    if ($result) {
        echo json_encode([
            'success' => true, 
            'message' => 'Employee information updated successfully'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update employee information']);
    }

} catch (PDOException $e) {
    error_log("Error updating employee: " . $e->getMessage());
    
    // Check for specific database errors
    if (strpos($e->getMessage(), 'card_uid') !== false) {
        echo json_encode(['success' => false, 'message' => 'Card UID must be unique']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error occurred']);
    }
}
?> 