<?php
session_start();
require_once 'config/database.php';

header('Content-Type: application/json');

// Verify if user is logged in as admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Validate required fields
$required_fields = ['intern_id', 'name', 'school', 'card_uid', 'required_hours', 'start_date', 'status'];
foreach ($required_fields as $field) {
    if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
        echo json_encode(['success' => false, 'message' => 'Missing required field: ' . $field]);
        exit();
    }
}

// Sanitize input data
$intern_id = intval($_POST['intern_id']);
$name = trim($_POST['name']);
$school = trim($_POST['school']);
$card_uid = trim($_POST['card_uid']);
$required_hours = intval($_POST['required_hours']);
$start_date = trim($_POST['start_date']);
$status = trim($_POST['status']);

// Validate data
if ($intern_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid intern ID']);
    exit();
}

if (strlen($name) < 2 || strlen($name) > 100) {
    echo json_encode(['success' => false, 'message' => 'Name must be between 2 and 100 characters']);
    exit();
}

if (strlen($school) < 2 || strlen($school) > 200) {
    echo json_encode(['success' => false, 'message' => 'School name must be between 2 and 200 characters']);
    exit();
}

if (strlen($card_uid) < 4 || strlen($card_uid) > 50) {
    echo json_encode(['success' => false, 'message' => 'Card UID must be between 4 and 50 characters']);
    exit();
}

if ($required_hours < 1 || $required_hours > 10000) {
    echo json_encode(['success' => false, 'message' => 'Required hours must be between 1 and 10000']);
    exit();
}

// Validate date format
if (!DateTime::createFromFormat('Y-m-d', $start_date)) {
    echo json_encode(['success' => false, 'message' => 'Invalid date format']);
    exit();
}

// Validate status
$valid_statuses = ['active', 'completed', 'suspended'];
if (!in_array($status, $valid_statuses)) {
    echo json_encode(['success' => false, 'message' => 'Invalid status value. Valid values are: ' . implode(', ', $valid_statuses)]);
    exit();
}

try {
    // Check if intern exists
    $stmt = $pdo->prepare("SELECT id FROM interns WHERE id = ?");
    $stmt->execute([$intern_id]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Intern not found']);
        exit();
    }
    
    // Check if card UID is already in use by another intern
    $stmt = $pdo->prepare("SELECT id FROM interns WHERE card_uid = ? AND id != ?");
    $stmt->execute([$card_uid, $intern_id]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Card UID is already in use by another intern']);
        exit();
    }
    
    // Check if card UID is already in use by an employee
    $stmt = $pdo->prepare("SELECT id FROM employees WHERE card_uid = ?");
    $stmt->execute([$card_uid]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Card UID is already in use by an employee']);
        exit();
    }
    
    // Update intern record
    $stmt = $pdo->prepare("
        UPDATE interns 
        SET name = ?, school = ?, card_uid = ?, required_hours = ?, start_date = ?, status = ?, updated_at = NOW()
        WHERE id = ?
    ");
    
    $result = $stmt->execute([
        $name,
        $school,
        $card_uid,
        $required_hours,
        $start_date,
        $status,
        $intern_id
    ]);
    
    if ($result) {
        echo json_encode([
            'success' => true, 
            'message' => 'Intern updated successfully!'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update intern']);
    }
    
} catch (PDOException $e) {
    error_log("Update intern error: " . $e->getMessage());
    error_log("SQL State: " . $e->getCode());
    error_log("Error Info: " . print_r($e->errorInfo, true));
    
    // Provide more specific error messages for common issues
    $errorMessage = 'Database error occurred';
    if (strpos($e->getMessage(), 'Unknown column') !== false) {
        $errorMessage = 'Database schema error - missing column. Please contact administrator.';
    } elseif (strpos($e->getMessage(), 'Duplicate entry') !== false) {
        $errorMessage = 'Duplicate entry error - this data may already exist.';
    } elseif (strpos($e->getMessage(), 'Data too long') !== false) {
        $errorMessage = 'Data validation error - one or more fields exceed maximum length.';
    }
    
    echo json_encode([
        'success' => false, 
        'message' => $errorMessage,
        'debug_info' => [
            'error_code' => $e->getCode(),
            'sql_state' => $e->errorInfo[0] ?? 'Unknown',
            'error_message' => $e->getMessage()
        ]
    ]);
}
?> 