<?php
session_start();
require_once 'config/database.php';

// Verify admin authentication
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['user_type'] !== 'admin') {
    http_response_code(403);
    exit('Access denied');
}

// Get image path from query parameter
$imagePath = $_GET['path'] ?? '';

if (empty($imagePath)) {
    http_response_code(400);
    exit('Image path required');
}

// Security: Ensure the path is within our images directory and has valid format
$imagePath = trim($imagePath);
$allowedPath = 'images/attendance/';

// Check if path starts with allowed directory
if (strpos($imagePath, $allowedPath) !== 0) {
    http_response_code(403);
    exit('Invalid image path');
}

// Prevent directory traversal attacks
if (strpos($imagePath, '..') !== false || strpos($imagePath, './') !== false) {
    http_response_code(403);
    exit('Invalid image path');
}

// Check if file exists
if (!file_exists($imagePath)) {
    http_response_code(404);
    exit('Image not found');
}

// Validate file extension
$allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
$extension = strtolower(pathinfo($imagePath, PATHINFO_EXTENSION));

if (!in_array($extension, $allowedExtensions)) {
    http_response_code(403);
    exit('Invalid file type');
}

// Verify the image path exists in database for additional security
try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count 
        FROM attendance_logs 
        WHERE image_path = ? OR timeout_image_path = ?
    ");
    $stmt->execute([$imagePath, $imagePath]);
    $result = $stmt->fetch();
    
    if ($result['count'] == 0) {
        http_response_code(404);
        exit('Image not found in records');
    }
} catch (PDOException $e) {
    error_log("Image verification error: " . $e->getMessage());
    http_response_code(500);
    exit('Database error');
}

// Set appropriate headers
$mimeType = 'image/' . ($extension === 'jpg' ? 'jpeg' : $extension);
header('Content-Type: ' . $mimeType);
header('Content-Length: ' . filesize($imagePath));
header('Cache-Control: private, max-age=3600'); // Cache for 1 hour
header('Pragma: private');

// Output the image
readfile($imagePath);
exit;
?> 